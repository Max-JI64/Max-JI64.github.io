# Multi-Source Join Rules

## Evidence required before proposing a join

Check all of the following:

1. The business meaning of each candidate key matches across sources.
2. The analytical grain is compatible or an explicit aggregation is planned.
3. Key uniqueness supports the expected cardinality.
4. Time periods, time zones, and periodicity are compatible.
5. Geographic codes and boundary versions are compatible.
6. Units, currencies, scales, and category definitions agree or have an
   explicit conversion.
7. Coverage loss and unmatched keys can be measured after execution.
8. Provenance remains traceable at source and derived-field level.
9. Profiled key overlap is positive. Zero overlap in a complete profile blocks
   the join; zero overlap in a sampled profile requires review.

Matching column names alone never prove join safety.

## Cardinality policy

- `ONE_TO_ONE`: allow as a candidate when both sides are unique at the proposed
  key.
- `ONE_TO_MANY` or `MANY_TO_ONE`: allow only when the repeated side is expected
  by the declared grain and the analysis plan states how duplication is avoided.
- `MANY_TO_MANY`: block by default. Require an aggregation, bridge table, or
  corrected composite key before integrated analysis.
- `UNKNOWN`: require extraction or additional source information.

Prefer the shortest composite key that satisfies the intended grain. Do not
select a single shared column when a composite key is required for uniqueness.
When both tables declare grain, generate key candidates only from the shared
declared-grain columns. Do not promote a shared measure to a join key merely
because its values are unique.

If no candidate is safe, retain the most specific shared declared-grain
composite key in the diagnostic. This makes it explicit when a many-to-many
relationship remains even at the common country-period grain because each
source has a different additional dimension.

For three or more inspected tables, an automatic `INTEGRATED` plan additionally
requires safe one-to-one candidates with the same normalized composite key to
form a connected graph across every target table. Otherwise use `SEPARATE` and
record the rejected candidate evidence as risks.

## Grain mismatch

When sources have different grains:

- Specify the target analytical grain.
- Aggregate the finer source only with a justified statistic and denominator.
- Never duplicate coarse values across fine rows and then treat them as
  independent observations.
- Keep source-separated analyses when no defensible target grain exists.

## Units and definitions

- Block direct comparison when units conflict and no conversion is defined.
- Treat conflicting units on a same-name non-key measure as
  `UNIT_ALIGNMENT_REQUIRED:<measure>`. Keep the sources separate in v1 because
  the Planner contract does not define an executable conversion.
- Distinguish counts, rates, percentages, indexes, currency values, and
  cumulative values.
- Treat similarly named categories from different publishers as unaligned until
  definitions are checked.
- Record boundary-year or classification-version mismatches as material risks.

## Join assessment output

For every proposed combination, record:

- left and right source/table identifiers
- normalized and original key columns
- cardinality estimate
- uniqueness ratios
- sampled key overlap
- unit or definition conflicts
- temporal, time-zone, geography, and key-overlap alignment issues
- safety status: `SAFE_CANDIDATE`, `REQUIRES_REVIEW`, or `BLOCKED`
- required confirmation or transformation

Do not put blocked or review-required candidates in the executable `joins`
array. Preserve them as risks and offer source-separated analysis.

An executable `INTEGRATED` join must be one-to-one, have positive key overlap,
contain no key or measure unit conflict, and contain no unresolved alignment
issue.
