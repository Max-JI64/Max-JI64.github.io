# Variable Semantics

Build `variable_inventory.v1` after structural source inspection and before
question generation. Keep physical type, semantic role, measurement scale, and
analysis role separate.

## Deterministic workflow

1. Use column names, declared grain and units, physical type, missingness,
   uniqueness, numeric summaries, string lengths, and pattern counts.
2. Emit no raw rows, sensitive values, or labelled top-value lists.
3. Mark sensitive names, addresses, email addresses, and phone numbers
   `EXCLUDED_SENSITIVE`.
4. Mark high-impact ambiguity `NEEDS_USER_CONFIRMATION`; do not generate
   analysis questions while any such request remains.
5. Apply `variable_semantic_overlay.v1` only as a suggestion. Reject unknown
   fields and any attempt to change sources, keys, units, joins, modules, or
   approval.
6. Apply `variable_confirmations.v1` as `CONFIRM` or `DEFER`. Map `DEFER` to
   `UNKNOWN` and exclude it from analytical selection. Preserve contradictions
   instead of overriding observed structure.

Run:

```powershell
python scripts/build_variable_inventory.py REQUEST.json INVENTORY.json `
  --output VARIABLES.json `
  --review-output REVIEW.json `
  [--llm-overlay OVERLAY.json] `
  [--user-confirmations CONFIRMATIONS.json]
```

## Controlled values

- Semantic role: `IDENTIFIER`, `PERSON_NAME`, `ADDRESS`, `EMAIL`,
  `PHONE_NUMBER`, `FREE_TEXT`, `NOMINAL_CATEGORY`, `ORDINAL_CATEGORY`,
  `TEMPORAL`, `GEOGRAPHIC`, `QUANTITATIVE_MEASURE`, `UNKNOWN`.
- Measurement scale: `NOMINAL`, `ORDINAL`, `INTERVAL`, `RATIO`,
  `NOT_APPLICABLE`, `UNKNOWN`.
- Analysis role: `JOIN_KEY`, `MEASURE`, `GROUP`, `TIME_AXIS`, `GEO_AXIS`,
  `QUALITY_ONLY`, `EXCLUDED`, `UNKNOWN`.
- Status: `AUTO_CONFIDENT`, `LLM_SUGGESTED`, `NEEDS_USER_CONFIRMATION`,
  `USER_CONFIRMED`, `UNKNOWN`, `EXCLUDED_SENSITIVE`.

## Analysis policy

- Use identifiers and numeric codes only for quality, key integrity, and
  approved joins.
- Use nominal categories for frequency, proportion, crosstab, and grouping.
- Use ordinal categories for ordered summaries, medians, ranks, distributions,
  and grouping; do not assume equal intervals.
- Use interval measures for distributions, means, differences, and non-causal
  association; do not interpret absolute zero or multiples.
- Use ratio measures for arithmetic, ratios, and multiplicative comparison only
  when unit and denominator semantics are confirmed.
- Use person names, addresses, contact fields, and free text for structural
  quality only. Text analysis requires a separate approved module.
- Keep regression, prediction, causal inference, and optimization outside v1.

## Metadata precedence and quality-only patterns

Restricted user-confirmed metadata overrides automatic heuristics. Coverage
counts, completeness or availability flags, display/sort order, and index base
period/value metadata are `QUALITY_ONLY`, not measures or axes. A suffix such
as `_year` is insufficient to establish `TIME_AXIS`.

`QUALITY_ONLY` and `EXCLUDED` suppress analytic permissions regardless of name
or physical type. A geography with both `GEO_AXIS` and `GROUP` may support
spatial analysis and geographic group comparison. When equivalent time
columns exist, only the analysis-focus `time_axis` is the primary EDA axis.
