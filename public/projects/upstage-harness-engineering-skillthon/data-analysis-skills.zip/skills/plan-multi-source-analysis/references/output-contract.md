# Output Contracts

## `analysis_blueprint.v1`

Emit a JSON object with these top-level fields:

```json
{
  "schema_version": "analysis_blueprint.v1",
  "blueprint_id": "regional-youth-001-plan",
  "request_id": "regional-youth-001",
  "status": "READY_FOR_APPROVAL",
  "source_inventory": [],
  "variable_inventory": {
    "schema_version": "variable_inventory.v1",
    "status": "READY",
    "variables": [],
    "confirmation_requests": []
  },
  "variable_inventory_sha256": "...",
  "variable_confirmation_requests": [],
  "structure_confirmation_requests": [],
  "preparation_plan": {
    "schema_version": "data_preparation_plan.v1",
    "sources": [],
    "join_output": {
      "mode": "INNER",
      "prefix_non_key_columns": true
    },
    "required_audits": [],
    "mvp_limits": {
      "formats": ["csv", "tsv"],
      "maximum_sources": 3
    },
    "join_strategy": "INTEGRATED"
  },
  "join_plan": {
    "strategy": "INTEGRATED",
    "target_grain": ["region", "year"],
    "joins": [
      {
        "left_source_id": "population",
        "right_source_id": "employment",
        "keys": ["region", "year"],
        "cardinality": "ONE_TO_ONE",
        "safety": "SAFE_CANDIDATE",
        "sampled_key_overlap": 1.0,
        "unit_conflicts": [],
        "measure_unit_conflicts": [],
        "alignment_issues": []
      }
    ],
    "risks": []
  },
  "candidate_questions": [],
  "selected_question": {},
  "analysis_steps": [],
  "validation_plan": [],
  "deliverables": [],
  "limitations": [],
  "approval": {
    "status": "PENDING",
    "required": true
  }
}
```

### Status rules

- `NEEDS_SOURCE_INFO`: non-provenance structural definitions that are strictly
  required to access or parse the source are missing. Ordinary uncertainty
  about row meaning, temporal cadence, time-field meaning, or measure time basis
  must remain advisory and must not produce this status. Missing source or
  license metadata alone must not produce this status.
- `NEEDS_VARIABLE_CONFIRMATION`: high-impact semantic ambiguity remains. Emit
  the batched confirmation requests and keep questions, selection, analysis
  steps, validation, and deliverables empty.
- `NEEDS_QUESTION_SELECTION`: two or three feasible candidate questions are
  available but none is selected.
- `READY_FOR_APPROVAL`: one question is selected and the full plan is complete.
- `BLOCKED`: files are unavailable/unreadable or no defensible exploratory plan
  can be produced.

Use a maximum of three `candidate_questions`. Give every question a stable
`question_id`, text, rationale, required sources, module IDs, feasibility, and
risks.

Every analysis step must use a module from the v1 analysis catalog. Include
`step_id`, `module`, `source_ids`, `purpose`, and expected outputs.

For incomplete provenance, keep the Blueprint approval-eligible, preserve
`missing_provenance`, `provenance_note`, and `provenance_status` in the source
inventory, add a `PROVENANCE_PARTIAL` or `PROVENANCE_UNKNOWN` limitation, and
include `provenance_disclosure` plus `provenance_summary`.

The validator rejects an `INTEGRATED` join unless it is a positive-overlap
`ONE_TO_ONE` `SAFE_CANDIDATE` with empty key-unit, measure-unit, and alignment
issue arrays. Non-integrated plans must keep the executable `joins` array empty.

Never embed `analysis_execution_request` inside a pre-approval blueprint.

The additive `preparation_plan` freezes source locators, table IDs,
collision-free output column mappings, strict inferred target types, declared
key columns, approved variable metadata, and preparation-related audit IDs
before approval. The MVP
executor accepts local CSV/TSV and at most two sources; other Planner inputs
remain valid plans but require a future executor.

Build the contract with:

```powershell
python scripts/build_blueprint.py REQUEST.json INVENTORY.json `
  --variable-inventory VARIABLES.json `
  [--question-refinements REFINEMENTS.json] `
  [--select-question q1] `
  [--output BLUEPRINT.json]
```

The builder owns status, source requirements, module IDs, join decisions,
analysis steps, validation, deliverables, and limitations. Do not edit those
fields manually.

### Internal question refinement overlay

`question_refinements.v1` is an internal planner helper, not a replacement for
the public Blueprint:

```json
{
  "schema_version": "question_refinements.v1",
  "blueprint_id": "regional-youth-001-plan",
  "questions": [
    {
      "question_id": "q1",
      "text": "Refined question text",
      "rationale": "Refined value explanation",
      "rank": 1
    }
  ]
}
```

Reject unknown question IDs, duplicate ranks, and any structural field.

## `analysis_execution_request.v1`

Create only after explicit user approval:

Every newly generated execution freezes `data_access_policy.v1` with
`mode: USER_PROVIDED_LOCAL_ONLY`, `network_access: false`,
`remote_fetch: false`, and `when_data_is_missing: REQUEST_USER`. No execution
task may browse, call a data API, or acquire a missing source.

The exploratory-analysis task also freezes `generic_analysis_recipe.v1`.
Technique selection, derived-variable eligibility, visualization rules,
sensitivity thresholds, insight ranking, and claim boundaries are executed by
Python. A downstream model must not improvise or relax them.

```json
{
  "schema_version": "analysis_execution_request.v1",
  "execution_id": "regional-youth-001-exec",
  "blueprint_id": "regional-youth-001-plan",
  "approved_question": {
    "question_id": "q1",
    "text": "..."
  },
  "approval": {
    "status": "APPROVED",
    "approved_by": "user"
  },
  "source_refs": ["population", "employment"],
  "frozen_variable_inventory": {},
  "frozen_preparation_plan": {},
  "frozen_join_plan": {
    "strategy": "INTEGRATED",
    "target_grain": ["region", "year"],
    "joins": [],
    "risks": []
  },
  "tasks": [
    {
      "task_id": "inspect-1",
      "task_type": "inspect_table",
      "executor": "table-inspector",
      "depends_on": [],
      "inputs": {},
      "expected_outputs": []
    }
  ],
  "deliverables": [],
  "trace_requirements": {
    "preserve_source_ids": true,
    "record_provenance_status": true,
    "record_row_counts": true,
    "record_join_coverage": true
  },
  "executor_status": "WAITING_FOR_EXECUTOR"
}
```

Order tasks from inspection through transformation, joining,
exploratory analysis, validation, and report rendering. Dependencies must refer
only to earlier task IDs.

Set `executor_status` to:

- `WAITING_FOR_EXECUTOR` when downstream Skills are not implemented or available.
- `READY_TO_DISPATCH` only when every named executor is actually callable.

Do not include fabricated results, row counts, join coverage, or analysis
findings in an execution request.

Build the request with:

```powershell
python scripts/build_execution_request.py BLUEPRINT.json `
  --approved-by user `
  [--output EXECUTION.json]
```

The generator accepts only `READY_FOR_APPROVAL` Blueprints and non-empty
approval attribution. It always returns `WAITING_FOR_EXECUTOR` in v1.1.

Every `clean_transform` task carries the exact matching frozen source plan.
Every `join_sources` task carries the exact frozen join plan, inner-join output
policy, and preparation audit IDs.
Every exploratory-analysis task carries the exact frozen variable inventory.
Generated execution requests always freeze the Blueprint variable inventory;
the validator continues accepting older additive-v1 examples that predate this
field, but the current preparation executor requires it.

Order tasks as inspection, preparation, safe join when applicable, EDA,
evidence validation, and report rendering.

## Pre-approval analysis policies

Every generated Blueprint includes resolved `analysis_focus.v1`, proposed
`staged_eda_policy.v1`, and proposed `generic_analysis_recipe.v1`. These expose
modules, axes, primary/comparison measures, derived rules, sensitivity pairs,
statistical thresholds, conditional second-pass triggers, per-finding
third-pass validation, chart selection and limits, evidence statuses, and claim
boundaries before approval.

The recipe also freezes derived-rule cohort comparisons, one-summary evidence
promotion for rules and sensitivity pairs, one stage-1 baseline evidence item
for every frozen association pair, question-coverage/diversity limits for the
top eight insights, primary-only distribution/time chart allocation, one chart
per frozen association pair, and finding-specific additional-data-request
rules. Table-wide missingness alone is not an approved request trigger.

An approved execution request deep-copies these objects into
`frozen_analysis_focus`, `frozen_staged_eda_policy`, and
`frozen_generic_analysis_recipe`, and into the EDA task inputs. Validators
require exact equality. Approval cannot introduce a new module, rule,
threshold, sensitivity check, or chart policy.

The resolved focus and recipe also freeze the exact association-pair IDs and
variable IDs, the non-geometric spatial baseline, one-to-one geography-label
requirement, core requested-module baselines, triggered drilldowns, and the
universal per-finding validation record shape.
