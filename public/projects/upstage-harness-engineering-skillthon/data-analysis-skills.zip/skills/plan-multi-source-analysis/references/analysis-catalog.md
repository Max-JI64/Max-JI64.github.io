# Exploratory Analysis Catalog

Use only the modules below in v1.

| Module ID | Use when | Minimum evidence | Typical output |
|---|---|---|---|
| `data_quality` | Any structured table is present | schema and row availability | missingness, duplicates, validity and coverage |
| `distribution` | Approved numeric, nominal, or ordinal variables exist | semantic role, scale, usable values and units | robust summaries, frequency tables |
| `group_comparison` | A measure and defensible grouping field exist | adequate group sizes and common definition | group profiles and effect-size-oriented comparisons |
| `temporal_pattern` | A parseable time field exists | sufficient coverage and declared periodicity | trend, seasonality and period comparisons |
| `spatial_pattern` | Geographic identifiers or coordinates exist | compatible geography definitions | geographic distribution and regional contrasts |
| `association` | At least two compatible measures exist | pairwise denominators and confounding warning | non-causal association screen |
| `anomaly_screen` | Repeated or sufficiently large numeric observations exist | robust reference distribution | review candidates and threshold sensitivity |
| `cross_source_consistency` | Sources measure overlapping concepts | aligned definitions, periods, units and grain | agreement, discrepancy and coverage audit |

## Question proposal rules

- Propose no more than three questions.
- Rank multi-source questions before single-source questions when the join is
  defensible and the integrated question adds analytical value.
- When sources must remain `SEPARATE`, keep each candidate's
  `required_source_ids` limited to the source named in the question and rotate
  candidates across the available sources before repeating one source.
- Give each question:
  - a concrete population, period, measure, and comparison or pattern
  - the required source identifiers
  - feasible module IDs
  - expected evidence and deliverables
  - material risks and missing information
- Prefer questions that can be validated by period, subgroup, source, or
  sensitivity checks.
- Avoid questions that reduce to a single lookup.
- Derive period scope from observed time-column ranges and geography scope from
  the same source's declared metadata and profiled coverage. Include month
  coverage and the number of profiled geographic units when available, but do
  not expose row-level identifiers to make the question look concrete.
- Preserve residual declared-grain dimensions such as age group or sex in the
  question wording so that source-separated analysis does not silently
  aggregate them away.
- Select fields only when `variable_inventory.v1` allows the required analysis.
  Never use identifiers, numeric codes, time axes, geography codes, coordinates,
  sensitive strings, `UNKNOWN`, or unconfirmed LLM suggestions as measures.
  Categorical dimensions may support group comparison only when their semantic
  role and scale allow it.
- Choose the measure from the same source whose title is used in the question.
  Do not combine one source's title with another source's field merely because
  both support the same module.
- Generate question structure deterministically from inspected column types,
  normalized time/geography names, units, row counts, and the safe join plan.
- Use `question_refinements.v1` only to improve candidate text, rationale, and
  rank. Do not let a refinement change IDs, required sources, modules,
  feasibility, or risks.
## Unsupported goals

Do not plan these in v1:

- prediction or forecasting
- causal effect estimation
- policy optimization or automated decisions
- prescriptive recommendations presented as measured effects

When a request uses causal or predictive language, preserve the user's topic but
offer an exploratory reformulation. For example:

- Replace "무엇이 매출을 증가시키는가?" with "매출과 함께 변하는 요인과 그
  관계가 기간·집단별로 일관적인가?"
- Replace "다음 달 수요를 예측해줘" with "수요의 추세·계절성과 변동이 큰
  기간은 언제인가?"

## Validation planning

Select at least one feasible check:

- period holdout or time-window comparison
- subgroup or geography stability
- source-to-source agreement
- join coverage and unmatched-key audit
- unit conversion scale, rounding, and transformed-value audit
- temporal aggregation frequency, statistic, denominator, and row-count audit
- geography code-system, boundary, overlap, and unmatched-key audit
- many-to-many grain resolution through a dimension-preserving key,
  approved aggregation, or bridge
- alternative threshold or aggregation sensitivity
- denominator and missingness sensitivity
- provenance disclosure: preserve user-supplied source notes, label unknown
  source or license fields, and avoid implying verified redistribution rights

Do not label exploratory stability as causal or predictive validation.

## Explicit module selection

When `analysis_focus.requested_modules` is present, preserve its order and
select every module supported by the frozen variables. Do not require a
matching natural-language keyword and do not silently discard a requested
module. Reject unsupported explicit modules.

Keyword fallback is used only without an explicit list. It recognizes temporal
persistence or change, between-group or between-region comparison,
spatial/geographic scope, and co-movement or association. Add declared
sensitivity-pair checks and coverage requirements to the validation plan before
approval.
