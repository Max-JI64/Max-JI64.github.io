# Input Contract

## `analysis_planning_request.v1`

Use this platform-neutral request shape:

```json
{
  "schema_version": "analysis_planning_request.v1",
  "request_id": "regional-youth-001",
  "question": null,
  "sources": [
    {
      "source_id": "population",
      "location": "population.csv",
      "format": "csv",
      "title": "지역별 청년 인구",
      "publisher": "Example Statistics Office",
      "source_url": "https://example.org/population",
      "license": "CC BY 4.0",
      "provenance_note": "사용자가 제공한 파일; 공공데이터포털 출처라고 기재함",
      "declared_grain": ["region", "year"],
      "column_units": {
        "population": "people"
      }
    }
  ],
  "preferences": {
    "language": "ko",
    "max_question_candidates": 3,
    "approval_required": true
  }
}
```

## Required fields

- Require `schema_version` to equal `analysis_planning_request.v1`.
- Require a stable `request_id`.
- Require one or more `sources` with unique `source_id` values.
- Require each source to contain a local `location`.
- Accept `question` as null or a non-empty string.

## Supported source formats

- Treat `csv`, `tsv`, `xlsx`, and tabular `json` as structured sources.
- Reject `pdf`, images, free-form documents, and other unstructured formats.
- Reject an HTTP(S) `location`. Return `user_data_requests` and ask the user to
  provide the structured local file. The Agent must not browse, call an API, or
  download it. `source_url` remains inert, user-supplied provenance metadata
  and must never be opened by this Skill.
- Infer format from the location suffix only when `format` is omitted.

## Provenance fields

Track these optional fields per source when the user knows them:

- `title`
- `publisher`
- `source_url`
- `license`
- `provenance_note`: free text supplied by the user, such as
  `공공데이터포털 출처라고 기재함`, `사용자가 직접 생성`,
  `지인에게 전달받음`, or `출처 모름`

Do not invent missing values. Accept any subset, including only a site name or
free-text note. The user may explicitly enter `unknown`, `모름`, or
`해당 없음`. Empty strings and `null` in these optional fields are treated as
omitted values, so an unfilled form does not invalidate the request.

Classify the recorded metadata as:

- `COMPLETE`: all four structured provenance fields are supplied.
- `PARTIAL`: at least one structured field or `provenance_note` is supplied.
- `UNKNOWN`: no provenance information is supplied.

Missing provenance or license never blocks question selection, approval, or
analysis. Preserve the gaps in `missing_provenance`, add a
`provenance_disclosure` validation check, and label unverified information in
downstream reports. Unknown licensing may require separate review before public
redistribution, but it does not block the analysis itself.

Minimal accepted examples:

```json
{"provenance_note": "사용자가 제공한 파일이며 어느 정부 사이트 출처라고 함"}
```

```json
{"provenance_note": "개인이 직접 수집", "license": "해당 없음"}
```

```json
{"provenance_note": "출처 모름", "license": "unknown"}
```

## Optional structural declarations

- `declared_grain`: columns that identify one analytical observation.
- `column_units`: mapping of column names to units.
- `time_zone`: non-empty declared time zone for temporal data.
- `periodicity`: non-empty expected time interval such as `annual`, `quarterly`,
  `monthly`, or `daily`.
- `geography`: object with required `level` and `code_system`, plus optional
  `boundary_version`.
- `dataset_structure`: user-confirmed dataset-level meaning. Do not infer these
  fields from column names or value spacing.
  - `observation_unit`: plain-language meaning of one row.
  - `time_granularity`: declared cadence such as `daily`, `weekly`, `monthly`,
    `quarterly`, `annual`, or `irregular`. This may replace `periodicity`.
  - `time_field_meaning`: whether time fields represent an event, reference
    period, aggregation window, or publication time.
  - `measure_time_basis`: mapping from measure columns to meanings such as
    `snapshot`, `period_total`, `period_average`, `rate`, `cumulative`, or
    `index`.
  - `comparison_notes`: user-provided collection, revision, scope, or
    definition notes that may explain cross-source differences.
- `notes`: source-specific caveats.

Treat declarations as claims to verify, not facts that override observed data.
When the row grain, a time field's cadence or meaning, or a time-varying
measure's basis is absent, emit an advisory `structure_confirmation_requests`
item. Preserve the value as unknown and continue planning. Do not present an
unconfirmed interpretation as fact; retain the request so it can be resolved
later if it materially affects preparation, comparison, or interpretation.

Example:

```json
{
  "periodicity": "annual",
  "dataset_structure": {
    "observation_unit": "one row per country and year",
    "time_granularity": "annual",
    "time_field_meaning": "calendar-year reference period",
    "measure_time_basis": {
      "population": "snapshot"
    },
    "comparison_notes": "publisher revisions may change historical values"
  },
  "geography": {
    "level": "country",
    "code_system": "ISO 3166-1 alpha-3",
    "boundary_version": "publisher release 2026-03"
  }
}
```

The inspector preserves these declarations, records whether the table profile
covers all rows, and reports observed ranges for recognized time columns. It
also emits privacy-preserving numeric summaries, string-length summaries,
pattern counts, and frequency summaries. It never emits raw rows or labelled
top-value lists into planning artifacts.

## Input handling rules

- Resolve relative local paths from the request JSON directory.
- Do not modify source files.
- Do not access the internet, browse source pages, call APIs, or fetch remote
  locations inside this Skill or any downstream Skill.
- If a required local file is missing or a remote location is supplied, stop
  that source at `BLOCKED` and emit a structured `user_data_requests` item.
- Do not copy sensitive row values into planning artifacts.
- Report unreadable, encrypted, missing, or unsupported inputs explicitly.
- If `max_question_candidates` is present, require an integer from 1 through 3.
  When question selection is required, the deterministic builder emits at least
  two candidates to satisfy the Blueprint contract.

## Execution-specific analysis focus

`analysis_focus` is authoritative when present. It declares requested modules,
one primary measure, comparison measures, primary time/group/geography axes,
an optional geography label, sensitivity pairs, and derived rules. A reference
is exactly either `variable_id` or `source_id` + `table_id` +
`source_column`. The Blueprint resolves each reference to a frozen variable ID
and rejects unknown, disallowed, or role-incompatible variables.

Explicit modules take precedence over question-keyword fallback. Sensitivity
pairs declare compatible unit/scale requirements, axes, checks, any
classification threshold, and minimum pairwise observations. Derived rules use
only `proportion_below_threshold`,
`consecutive_periods_below_threshold`, `window_mean_difference`, or
`first_latest_difference` with explicit observation, window, missingness, and
partial-period rules.

`derived_group_comparisons` may declare a comparison whose selected cohort is
determined by one frozen derived rule. It requires a stable comparison ID,
selector rule ID, `equal`/`at_least`/`at_most` operator and numeric selector
value, a non-empty subset of the approved comparison measures,
`median_of_group_medians_difference`, minimum selected and remaining group
counts, minimum observations per group, `exclude_missing`, and the
`observed_non_causal_group_contrast` claim boundary. The Blueprint resolves all
measure references to variable IDs and rejects unknown rules, unapproved
measures, or quality-only variables.

`association_pairs` may explicitly declare `pair_id`, `left_variable`, and
`right_variable`. Without it, the Blueprint resolves the primary measure
crossed with each comparison measure. It never adds comparison-to-comparison
pairs. An alternative-definition variable remains sensitivity-only unless it is
also a declared comparison measure.

`variable_metadata_overrides` is restricted to a variable reference,
`semantic_role`, `measurement_scale`, `analysis_roles`, optional `unit`, and
non-empty `rationale`. It may correct automatic classifications but may never
promote excluded sensitive data or combine `QUALITY_ONLY` with an analytic
measure or axis role.
