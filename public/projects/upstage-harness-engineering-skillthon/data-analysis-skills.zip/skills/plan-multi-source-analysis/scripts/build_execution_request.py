#!/usr/bin/env python3
"""Build an execution request only from an explicitly approved blueprint."""

from __future__ import annotations

import argparse
from copy import deepcopy
import json
from pathlib import Path
import sys
from typing import Any, Iterable

from validate_contract import validate_blueprint, validate_execution


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")


EXECUTION_SCHEMA = "analysis_execution_request.v1"


def _load_json(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(payload, dict):
        raise ValueError("TOP_LEVEL_JSON_MUST_BE_OBJECT")
    return payload


def _task(
    task_id: str,
    task_type: str,
    executor: str,
    depends_on: list[str],
    inputs: dict[str, Any],
    expected_outputs: list[str],
) -> dict[str, Any]:
    return {
        "task_id": task_id,
        "task_type": task_type,
        "executor": executor,
        "depends_on": depends_on,
        "inputs": inputs,
        "expected_outputs": expected_outputs,
    }


def _source_refs(blueprint: dict[str, Any]) -> list[str]:
    selected = blueprint.get("selected_question", {})
    refs = selected.get("required_source_ids", [])
    if not refs:
        refs = [
            source.get("source_id")
            for source in blueprint.get("source_inventory", [])
        ]
    return sorted({str(source_id) for source_id in refs})


def _full_tasks(
    blueprint: dict[str, Any], source_refs: list[str]
) -> list[dict[str, Any]]:
    tasks: list[dict[str, Any]] = []
    inspect_ids: dict[str, str] = {}
    prepare_ids: list[str] = []
    preparation_plan = blueprint.get("preparation_plan", {})
    preparation_sources = {
        str(source.get("source_id")): source
        for source in preparation_plan.get("sources", [])
        if isinstance(source, dict)
    }
    for index, source_id in enumerate(source_refs, 1):
        task_id = f"inspect-{index:02d}"
        inspect_ids[source_id] = task_id
        tasks.append(
            _task(
                task_id,
                "inspect_table",
                "table-inspector",
                [],
                {"source_id": source_id},
                ["inspection_result"],
            )
        )
    for index, source_id in enumerate(source_refs, 1):
        task_id = f"prepare-{index:02d}"
        prepare_ids.append(task_id)
        tasks.append(
            _task(
                task_id,
                "clean_transform",
                "prepare-multi-source-data",
                [inspect_ids[source_id]],
                {
                    "source_id": source_id,
                    "preparation_source": deepcopy(
                        preparation_sources.get(source_id, {})
                    ),
                },
                ["prepared_table", "transformation_manifest"],
            )
        )
    analysis_dependencies = prepare_ids
    join_plan = blueprint.get("join_plan", {})
    if join_plan.get("strategy") == "INTEGRATED":
        tasks.append(
            _task(
                "join-01",
                "join_sources",
                "prepare-multi-source-data",
                prepare_ids,
                {
                    "join_plan": deepcopy(join_plan),
                    "join_output": deepcopy(
                        preparation_plan.get("join_output", {})
                    ),
                    "required_audits": deepcopy(
                        preparation_plan.get("required_audits", [])
                    ),
                },
                ["joined_table", "join_audit"],
            )
        )
        analysis_dependencies = ["join-01"]
    tasks.append(
        _task(
            "eda-01",
            "exploratory_analysis",
            "run-exploratory-analysis",
            analysis_dependencies,
            {
                "question": deepcopy(blueprint["selected_question"]),
                "analysis_steps": deepcopy(blueprint["analysis_steps"]),
                "variable_inventory": deepcopy(
                    blueprint["variable_inventory"]
                ),
                "analysis_focus": deepcopy(blueprint["analysis_focus"]),
                "staged_eda_policy": deepcopy(
                    blueprint["staged_eda_policy"]
                ),
                "generic_analysis_recipe": deepcopy(
                    blueprint["generic_analysis_recipe"]
                ),
            },
            [
                "analysis_tables",
                "candidate_findings",
                "evidence_records",
                "finding_validation_records",
                "additional_data_requests",
                "chart_manifest",
                "execution_integrity",
            ],
        )
    )
    tasks.append(
        _task(
            "validate-01",
            "validate_findings",
            "run-exploratory-analysis",
            ["eda-01"],
            {"validation_plan": deepcopy(blueprint["validation_plan"])},
            ["validation_summary", "validated_evidence"],
        )
    )
    tasks.append(
        _task(
            "report-01",
            "render_report",
            "render-analysis-deliverables",
            ["validate-01"],
            {"deliverables": deepcopy(blueprint["deliverables"])},
            ["report_markdown", "report_pdf", "dashboard_html"],
        )
    )
    return tasks


def build_execution_request(
    blueprint: dict[str, Any], approved_by: str
) -> dict[str, Any]:
    blueprint_errors = validate_blueprint(blueprint)
    if blueprint_errors:
        raise ValueError(
            "INVALID_BLUEPRINT:" + ",".join(blueprint_errors)
        )
    if blueprint.get("status") != "READY_FOR_APPROVAL":
        raise ValueError("BLUEPRINT_NOT_READY_FOR_APPROVAL")
    if not isinstance(approved_by, str) or not approved_by.strip():
        raise ValueError("EXPLICIT_APPROVED_BY_REQUIRED")
    selected = blueprint.get("selected_question")
    if not isinstance(selected, dict) or not selected.get("question_id"):
        raise ValueError("SELECTED_QUESTION_REQUIRED")
    source_refs = _source_refs(blueprint)
    tasks = _full_tasks(blueprint, source_refs)
    payload = {
        "schema_version": EXECUTION_SCHEMA,
        "execution_id": f"{blueprint['request_id']}-exec",
        "blueprint_id": blueprint["blueprint_id"],
        "approved_question": deepcopy(selected),
        "approval": {
            "status": "APPROVED",
            "approved_by": approved_by.strip(),
        },
        "source_refs": source_refs,
        "frozen_variable_inventory": deepcopy(
            blueprint["variable_inventory"]
        ),
        "frozen_join_plan": deepcopy(blueprint["join_plan"]),
        "frozen_preparation_plan": deepcopy(
            blueprint["preparation_plan"]
        ),
        "frozen_analysis_focus": deepcopy(blueprint["analysis_focus"]),
        "frozen_staged_eda_policy": deepcopy(
            blueprint["staged_eda_policy"]
        ),
        "frozen_generic_analysis_recipe": deepcopy(
            blueprint["generic_analysis_recipe"]
        ),
        "data_access_policy": {
            "schema_version": "data_access_policy.v1",
            "mode": "USER_PROVIDED_LOCAL_ONLY",
            "network_access": False,
            "remote_fetch": False,
            "allowed_inputs": [
                "approved_user_provided_local_files",
                "approved_derived_local_artifacts",
            ],
            "when_data_is_missing": "REQUEST_USER",
        },
        "tasks": tasks,
        "deliverables": deepcopy(blueprint["deliverables"]),
        "trace_requirements": {
            "preserve_source_ids": True,
            "record_provenance_status": True,
            "record_row_counts": True,
            "record_join_coverage": True,
        },
        "executor_status": "WAITING_FOR_EXECUTOR",
    }
    execution_errors = validate_execution(payload)
    if execution_errors:
        raise ValueError(
            "GENERATED_EXECUTION_INVALID:" + ",".join(execution_errors)
        )
    return payload


def _write_json(payload: dict[str, Any], output: Path | None) -> None:
    serialized = json.dumps(
        payload, ensure_ascii=False, indent=2, sort_keys=True
    ) + "\n"
    if output is None:
        sys.stdout.write(serialized)
    else:
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(serialized, encoding="utf-8")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Build an approved analysis_execution_request.v1."
    )
    parser.add_argument("blueprint", type=Path)
    parser.add_argument("--approved-by", required=True)
    parser.add_argument("--output", type=Path)
    return parser


def main(argv: Iterable[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        blueprint = _load_json(args.blueprint)
        payload = build_execution_request(blueprint, args.approved_by)
        _write_json(payload, args.output)
        return 0
    except Exception as exc:
        error = {
            "valid": False,
            "errors": [f"{type(exc).__name__}:{exc}"],
        }
        sys.stderr.write(
            json.dumps(error, ensure_ascii=False, indent=2, sort_keys=True)
            + "\n"
        )
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
