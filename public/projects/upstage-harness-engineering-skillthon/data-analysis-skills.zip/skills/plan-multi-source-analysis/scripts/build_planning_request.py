#!/usr/bin/env python3
"""Build a deterministic planning request from run-specific local settings."""

from __future__ import annotations

import argparse
from copy import deepcopy
import json
from pathlib import Path
import sys
from typing import Any, Iterable

from validate_contract import validate_request


SETTINGS_SCHEMA = "analysis_planning_settings.v1"
REQUEST_SCHEMA = "analysis_planning_request.v1"
REQUEST_FIELDS = {
    "request_id",
    "question",
    "sources",
    "variable_metadata_overrides",
    "analysis_focus",
    "preferences",
}


def _load_json(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(payload, dict):
        raise ValueError("TOP_LEVEL_JSON_MUST_BE_OBJECT")
    return payload


def build_request(settings: dict[str, Any]) -> dict[str, Any]:
    if settings.get("schema_version") != SETTINGS_SCHEMA:
        raise ValueError(f"EXPECTED_SCHEMA:{SETTINGS_SCHEMA}")
    unknown = set(settings) - {"schema_version", *REQUEST_FIELDS}
    if unknown:
        raise ValueError(
            "PLANNING_SETTINGS_UNKNOWN_FIELDS:" + ",".join(sorted(unknown))
        )
    payload = {
        "schema_version": REQUEST_SCHEMA,
        **{
            field: deepcopy(settings[field])
            for field in sorted(REQUEST_FIELDS)
            if field in settings
        },
    }
    errors = validate_request(payload)
    if errors:
        raise ValueError("GENERATED_REQUEST_INVALID:" + ",".join(errors))
    return payload


def _write_json(payload: dict[str, Any], output: Path | None) -> None:
    serialized = json.dumps(
        payload, ensure_ascii=False, indent=2, sort_keys=True
    ) + "\n"
    if output is None:
        sys.stdout.write(serialized)
        return
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(serialized, encoding="utf-8")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Build analysis_planning_request.v1 from run-specific local settings."
        )
    )
    parser.add_argument("settings", type=Path)
    parser.add_argument("--output", type=Path)
    return parser


def main(argv: Iterable[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        _write_json(build_request(_load_json(args.settings)), args.output)
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        sys.stderr.write(str(exc) + "\n")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
