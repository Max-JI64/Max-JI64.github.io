#!/usr/bin/env python3
"""Validate planner request, blueprint, and approved execution contracts."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys
from typing import Any, Callable, Iterable

from analysis_focus_contract import (
    validate_analysis_focus,
    validate_generic_analysis_recipe,
    validate_metadata_overrides,
    validate_staged_eda_policy,
)


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")


REQUEST_SCHEMA = "analysis_planning_request.v1"
SOURCE_INVENTORY_SCHEMA = "source_inventory.v1"
BLUEPRINT_SCHEMA = "analysis_blueprint.v1"
EXECUTION_SCHEMA = "analysis_execution_request.v1"
PREPARATION_PLAN_SCHEMA = "data_preparation_plan.v1"
VARIABLE_INVENTORY_SCHEMA = "variable_inventory.v1"
PREPARATION_AUDITS = {
    "unit_conversion_audit",
    "temporal_alignment_audit",
    "geography_key_alignment_audit",
    "grain_cardinality_resolution",
}
SUPPORTED_FORMATS = {
    "csv",
    "tsv",
    "xlsx",
    "json",
}
BLUEPRINT_STATUSES = {
    "NEEDS_SOURCE_INFO",
    "NEEDS_VARIABLE_CONFIRMATION",
    "NEEDS_QUESTION_SELECTION",
    "READY_FOR_APPROVAL",
    "BLOCKED",
}
SEMANTIC_ROLES = {
    "IDENTIFIER", "PERSON_NAME", "ADDRESS", "EMAIL", "PHONE_NUMBER",
    "FREE_TEXT", "NOMINAL_CATEGORY", "ORDINAL_CATEGORY", "TEMPORAL",
    "GEOGRAPHIC", "QUANTITATIVE_MEASURE", "UNKNOWN",
}
MEASUREMENT_SCALES = {
    "NOMINAL", "ORDINAL", "INTERVAL", "RATIO", "NOT_APPLICABLE", "UNKNOWN",
}
VARIABLE_ANALYSIS_ROLES = {
    "JOIN_KEY", "MEASURE", "GROUP", "TIME_AXIS", "GEO_AXIS",
    "QUALITY_ONLY", "EXCLUDED", "UNKNOWN",
}
VARIABLE_STATUSES = {
    "AUTO_CONFIDENT", "LLM_SUGGESTED", "NEEDS_USER_CONFIRMATION",
    "USER_CONFIRMED", "UNKNOWN", "EXCLUDED_SENSITIVE",
}
UNSUPPORTED_VARIABLE_ANALYSES = {
    "regression", "prediction", "causal_inference", "text_analysis",
}
ANALYSIS_MODULES = {
    "data_quality",
    "distribution",
    "group_comparison",
    "temporal_pattern",
    "spatial_pattern",
    "association",
    "anomaly_screen",
    "cross_source_consistency",
}
TASK_TYPES = {
    "inspect_table",
    "clean_transform",
    "join_sources",
    "exploratory_analysis",
    "validate_findings",
    "render_report",
}


def _required(
    payload: dict[str, Any],
    fields: Iterable[str],
    errors: list[str],
) -> None:
    for field in fields:
        if field not in payload:
            errors.append(f"MISSING_FIELD:{field}")


def _nonempty_string(value: Any) -> bool:
    return isinstance(value, str) and bool(value.strip())


def _payload_sha256(payload: dict[str, Any]) -> str:
    encoded = json.dumps(
        payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _validate_variable_inventory(
    value: Any,
    source_ids: set[str],
    errors: list[str],
    *,
    prefix: str = "",
) -> dict[tuple[str, str], list[dict[str, Any]]]:
    label = f"{prefix}VARIABLE_INVENTORY"
    if not isinstance(value, dict):
        errors.append(f"{label}_MUST_BE_OBJECT")
        return {}
    if value.get("schema_version") != VARIABLE_INVENTORY_SCHEMA:
        errors.append(f"{label}_EXPECTED_SCHEMA:{VARIABLE_INVENTORY_SCHEMA}")
    if value.get("status") not in {"READY", "NEEDS_USER_CONFIRMATION"}:
        errors.append(f"{label}_INVALID_STATUS")
    variables = value.get("variables")
    if not isinstance(variables, list):
        errors.append(f"{label}_VARIABLES_MUST_BE_LIST")
        variables = []
    ids: set[str] = set()
    by_table: dict[tuple[str, str], list[dict[str, Any]]] = {}
    for index, variable in enumerate(variables):
        if not isinstance(variable, dict):
            errors.append(f"{label}_ENTRY_NOT_OBJECT:{index}")
            continue
        variable_id = variable.get("variable_id")
        source_id = variable.get("source_id")
        table_id = variable.get("table_id")
        if not _nonempty_string(variable_id) or variable_id in ids:
            errors.append(f"{label}_INVALID_OR_DUPLICATE_ID:{variable_id}")
        else:
            ids.add(variable_id)
        if source_id not in source_ids or not _nonempty_string(table_id):
            errors.append(f"{label}_INVALID_OWNERSHIP:{variable_id}")
        if not _nonempty_string(variable.get("source_column")) or not _nonempty_string(
            variable.get("prepared_column")
        ):
            errors.append(f"{label}_COLUMN_NAMES_REQUIRED:{variable_id}")
        if variable.get("semantic_role") not in SEMANTIC_ROLES:
            errors.append(f"{label}_INVALID_SEMANTIC_ROLE:{variable_id}")
        if variable.get("measurement_scale") not in MEASUREMENT_SCALES:
            errors.append(f"{label}_INVALID_MEASUREMENT_SCALE:{variable_id}")
        roles = variable.get("analysis_roles")
        if (
            not isinstance(roles, list)
            or not roles
            or any(role not in VARIABLE_ANALYSIS_ROLES for role in roles)
        ):
            errors.append(f"{label}_INVALID_ANALYSIS_ROLES:{variable_id}")
        status = variable.get("status")
        if status not in VARIABLE_STATUSES:
            errors.append(f"{label}_INVALID_VARIABLE_STATUS:{variable_id}")
        confidence = variable.get("confidence")
        if (
            not isinstance(confidence, (int, float))
            or isinstance(confidence, bool)
            or not 0 <= confidence <= 1
        ):
            errors.append(f"{label}_INVALID_CONFIDENCE:{variable_id}")
        evidence = variable.get("evidence")
        if (
            not isinstance(evidence, list)
            or not evidence
            or not all(_nonempty_string(item) for item in evidence)
        ):
            errors.append(f"{label}_EVIDENCE_REQUIRED:{variable_id}")
        allowed = variable.get("allowed_analyses")
        prohibited = variable.get("prohibited_analyses")
        if not isinstance(allowed, list) or not isinstance(prohibited, list):
            errors.append(f"{label}_ANALYSIS_POLICY_REQUIRED:{variable_id}")
        else:
            if set(allowed) & set(prohibited):
                errors.append(f"{label}_POLICY_OVERLAP:{variable_id}")
            if not UNSUPPORTED_VARIABLE_ANALYSES <= set(prohibited):
                errors.append(f"{label}_UNSUPPORTED_ANALYSIS_NOT_BLOCKED:{variable_id}")
        role = variable.get("semantic_role")
        if role == "QUANTITATIVE_MEASURE" and "MEASURE" not in (roles or []):
            errors.append(f"{label}_MEASURE_ROLE_MISMATCH:{variable_id}")
        if role in {"PERSON_NAME", "ADDRESS", "EMAIL", "PHONE_NUMBER"} and (
            set(roles or []) & {"MEASURE", "GROUP"}
        ):
            errors.append(f"{label}_SENSITIVE_ROLE_EXPOSED:{variable_id}")
        by_table.setdefault((str(source_id), str(table_id)), []).append(variable)
    requests = value.get("confirmation_requests")
    if not isinstance(requests, list):
        errors.append(f"{label}_CONFIRMATION_REQUESTS_MUST_BE_LIST")
        requests = []
    requested_ids = {
        item.get("variable_id") for item in requests if isinstance(item, dict)
    }
    unresolved_ids = {
        item.get("variable_id") for item in variables
        if isinstance(item, dict)
        and item.get("status") == "NEEDS_USER_CONFIRMATION"
    }
    if requested_ids != unresolved_ids:
        errors.append(f"{label}_CONFIRMATION_REQUEST_MISMATCH")
    expected_status = "NEEDS_USER_CONFIRMATION" if unresolved_ids else "READY"
    if value.get("status") != expected_status:
        errors.append(f"{label}_STATUS_CONFIRMATION_MISMATCH")
    return by_table


def _validate_preparation_plan(
    plan: Any,
    source_ids: set[str],
    errors: list[str],
    *,
    prefix: str = "",
    enforce_mvp_limits: bool = False,
    variable_by_table: dict[tuple[str, str], list[dict[str, Any]]] | None = None,
) -> dict[str, dict[str, Any]]:
    label = f"{prefix}PREPARATION_PLAN"
    if not isinstance(plan, dict):
        errors.append(f"{label}_MUST_BE_OBJECT")
        return {}
    if plan.get("schema_version") != PREPARATION_PLAN_SCHEMA:
        errors.append(
            f"{label}_EXPECTED_SCHEMA:{PREPARATION_PLAN_SCHEMA}"
        )
    sources = plan.get("sources")
    if not isinstance(sources, list) or not sources:
        errors.append(f"{label}_SOURCES_MUST_BE_NONEMPTY_LIST")
        sources = []
    if enforce_mvp_limits and len(sources) > 3:
        errors.append(f"{label}_UNSUPPORTED_SOURCE_COUNT_MVP")
    by_id: dict[str, dict[str, Any]] = {}
    for index, source in enumerate(sources):
        if not isinstance(source, dict):
            errors.append(f"{label}_SOURCE_NOT_OBJECT:{index}")
            continue
        source_id = source.get("source_id")
        if not _nonempty_string(source_id):
            errors.append(f"{label}_SOURCE_REQUIRES_ID:{index}")
            continue
        if source_id in by_id:
            errors.append(f"{label}_DUPLICATE_SOURCE:{source_id}")
        by_id[source_id] = source
        if source_id not in source_ids:
            errors.append(f"{label}_UNKNOWN_SOURCE:{source_id}")
        if not _nonempty_string(source.get("location")):
            errors.append(f"{label}_SOURCE_REQUIRES_LOCATION:{source_id}")
        if not _nonempty_string(source.get("format")):
            errors.append(f"{label}_SOURCE_REQUIRES_FORMAT:{source_id}")
        tables = source.get("tables")
        if not isinstance(tables, list):
            errors.append(f"{label}_TABLES_MUST_BE_LIST:{source_id}")
            continue
        for table_index, table in enumerate(tables):
            if not isinstance(table, dict):
                errors.append(
                    f"{label}_TABLE_NOT_OBJECT:{source_id}:{table_index}"
                )
                continue
            table_id = table.get("table_id")
            if not _nonempty_string(table_id):
                errors.append(
                    f"{label}_TABLE_REQUIRES_ID:{source_id}:{table_index}"
                )
            transformations = table.get("approved_transformations")
            if not isinstance(transformations, list) or len(transformations) != 2:
                errors.append(
                    f"{label}_REQUIRES_CANONICAL_TRANSFORMS:"
                    f"{source_id}:{table_id}"
                )
                continue
            operations = [
                item.get("operation") if isinstance(item, dict) else None
                for item in transformations
            ]
            if operations != ["normalize_columns", "coerce_types"]:
                errors.append(
                    f"{label}_UNAPPROVED_TRANSFORMATION:"
                    f"{source_id}:{table_id}"
                )
            key_columns = table.get("key_columns")
            if not isinstance(key_columns, list) or not all(
                _nonempty_string(value) for value in key_columns
            ):
                errors.append(
                    f"{label}_INVALID_KEY_COLUMNS:{source_id}:{table_id}"
                )
            for operation in transformations:
                if not isinstance(operation, dict) or not _nonempty_string(
                    operation.get("operation_id")
                ):
                    errors.append(
                        f"{label}_TRANSFORMATION_REQUIRES_ID:"
                        f"{source_id}:{table_id}"
                    )
            if variable_by_table is not None:
                metadata_keys = (
                    "variable_id",
                    "source_column",
                    "prepared_column",
                    "physical_type",
                    "semantic_role",
                    "measurement_scale",
                    "analysis_roles",
                    "unit",
                    "status",
                    "allowed_analyses",
                    "prohibited_analyses",
                )
                expected_metadata = [
                    {
                        key: variable.get(key)
                        for key in metadata_keys
                    }
                    for variable in sorted(
                        variable_by_table.get(
                            (str(source_id), str(table_id)), []
                        ),
                        key=lambda item: str(item.get("variable_id")),
                    )
                ]
                if table.get("variable_metadata") != expected_metadata:
                    errors.append(
                        f"{label}_VARIABLE_METADATA_NOT_FROZEN:"
                        f"{source_id}:{table_id}"
                    )
    join_output = plan.get("join_output")
    if not isinstance(join_output, dict):
        errors.append(f"{label}_JOIN_OUTPUT_MUST_BE_OBJECT")
    else:
        if join_output.get("mode") != "INNER":
            errors.append(f"{label}_JOIN_MODE_MUST_BE_INNER")
        if join_output.get("prefix_non_key_columns") is not True:
            errors.append(f"{label}_MUST_PREFIX_NON_KEY_COLUMNS")
    audits = plan.get("required_audits")
    if not isinstance(audits, list) or not all(
        audit in PREPARATION_AUDITS for audit in audits
    ):
        errors.append(f"{label}_INVALID_REQUIRED_AUDITS")
    limits = plan.get("mvp_limits")
    if (
        not isinstance(limits, dict)
        or limits.get("formats") != ["csv", "tsv"]
        or limits.get("maximum_sources") != 3
    ):
        errors.append(f"{label}_INVALID_MVP_LIMITS")
    return by_id


def validate_request(payload: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    if payload.get("schema_version") != REQUEST_SCHEMA:
        errors.append(f"EXPECTED_SCHEMA:{REQUEST_SCHEMA}")
    _required(payload, ("request_id", "sources"), errors)
    if not _nonempty_string(payload.get("request_id")):
        errors.append("INVALID_REQUEST_ID")
    question = payload.get("question")
    if question is not None and not _nonempty_string(question):
        errors.append("QUESTION_MUST_BE_NULL_OR_NONEMPTY_STRING")
    sources = payload.get("sources")
    if not isinstance(sources, list) or not sources:
        errors.append("SOURCES_MUST_BE_NONEMPTY_LIST")
        return errors
    source_ids: list[str] = []
    for index, source in enumerate(sources):
        if not isinstance(source, dict):
            errors.append(f"SOURCE_NOT_OBJECT:{index}")
            continue
        source_id = source.get("source_id")
        if not _nonempty_string(source_id):
            errors.append(f"INVALID_SOURCE_ID:{index}")
        else:
            source_ids.append(source_id)
        if not _nonempty_string(source.get("location")):
            errors.append(f"MISSING_SOURCE_LOCATION:{source_id or index}")
        fmt = source.get("format")
        if fmt is not None and str(fmt).lower() not in SUPPORTED_FORMATS:
            errors.append(f"UNSUPPORTED_SOURCE_FORMAT:{source_id or index}:{fmt}")
        for field in (
            "title",
            "publisher",
            "source_url",
            "license",
            "provenance_note",
        ):
            if (
                field in source
                and source[field] is not None
                and not isinstance(source[field], str)
            ):
                errors.append(
                    f"INVALID_{field.upper()}:{source_id or index}"
                )
        grain = source.get("declared_grain")
        if grain is not None and (
            not isinstance(grain, list)
            or not all(_nonempty_string(item) for item in grain)
        ):
            errors.append(f"INVALID_DECLARED_GRAIN:{source_id or index}")
        column_units = source.get("column_units")
        if column_units is not None and (
            not isinstance(column_units, dict)
            or not all(
                _nonempty_string(key) and _nonempty_string(value)
                for key, value in column_units.items()
            )
        ):
            errors.append(f"INVALID_COLUMN_UNITS:{source_id or index}")
        for field in ("periodicity", "time_zone"):
            if field in source and source[field] is not None and not _nonempty_string(
                source[field]
            ):
                errors.append(
                    f"INVALID_{field.upper()}:{source_id or index}"
                )
        dataset_structure = source.get("dataset_structure")
        if dataset_structure is not None:
            if not isinstance(dataset_structure, dict):
                errors.append(
                    f"DATASET_STRUCTURE_MUST_BE_OBJECT:{source_id or index}"
                )
            else:
                for field in (
                    "observation_unit",
                    "time_granularity",
                    "time_field_meaning",
                    "comparison_notes",
                ):
                    if (
                        field in dataset_structure
                        and dataset_structure[field] is not None
                        and not _nonempty_string(dataset_structure[field])
                    ):
                        errors.append(
                            f"INVALID_DATASET_STRUCTURE_{field.upper()}:"
                            f"{source_id or index}"
                        )
                measure_time_basis = dataset_structure.get(
                    "measure_time_basis"
                )
                if measure_time_basis is not None and (
                    not isinstance(measure_time_basis, dict)
                    or not all(
                        _nonempty_string(key) and _nonempty_string(value)
                        for key, value in measure_time_basis.items()
                    )
                ):
                    errors.append(
                        "INVALID_DATASET_STRUCTURE_MEASURE_TIME_BASIS:"
                        f"{source_id or index}"
                    )
        geography = source.get("geography")
        if geography is not None:
            if not isinstance(geography, dict):
                errors.append(f"GEOGRAPHY_MUST_BE_OBJECT:{source_id or index}")
            else:
                for field in ("level", "code_system"):
                    if not _nonempty_string(geography.get(field)):
                        errors.append(
                            f"GEOGRAPHY_REQUIRES_{field.upper()}:"
                            f"{source_id or index}"
                        )
                boundary_version = geography.get("boundary_version")
                if boundary_version is not None and not _nonempty_string(
                    boundary_version
                ):
                    errors.append(
                        f"INVALID_GEOGRAPHY_BOUNDARY_VERSION:"
                        f"{source_id or index}"
                    )
    if len(source_ids) != len(set(source_ids)):
        errors.append("DUPLICATE_SOURCE_ID")
    preferences = payload.get("preferences", {})
    if preferences and not isinstance(preferences, dict):
        errors.append("PREFERENCES_MUST_BE_OBJECT")
    else:
        if preferences.get("approval_required") is False:
            errors.append("APPROVAL_REQUIRED_MUST_NOT_BE_FALSE")
        max_candidates = preferences.get("max_question_candidates")
        if max_candidates is not None and (
            not isinstance(max_candidates, int)
            or isinstance(max_candidates, bool)
            or not 1 <= max_candidates <= 3
        ):
            errors.append("MAX_QUESTION_CANDIDATES_MUST_BE_1_TO_3")
    errors.extend(
        validate_metadata_overrides(payload.get("variable_metadata_overrides"))
    )
    errors.extend(validate_analysis_focus(payload.get("analysis_focus")))
    return errors


def validate_source_inventory(payload: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    if payload.get("schema_version") != SOURCE_INVENTORY_SCHEMA:
        errors.append(f"EXPECTED_SCHEMA:{SOURCE_INVENTORY_SCHEMA}")
    if not _nonempty_string(payload.get("request_id")):
        errors.append("SOURCE_INVENTORY_REQUIRES_REQUEST_ID")
    if payload.get("status") not in {
        "READY_FOR_PLANNING",
        "NEEDS_SOURCE_INFO",
        "BLOCKED",
    }:
        errors.append("INVALID_SOURCE_INVENTORY_STATUS")
    sources = payload.get("sources")
    if not isinstance(sources, list) or not sources:
        errors.append("SOURCE_INVENTORY_REQUIRES_SOURCES")
        sources = []
    source_ids = [
        str(source.get("source_id"))
        for source in sources
        if isinstance(source, dict) and _nonempty_string(source.get("source_id"))
    ]
    if len(source_ids) != len(sources):
        errors.append("SOURCE_INVENTORY_INVALID_SOURCE_ENTRY")
    if len(source_ids) != len(set(source_ids)):
        errors.append("SOURCE_INVENTORY_DUPLICATE_SOURCE_ID")
    tables = payload.get("tables")
    if not isinstance(tables, list) or not tables:
        errors.append("SOURCE_INVENTORY_REQUIRES_TABLES")
        tables = []
    table_ids: list[tuple[str, str]] = []
    for index, table in enumerate(tables):
        if not isinstance(table, dict):
            errors.append(f"SOURCE_INVENTORY_TABLE_NOT_OBJECT:{index}")
            continue
        source_id = table.get("source_id")
        table_id = table.get("table_id")
        if source_id not in source_ids or not _nonempty_string(table_id):
            errors.append(f"SOURCE_INVENTORY_INVALID_TABLE_REFERENCE:{index}")
            continue
        table_ids.append((str(source_id), str(table_id)))
        columns = table.get("columns")
        if not isinstance(columns, list) or not columns:
            errors.append(f"SOURCE_INVENTORY_TABLE_REQUIRES_COLUMNS:{index}")
        elif any(
            not isinstance(column, dict)
            or not _nonempty_string(column.get("name"))
            for column in columns
        ):
            errors.append(f"SOURCE_INVENTORY_INVALID_COLUMN:{index}")
    if len(table_ids) != len(set(table_ids)):
        errors.append("SOURCE_INVENTORY_DUPLICATE_TABLE_ID")
    requests = payload.get("user_data_requests")
    if not isinstance(requests, list):
        errors.append("SOURCE_INVENTORY_USER_DATA_REQUESTS_MUST_BE_LIST")
    confirmations = payload.get("structure_confirmation_requests")
    if not isinstance(confirmations, list):
        errors.append(
            "SOURCE_INVENTORY_STRUCTURE_CONFIRMATIONS_MUST_BE_LIST"
        )
    return errors


def validate_variable_inventory(payload: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    variables = payload.get("variables")
    source_ids = {
        str(item.get("source_id"))
        for item in variables or []
        if isinstance(item, dict) and _nonempty_string(item.get("source_id"))
    } if isinstance(variables, list) else set()
    _validate_variable_inventory(payload, source_ids, errors)
    status = payload.get("status")
    requests = payload.get("confirmation_requests")
    if status not in {"READY", "NEEDS_USER_CONFIRMATION"}:
        errors.append("INVALID_VARIABLE_INVENTORY_STATUS")
    if status == "READY" and requests != []:
        errors.append("READY_VARIABLE_INVENTORY_HAS_CONFIRMATION_REQUESTS")
    if status == "NEEDS_USER_CONFIRMATION" and (
        not isinstance(requests, list) or not requests
    ):
        errors.append("PENDING_VARIABLE_INVENTORY_REQUIRES_CONFIRMATIONS")
    return errors


def _validate_question(
    question: Any,
    prefix: str,
    errors: list[str],
) -> None:
    if not isinstance(question, dict):
        errors.append(f"{prefix}_MUST_BE_OBJECT")
        return
    for field in ("question_id", "text"):
        if not _nonempty_string(question.get(field)):
            errors.append(f"{prefix}_MISSING_{field.upper()}")
    modules = question.get("module_ids", [])
    if modules and (
        not isinstance(modules, list)
        or any(module not in ANALYSIS_MODULES for module in modules)
    ):
        errors.append(f"{prefix}_HAS_UNSUPPORTED_MODULE")


def _validate_integrated_join(
    join: dict[str, Any], index: int, errors: list[str], prefix: str = ""
) -> None:
    label = f"{prefix}JOIN_{index}"
    if join.get("cardinality") != "ONE_TO_ONE":
        errors.append(f"{label}_MUST_BE_ONE_TO_ONE")
    if join.get("safety") != "SAFE_CANDIDATE":
        errors.append(f"{label}_MUST_BE_SAFE_CANDIDATE")
    overlap = join.get("sampled_key_overlap")
    if not isinstance(overlap, (int, float)) or isinstance(overlap, bool):
        errors.append(f"{label}_REQUIRES_KEY_OVERLAP")
    elif overlap <= 0:
        errors.append(f"{label}_ZERO_KEY_OVERLAP_BLOCKED")
    if join.get("unit_conflicts"):
        errors.append(f"{label}_HAS_KEY_UNIT_CONFLICT")
    if join.get("measure_unit_conflicts"):
        errors.append(f"{label}_HAS_MEASURE_UNIT_CONFLICT")
    if join.get("alignment_issues"):
        errors.append(f"{label}_HAS_ALIGNMENT_ISSUE")


def validate_blueprint(payload: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    if payload.get("schema_version") != BLUEPRINT_SCHEMA:
        errors.append(f"EXPECTED_SCHEMA:{BLUEPRINT_SCHEMA}")
    _required(
        payload,
        (
            "blueprint_id",
            "request_id",
            "status",
            "source_inventory",
            "preparation_plan",
            "join_plan",
            "candidate_questions",
            "selected_question",
            "analysis_steps",
            "validation_plan",
            "analysis_focus",
            "staged_eda_policy",
            "generic_analysis_recipe",
            "deliverables",
            "additional_data_requests",
            "limitations",
            "approval",
        ),
        errors,
    )
    status = payload.get("status")
    if status not in BLUEPRINT_STATUSES:
        errors.append(f"INVALID_BLUEPRINT_STATUS:{status}")
    if "analysis_execution_request" in payload:
        errors.append("PREAPPROVAL_BLUEPRINT_MUST_NOT_EMBED_EXECUTION_REQUEST")
    approval = payload.get("approval")
    if not isinstance(approval, dict):
        errors.append("APPROVAL_MUST_BE_OBJECT")
    else:
        if approval.get("status") != "PENDING":
            errors.append("BLUEPRINT_APPROVAL_STATUS_MUST_BE_PENDING")
        if approval.get("required") is not True:
            errors.append("BLUEPRINT_APPROVAL_REQUIRED_MUST_BE_TRUE")

    source_inventory = payload.get("source_inventory")
    source_ids: set[str] = set()
    if not isinstance(source_inventory, list) or not source_inventory:
        errors.append("SOURCE_INVENTORY_MUST_BE_NONEMPTY_LIST")
    else:
        for index, source in enumerate(source_inventory):
            if not isinstance(source, dict) or not _nonempty_string(
                source.get("source_id")
            ):
                errors.append(f"INVALID_SOURCE_INVENTORY_ENTRY:{index}")
                continue
            source_id = source["source_id"]
            if source_id in source_ids:
                errors.append(f"DUPLICATE_SOURCE_INVENTORY_ID:{source_id}")
            source_ids.add(source_id)
            missing_provenance = source.get("missing_provenance", [])
            if not isinstance(missing_provenance, list) or not all(
                _nonempty_string(field) for field in missing_provenance
            ):
                errors.append(
                    f"INVALID_MISSING_PROVENANCE:{source_id}"
                )
            provenance_status = source.get("provenance_status")
            if provenance_status is not None and provenance_status not in {
                "COMPLETE",
                "PARTIAL",
                "UNKNOWN",
            }:
                errors.append(f"INVALID_PROVENANCE_STATUS:{source_id}")
            provenance_note = source.get("provenance_note")
            if provenance_note is not None and not _nonempty_string(
                provenance_note
            ):
                errors.append(f"INVALID_PROVENANCE_NOTE:{source_id}")

    variable_inventory = payload.get("variable_inventory")
    variable_by_table: dict[tuple[str, str], list[dict[str, Any]]] | None = None
    if isinstance(variable_inventory, dict):
        variable_by_table = _validate_variable_inventory(
            variable_inventory, source_ids, errors
        )
        if payload.get("variable_inventory_sha256") != _payload_sha256(
            variable_inventory
        ):
            errors.append("VARIABLE_INVENTORY_SHA256_MISMATCH")
        if payload.get("variable_confirmation_requests") != (
            variable_inventory.get("confirmation_requests")
        ):
            errors.append("VARIABLE_CONFIRMATION_REQUESTS_NOT_FROZEN")
        if variable_inventory.get("request_id") != payload.get("request_id"):
            errors.append("VARIABLE_INVENTORY_REQUEST_ID_MISMATCH")

    analysis_focus = payload.get("analysis_focus")
    errors.extend(validate_analysis_focus(analysis_focus, resolved=True))
    errors.extend(validate_staged_eda_policy(payload.get("staged_eda_policy")))
    errors.extend(
        validate_generic_analysis_recipe(payload.get("generic_analysis_recipe"))
    )
    if isinstance(analysis_focus, dict):
        requested_modules = analysis_focus.get("requested_modules")
        selected_modules = (
            payload.get("selected_question", {}).get("module_ids")
            if isinstance(payload.get("selected_question"), dict)
            else None
        )
        if requested_modules and selected_modules != requested_modules:
            errors.append("SELECTED_MODULES_DO_NOT_MATCH_ANALYSIS_FOCUS")
        policy = payload.get("staged_eda_policy")
        if (
            isinstance(policy, dict)
            and policy.get("requested_modules") != requested_modules
        ):
            errors.append("STAGED_POLICY_MODULES_DO_NOT_MATCH_ANALYSIS_FOCUS")
        recipe = payload.get("generic_analysis_recipe")
        if isinstance(recipe, dict):
            if recipe.get("derived_rules") != analysis_focus.get(
                "derived_rules"
            ):
                errors.append("RECIPE_DERIVED_RULES_NOT_FROZEN")
            if recipe.get("sensitivity_pairs") != analysis_focus.get(
                "sensitivity_pairs"
            ):
                errors.append("RECIPE_SENSITIVITY_PAIRS_NOT_FROZEN")
            if recipe.get("association_pairs") != analysis_focus.get(
                "association_pairs"
            ):
                errors.append("RECIPE_ASSOCIATION_PAIRS_NOT_FROZEN")
            if recipe.get(
                "derived_group_comparisons"
            ) != analysis_focus.get("derived_group_comparisons", []):
                errors.append(
                    "RECIPE_DERIVED_GROUP_COMPARISONS_NOT_FROZEN"
                )
            spatial = recipe.get("spatial_baseline")
            if isinstance(spatial, dict):
                if spatial.get("geography_axis") != analysis_focus.get(
                    "geography_axis"
                ):
                    errors.append("RECIPE_SPATIAL_AXIS_NOT_FROZEN")
                if spatial.get("geography_label") != analysis_focus.get(
                    "geography_label", {}
                ):
                    errors.append("RECIPE_SPATIAL_LABEL_NOT_FROZEN")
                if spatial.get("primary_measure") != analysis_focus.get(
                    "primary_measure"
                ):
                    errors.append("RECIPE_SPATIAL_MEASURE_NOT_FROZEN")

    _validate_preparation_plan(
        payload.get("preparation_plan"),
        source_ids,
        errors,
        variable_by_table=variable_by_table,
    )

    join_plan = payload.get("join_plan")
    if not isinstance(join_plan, dict):
        errors.append("JOIN_PLAN_MUST_BE_OBJECT")
    else:
        strategy = join_plan.get("strategy")
        if strategy not in {
            "INTEGRATED",
            "SEPARATE",
            "NO_JOIN_REQUIRED",
        }:
            errors.append(f"INVALID_JOIN_STRATEGY:{strategy}")
        joins = join_plan.get("joins", [])
        if not isinstance(joins, list):
            errors.append("JOIN_PLAN_JOINS_MUST_BE_LIST")
            joins = []
        if strategy == "INTEGRATED" and not joins:
            errors.append("INTEGRATED_PLAN_REQUIRES_JOIN")
        if strategy != "INTEGRATED" and joins:
            errors.append("NON_INTEGRATED_PLAN_MUST_NOT_HAVE_EXECUTABLE_JOINS")
        risks = join_plan.get("risks", [])
        if not isinstance(risks, list):
            errors.append("JOIN_PLAN_RISKS_MUST_BE_LIST")
            risks = []
        if strategy == "INTEGRATED" and any(
            str(risk).startswith(
                (
                    "UNSAFE_JOIN:",
                    "ZERO_KEY_OVERLAP",
                    "GEOGRAPHY_ALIGNMENT_MISMATCH",
                    "TEMPORAL_GRAIN_MISMATCH",
                    "TIME_ZONE_ALIGNMENT_MISMATCH",
                    "JOIN_KEY_UNIT_CONFLICT:",
                    "UNIT_ALIGNMENT_REQUIRED:",
                )
            )
            for risk in risks
        ):
            errors.append("INTEGRATED_PLAN_HAS_BLOCKING_ALIGNMENT_RISK")
        for index, join in enumerate(joins):
            if not isinstance(join, dict):
                errors.append(f"JOIN_NOT_OBJECT:{index}")
                continue
            for field in ("left_source_id", "right_source_id"):
                if join.get(field) not in source_ids:
                    errors.append(
                        f"JOIN_REFERENCES_UNKNOWN_SOURCE:{index}:{field}"
                    )
            keys = join.get("keys")
            if not isinstance(keys, list) or not keys or not all(
                _nonempty_string(key) for key in keys
            ):
                errors.append(f"JOIN_REQUIRES_KEYS:{index}")
            if join.get("cardinality") not in {
                "ONE_TO_ONE",
                "ONE_TO_MANY",
                "MANY_TO_ONE",
                "MANY_TO_MANY",
                "UNKNOWN",
            }:
                errors.append(f"INVALID_JOIN_CARDINALITY:{index}")
            if join.get("safety") not in {
                "SAFE_CANDIDATE",
                "REQUIRES_REVIEW",
                "BLOCKED",
            }:
                errors.append(f"INVALID_JOIN_SAFETY:{index}")
            if join.get("cardinality") == "MANY_TO_MANY":
                errors.append(f"INTEGRATED_MANY_TO_MANY_JOIN_BLOCKED:{index}")
            if join.get("safety") == "BLOCKED":
                errors.append(f"INTEGRATED_BLOCKED_JOIN:{index}")
            if strategy == "INTEGRATED":
                _validate_integrated_join(join, index, errors)

    candidates = payload.get("candidate_questions")
    if not isinstance(candidates, list):
        errors.append("CANDIDATE_QUESTIONS_MUST_BE_LIST")
        candidates = []
    if len(candidates) > 3:
        errors.append("TOO_MANY_CANDIDATE_QUESTIONS")
    if status in {"NEEDS_SOURCE_INFO", "NEEDS_VARIABLE_CONFIRMATION"} and candidates:
        errors.append("CONFIRMATION_STATUS_REQUIRES_NO_CANDIDATES")
    if status == "NEEDS_SOURCE_INFO":
        confirmations = payload.get("structure_confirmation_requests")
        if not isinstance(confirmations, list) or not any(
            isinstance(item, dict) and item.get("blocking") is True
            for item in confirmations or []
        ):
            errors.append(
                "SOURCE_INFO_STATUS_REQUIRES_BLOCKING_STRUCTURE_CONFIRMATION"
            )
        for field in (
            "selected_question", "analysis_steps", "validation_plan", "deliverables"
        ):
            if payload.get(field) not in ({}, [], None):
                errors.append(
                    f"SOURCE_INFO_STATUS_REQUIRES_EMPTY_{field.upper()}"
                )
    if status == "NEEDS_VARIABLE_CONFIRMATION":
        if (
            not isinstance(variable_inventory, dict)
            or variable_inventory.get("status") != "NEEDS_USER_CONFIRMATION"
        ):
            errors.append("VARIABLE_CONFIRMATION_STATUS_REQUIRES_PENDING_VARIABLES")
        for field in (
            "selected_question", "analysis_steps", "validation_plan", "deliverables"
        ):
            if payload.get(field) not in ({}, [], None):
                errors.append(
                    f"VARIABLE_CONFIRMATION_STATUS_REQUIRES_EMPTY_{field.upper()}"
                )
    elif status != "NEEDS_SOURCE_INFO" and isinstance(variable_inventory, dict) and (
        variable_inventory.get("status") == "NEEDS_USER_CONFIRMATION"
    ):
        errors.append("UNRESOLVED_VARIABLE_CONFIRMATION_MUST_GATE_BLUEPRINT")
    if status == "NEEDS_QUESTION_SELECTION" and not 2 <= len(candidates) <= 3:
        errors.append("QUESTION_SELECTION_REQUIRES_TWO_OR_THREE_CANDIDATES")
    question_ids: list[str] = []
    for index, question in enumerate(candidates):
        _validate_question(question, f"CANDIDATE_{index}", errors)
        if isinstance(question, dict):
            if _nonempty_string(question.get("question_id")):
                question_ids.append(question["question_id"])
            if not _nonempty_string(question.get("rationale")):
                errors.append(f"CANDIDATE_{index}_MISSING_RATIONALE")
            required_sources = question.get("required_source_ids")
            if not isinstance(required_sources, list) or not required_sources:
                errors.append(f"CANDIDATE_{index}_REQUIRES_SOURCES")
            elif any(
                source_id not in source_ids for source_id in required_sources
            ):
                errors.append(
                    f"CANDIDATE_{index}_REFERENCES_UNKNOWN_SOURCE"
                )
            modules = question.get("module_ids")
            if not isinstance(modules, list) or not modules:
                errors.append(f"CANDIDATE_{index}_REQUIRES_MODULES")
            if not _nonempty_string(question.get("feasibility")):
                errors.append(f"CANDIDATE_{index}_MISSING_FEASIBILITY")
            if not isinstance(question.get("risks"), list):
                errors.append(f"CANDIDATE_{index}_RISKS_MUST_BE_LIST")
    if len(question_ids) != len(set(question_ids)):
        errors.append("DUPLICATE_QUESTION_ID")

    selected = payload.get("selected_question")
    if status == "READY_FOR_APPROVAL":
        _validate_question(selected, "SELECTED_QUESTION", errors)
        if isinstance(selected, dict) and question_ids:
            if selected.get("question_id") not in question_ids:
                errors.append("SELECTED_QUESTION_NOT_IN_CANDIDATES")
        if isinstance(selected, dict):
            required_sources = selected.get("required_source_ids", [])
            if any(source_id not in source_ids for source_id in required_sources):
                errors.append("SELECTED_QUESTION_REFERENCES_UNKNOWN_SOURCE")
    elif status in {
        "NEEDS_SOURCE_INFO", "NEEDS_QUESTION_SELECTION",
        "NEEDS_VARIABLE_CONFIRMATION",
    } and selected not in (None, {}):
        errors.append("QUESTION_SELECTION_STATUS_REQUIRES_EMPTY_SELECTION")

    steps = payload.get("analysis_steps")
    if not isinstance(steps, list):
        errors.append("ANALYSIS_STEPS_MUST_BE_LIST")
        steps = []
    step_ids: list[str] = []
    for index, step in enumerate(steps):
        if not isinstance(step, dict):
            errors.append(f"ANALYSIS_STEP_NOT_OBJECT:{index}")
            continue
        if not _nonempty_string(step.get("step_id")):
            errors.append(f"ANALYSIS_STEP_MISSING_ID:{index}")
        else:
            step_ids.append(step["step_id"])
        if step.get("module") not in ANALYSIS_MODULES:
            errors.append(
                f"UNSUPPORTED_ANALYSIS_MODULE:{step.get('module')}"
            )
        if not isinstance(step.get("source_ids"), list) or not step.get(
            "source_ids"
        ):
            errors.append(f"ANALYSIS_STEP_REQUIRES_SOURCES:{index}")
        elif any(
            source_id not in source_ids for source_id in step["source_ids"]
        ):
            errors.append(f"ANALYSIS_STEP_REFERENCES_UNKNOWN_SOURCE:{index}")
        if not _nonempty_string(step.get("purpose")):
            errors.append(f"ANALYSIS_STEP_REQUIRES_PURPOSE:{index}")
        expected_outputs = step.get("expected_outputs")
        if not isinstance(expected_outputs, list) or not expected_outputs or not all(
            _nonempty_string(value) for value in expected_outputs
        ):
            errors.append(f"ANALYSIS_STEP_REQUIRES_EXPECTED_OUTPUTS:{index}")
    if len(step_ids) != len(set(step_ids)):
        errors.append("DUPLICATE_ANALYSIS_STEP_ID")

    if status == "READY_FOR_APPROVAL":
        for field in ("analysis_steps", "validation_plan", "deliverables"):
            value = payload.get(field)
            if not isinstance(value, list) or not value:
                errors.append(f"READY_BLUEPRINT_REQUIRES_{field.upper()}")
    validation_plan = payload.get("validation_plan")
    if isinstance(validation_plan, list):
        for index, check in enumerate(validation_plan):
            if (
                not isinstance(check, dict)
                or not _nonempty_string(check.get("check"))
                or not _nonempty_string(check.get("description"))
            ):
                errors.append(f"INVALID_VALIDATION_CHECK:{index}")
    deliverables = payload.get("deliverables")
    if isinstance(deliverables, list) and not all(
        _nonempty_string(value) for value in deliverables
    ):
        errors.append("DELIVERABLES_MUST_BE_NONEMPTY_STRINGS")
    if not isinstance(payload.get("additional_data_requests"), list):
        errors.append("ADDITIONAL_DATA_REQUESTS_MUST_BE_LIST")
    return errors


def validate_execution(payload: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    raw_tasks = payload.get("tasks")
    uses_staged_eda = any(
        isinstance(task, dict)
        and task.get("task_type") == "exploratory_analysis"
        and isinstance(task.get("inputs"), dict)
        and "staged_eda_policy" in task["inputs"]
        for task in (raw_tasks if isinstance(raw_tasks, list) else [])
    )
    if payload.get("schema_version") != EXECUTION_SCHEMA:
        errors.append(f"EXPECTED_SCHEMA:{EXECUTION_SCHEMA}")
    for forbidden in ("results", "findings", "analysis_results"):
        if forbidden in payload:
            errors.append(f"EXECUTION_REQUEST_MUST_NOT_CONTAIN_{forbidden.upper()}")
    _required(
        payload,
        (
            "execution_id",
            "blueprint_id",
            "approved_question",
            "approval",
            "source_refs",
            "frozen_join_plan",
            "frozen_preparation_plan",
            "frozen_analysis_focus",
            "frozen_staged_eda_policy",
            "frozen_generic_analysis_recipe",
            "tasks",
            "deliverables",
            "trace_requirements",
            "executor_status",
        ),
        errors,
    )
    _validate_question(payload.get("approved_question"), "APPROVED_QUESTION", errors)
    approval = payload.get("approval")
    if not isinstance(approval, dict) or approval.get("status") != "APPROVED":
        errors.append("EXECUTION_REQUIRES_EXPLICIT_APPROVAL")
    elif not _nonempty_string(approval.get("approved_by")):
        errors.append("EXECUTION_REQUIRES_APPROVED_BY")
    if uses_staged_eda:
        data_policy = payload.get("data_access_policy")
        if (
            not isinstance(data_policy, dict)
            or data_policy.get("schema_version") != "data_access_policy.v1"
            or data_policy.get("mode") != "USER_PROVIDED_LOCAL_ONLY"
            or data_policy.get("network_access") is not False
            or data_policy.get("remote_fetch") is not False
            or data_policy.get("when_data_is_missing") != "REQUEST_USER"
        ):
            errors.append("USER_PROVIDED_LOCAL_DATA_POLICY_REQUIRED")
    source_refs = payload.get("source_refs")
    if not isinstance(source_refs, list) or not source_refs or not all(
        _nonempty_string(value) for value in source_refs
    ):
        errors.append("EXECUTION_REQUIRES_SOURCE_REFS")
    source_ref_ids = (
        {value for value in source_refs if isinstance(value, str)}
        if isinstance(source_refs, list)
        else set()
    )
    frozen_variables = payload.get("frozen_variable_inventory")
    frozen_variable_source_ids = {
        str(item.get("source_id"))
        for item in (
            frozen_variables.get("variables", [])
            if isinstance(frozen_variables, dict) else []
        )
        if isinstance(item, dict) and _nonempty_string(item.get("source_id"))
    }
    if (
        isinstance(frozen_variables, dict)
        and not source_ref_ids <= frozen_variable_source_ids
    ):
        errors.append("SOURCE_REFS_NOT_COVERED_BY_FROZEN_VARIABLE_INVENTORY")
    frozen_variable_by_table = None
    if isinstance(frozen_variables, dict):
        frozen_variable_by_table = _validate_variable_inventory(
            frozen_variables,
            frozen_variable_source_ids,
            errors,
            prefix="FROZEN_",
        )
        if frozen_variables.get("status") != "READY":
            errors.append("EXECUTION_REQUIRES_RESOLVED_VARIABLE_INVENTORY")
    frozen_focus = payload.get("frozen_analysis_focus")
    errors.extend(validate_analysis_focus(frozen_focus, resolved=True))
    frozen_policy = payload.get("frozen_staged_eda_policy")
    errors.extend(validate_staged_eda_policy(frozen_policy))
    frozen_recipe = payload.get("frozen_generic_analysis_recipe")
    errors.extend(validate_generic_analysis_recipe(frozen_recipe))
    if isinstance(frozen_focus, dict) and isinstance(frozen_policy, dict):
        if frozen_policy.get("requested_modules") != frozen_focus.get(
            "requested_modules"
        ):
            errors.append(
                "FROZEN_STAGED_POLICY_MODULES_DO_NOT_MATCH_ANALYSIS_FOCUS"
            )
    if isinstance(frozen_focus, dict) and isinstance(frozen_recipe, dict):
        for recipe_field, focus_field, error_code in (
            (
                "derived_rules",
                "derived_rules",
                "FROZEN_RECIPE_DERIVED_RULES_NOT_FROZEN",
            ),
            (
                "sensitivity_pairs",
                "sensitivity_pairs",
                "FROZEN_RECIPE_SENSITIVITY_PAIRS_NOT_FROZEN",
            ),
            (
                "association_pairs",
                "association_pairs",
                "FROZEN_RECIPE_ASSOCIATION_PAIRS_NOT_FROZEN",
            ),
            (
                "derived_group_comparisons",
                "derived_group_comparisons",
                "FROZEN_RECIPE_DERIVED_GROUP_COMPARISONS_NOT_FROZEN",
            ),
        ):
            if frozen_recipe.get(recipe_field) != frozen_focus.get(
                focus_field
            ):
                errors.append(error_code)
        spatial = frozen_recipe.get("spatial_baseline")
        if isinstance(spatial, dict):
            if spatial.get("geography_axis") != frozen_focus.get(
                "geography_axis"
            ):
                errors.append("FROZEN_RECIPE_SPATIAL_AXIS_NOT_FROZEN")
            if spatial.get("geography_label") != frozen_focus.get(
                "geography_label", {}
            ):
                errors.append("FROZEN_RECIPE_SPATIAL_LABEL_NOT_FROZEN")
            if spatial.get("primary_measure") != frozen_focus.get(
                "primary_measure"
            ):
                errors.append("FROZEN_RECIPE_SPATIAL_MEASURE_NOT_FROZEN")
    if payload.get("executor_status") not in {
        "WAITING_FOR_EXECUTOR",
        "READY_TO_DISPATCH",
    }:
        errors.append("INVALID_EXECUTOR_STATUS")
    trace_requirements = payload.get("trace_requirements")
    if not isinstance(trace_requirements, dict):
        errors.append("TRACE_REQUIREMENTS_MUST_BE_OBJECT")
    else:
        for field in (
            "preserve_source_ids",
            "record_provenance_status",
            "record_row_counts",
            "record_join_coverage",
        ):
            if trace_requirements.get(field) is not True:
                errors.append(f"TRACE_REQUIREMENT_MUST_BE_TRUE:{field}")
    frozen_preparation_by_id = _validate_preparation_plan(
        payload.get("frozen_preparation_plan"),
        source_ref_ids,
        errors,
        prefix="FROZEN_",
        variable_by_table=frozen_variable_by_table,
    )
    frozen_join_plan = payload.get("frozen_join_plan")
    if not isinstance(frozen_join_plan, dict):
        errors.append("FROZEN_JOIN_PLAN_MUST_BE_OBJECT")
        frozen_strategy = None
    else:
        frozen_strategy = frozen_join_plan.get("strategy")
        if frozen_strategy not in {
            "INTEGRATED",
            "SEPARATE",
            "NO_JOIN_REQUIRED",
        }:
            errors.append(f"INVALID_FROZEN_JOIN_STRATEGY:{frozen_strategy}")
        frozen_joins = frozen_join_plan.get("joins", [])
        if not isinstance(frozen_joins, list):
            errors.append("FROZEN_JOIN_PLAN_JOINS_MUST_BE_LIST")
            frozen_joins = []
        if frozen_strategy == "INTEGRATED":
            if not frozen_joins:
                errors.append("FROZEN_INTEGRATED_PLAN_REQUIRES_JOIN")
            for index, join in enumerate(frozen_joins):
                if not isinstance(join, dict):
                    errors.append(f"FROZEN_JOIN_NOT_OBJECT:{index}")
                    continue
                _validate_integrated_join(
                    join, index, errors, prefix="FROZEN_"
                )
        elif frozen_joins:
            errors.append("FROZEN_NON_INTEGRATED_PLAN_MUST_NOT_HAVE_JOINS")

    tasks = payload.get("tasks")
    if not isinstance(tasks, list) or not tasks:
        errors.append("EXECUTION_REQUIRES_TASKS")
        tasks = []
    seen: set[str] = set()
    for index, task in enumerate(tasks):
        if not isinstance(task, dict):
            errors.append(f"TASK_NOT_OBJECT:{index}")
            continue
        task_id = task.get("task_id")
        if not _nonempty_string(task_id):
            errors.append(f"TASK_MISSING_ID:{index}")
            continue
        if task_id in seen:
            errors.append(f"DUPLICATE_TASK_ID:{task_id}")
        if task.get("task_type") not in TASK_TYPES:
            errors.append(f"UNSUPPORTED_TASK_TYPE:{task.get('task_type')}")
        if not _nonempty_string(task.get("executor")):
            errors.append(f"TASK_REQUIRES_EXECUTOR:{task_id}")
        if not isinstance(task.get("inputs"), dict):
            errors.append(f"TASK_INPUTS_MUST_BE_OBJECT:{task_id}")
            task_inputs: dict[str, Any] = {}
        else:
            task_inputs = task["inputs"]
        if task.get("task_type") == "clean_transform":
            if task.get("executor") != "prepare-multi-source-data":
                errors.append(
                    f"CLEAN_TRANSFORM_REQUIRES_PREPARATION_EXECUTOR:{task_id}"
                )
            source_id = task_inputs.get("source_id")
            if source_id not in frozen_preparation_by_id:
                errors.append(
                    f"CLEAN_TRANSFORM_REFERENCES_UNPLANNED_SOURCE:{task_id}"
                )
            elif task_inputs.get("preparation_source") != (
                frozen_preparation_by_id[source_id]
            ):
                errors.append(
                    f"CLEAN_TRANSFORM_PLAN_NOT_FROZEN:{task_id}"
                )
        if task.get("task_type") == "join_sources":
            if task.get("executor") != "prepare-multi-source-data":
                errors.append(
                    f"JOIN_REQUIRES_PREPARATION_EXECUTOR:{task_id}"
                )
            frozen_preparation = payload.get("frozen_preparation_plan", {})
            if task_inputs.get("join_plan") != payload.get("frozen_join_plan"):
                errors.append(f"JOIN_TASK_PLAN_NOT_FROZEN:{task_id}")
            if task_inputs.get("join_output") != frozen_preparation.get(
                "join_output"
            ):
                errors.append(f"JOIN_OUTPUT_PLAN_NOT_FROZEN:{task_id}")
            if task_inputs.get("required_audits") != frozen_preparation.get(
                "required_audits"
            ):
                errors.append(f"JOIN_AUDITS_NOT_FROZEN:{task_id}")
        if (
            task.get("task_type") == "exploratory_analysis"
            and isinstance(frozen_variables, dict)
            and uses_staged_eda
        ):
            if task.get("executor") != "run-exploratory-analysis":
                errors.append(f"EDA_REQUIRES_EDA_EXECUTOR:{task_id}")
            if task_inputs.get("variable_inventory") != payload.get(
                "frozen_variable_inventory"
            ):
                errors.append(f"EDA_VARIABLE_INVENTORY_NOT_FROZEN:{task_id}")
            if task_inputs.get("analysis_focus") != frozen_focus:
                errors.append(f"EDA_ANALYSIS_FOCUS_NOT_FROZEN:{task_id}")
            policy = task_inputs.get("staged_eda_policy")
            if policy != frozen_policy:
                errors.append(f"EDA_STAGED_POLICY_NOT_FROZEN:{task_id}")
            recipe = task_inputs.get("generic_analysis_recipe")
            if recipe != frozen_recipe:
                errors.append(
                    f"EDA_GENERIC_ANALYSIS_RECIPE_NOT_FROZEN:{task_id}"
                )
        if task.get("task_type") == "validate_findings" and uses_staged_eda:
            if task.get("executor") != "run-exploratory-analysis":
                errors.append(
                    f"VALIDATION_REQUIRES_EDA_EXECUTOR:{task_id}"
                )
        if task.get("task_type") == "render_report" and uses_staged_eda:
            if task.get("executor") != "render-analysis-deliverables":
                errors.append(
                    f"REPORT_REQUIRES_DELIVERABLE_RENDERER:{task_id}"
                )
        expected_outputs = task.get("expected_outputs")
        if not isinstance(expected_outputs, list) or not expected_outputs or not all(
            _nonempty_string(value) for value in expected_outputs
        ):
            errors.append(f"TASK_REQUIRES_EXPECTED_OUTPUTS:{task_id}")
        dependencies = task.get("depends_on")
        if not isinstance(dependencies, list):
            errors.append(f"TASK_DEPENDS_ON_MUST_BE_LIST:{task_id}")
        else:
            for dependency in dependencies:
                if dependency not in seen:
                    errors.append(
                        f"TASK_DEPENDENCY_MUST_REFERENCE_EARLIER_TASK:"
                        f"{task_id}:{dependency}"
                    )
        seen.add(task_id)
    task_types = {
        task.get("task_type") for task in tasks if isinstance(task, dict)
    }
    if frozen_strategy in {"INTEGRATED", "SEPARATE", "NO_JOIN_REQUIRED"}:
        for required_type in {
            "inspect_table",
            "clean_transform",
            "exploratory_analysis",
            "validate_findings",
            "render_report",
        }:
            if required_type not in task_types:
                errors.append(
                    f"FULL_EXECUTION_REQUIRES_TASK_TYPE:{required_type}"
                )
        if frozen_strategy == "INTEGRATED" and "join_sources" not in task_types:
            errors.append("INTEGRATED_EXECUTION_REQUIRES_JOIN_TASK")
        if frozen_strategy != "INTEGRATED" and "join_sources" in task_types:
            errors.append("NON_INTEGRATED_EXECUTION_MUST_NOT_JOIN")
    return errors


VALIDATORS: dict[str, Callable[[dict[str, Any]], list[str]]] = {
    "request": validate_request,
    "source_inventory": validate_source_inventory,
    "variable_inventory": validate_variable_inventory,
    "blueprint": validate_blueprint,
    "execution": validate_execution,
}


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Validate planner JSON contracts.")
    parser.add_argument("contract", choices=sorted(VALIDATORS))
    parser.add_argument("input", type=Path)
    return parser


def main(argv: Iterable[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        payload = json.loads(args.input.read_text(encoding="utf-8-sig"))
        if not isinstance(payload, dict):
            raise ValueError("TOP_LEVEL_JSON_MUST_BE_OBJECT")
        errors = VALIDATORS[args.contract](payload)
    except Exception as exc:
        errors = [f"{type(exc).__name__}:{exc}"]
    result = {
        "contract": args.contract,
        "valid": not errors,
        "errors": errors,
    }
    sys.stdout.write(
        json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    )
    return 0 if not errors else 1


if __name__ == "__main__":
    raise SystemExit(main())
