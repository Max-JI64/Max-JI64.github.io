#!/usr/bin/env python3
"""Deterministically inventory structured analysis sources without modifying them."""

from __future__ import annotations

import argparse
from collections import Counter
import csv
from datetime import datetime
from itertools import combinations
import json
from pathlib import Path
import re
import sys
from typing import Any, Iterable
from urllib.parse import urlparse


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")


SCHEMA_VERSION = "source_inventory.v1"
REQUEST_SCHEMA = "analysis_planning_request.v1"
SUPPORTED_FORMATS = {
    "csv",
    "tsv",
    "xlsx",
    "json",
}
STRUCTURED_FORMATS = {"csv", "tsv", "xlsx", "json"}
PROVENANCE_FIELDS = ("title", "publisher", "source_url", "license")
PROFILE_ROW_LIMIT = 20_000
UNIQUE_VALUE_LIMIT = 100_000
TIME_NAMES = {
    "year", "date", "time", "month", "quarter", "period", "week", "day",
    "연도", "년도", "날짜", "일자", "월", "분기", "기간", "시점",
}
EMAIL_PATTERN = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
PHONE_PATTERN = re.compile(r"^\+?[0-9][0-9()\-\s]{6,}[0-9]$")
URL_PATTERN = re.compile(r"^https?://", re.IGNORECASE)


def _is_url(value: str) -> bool:
    parsed = urlparse(value)
    return parsed.scheme.lower() in {"http", "https"} and bool(parsed.netloc)


def _infer_format(location: str) -> str:
    suffix = Path(urlparse(location).path).suffix.lower().lstrip(".")
    return suffix


def _optional_text(value: Any) -> str | None:
    if not isinstance(value, str):
        return None
    cleaned = value.strip()
    return cleaned or None


def _declared_periodicity(source: dict[str, Any]) -> str | None:
    structure = source.get("dataset_structure")
    structure_periodicity = (
        structure.get("time_granularity")
        if isinstance(structure, dict)
        else None
    )
    return _optional_text(source.get("periodicity")) or _optional_text(
        structure_periodicity
    )


def _normalize_name(value: str) -> str:
    return re.sub(r"[^0-9a-z가-힣]+", "", value.strip().lower())


def _is_time_name(value: str) -> bool:
    normalized = _normalize_name(value)
    tokens = {
        token
        for token in re.findall(r"[0-9a-z]+|[가-힣]+", value.strip().lower())
        if token
    }
    return normalized in TIME_NAMES or bool(tokens & TIME_NAMES)


def _nonempty(value: Any) -> bool:
    return value is not None and str(value).strip() != ""


def _as_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, datetime):
        return value.isoformat()
    return str(value).strip()


def _infer_type(values: list[Any]) -> str:
    text = [_as_text(value) for value in values if _nonempty(value)]
    if not text:
        return "empty"
    lowered = {value.lower() for value in text}
    if lowered <= {"true", "false", "yes", "no", "y", "n"}:
        return "boolean"
    if all(re.fullmatch(r"[+-]?\d+", value) for value in text):
        return "integer"
    try:
        for value in text:
            float(value.replace(",", ""))
        return "number"
    except ValueError:
        pass
    date_like = all(
        bool(re.search(r"[-/:T]", value)) and _parse_datetime(value)
        for value in text
    )
    if date_like:
        return "datetime"
    return "string"


def _parse_datetime(value: str) -> bool:
    candidates = (
        value,
        value.replace("Z", "+00:00"),
        value.replace("/", "-"),
    )
    for candidate in candidates:
        try:
            datetime.fromisoformat(candidate)
            return True
        except ValueError:
            continue
    return False


def _quantile(values: list[float], probability: float) -> float:
    if not values:
        raise ValueError("QUANTILE_REQUIRES_VALUES")
    ordered = sorted(values)
    position = (len(ordered) - 1) * probability
    lower = int(position)
    upper = min(lower + 1, len(ordered) - 1)
    weight = position - lower
    return ordered[lower] * (1 - weight) + ordered[upper] * weight


def _structural_summary(
    values: list[str], inferred_type: str
) -> dict[str, Any]:
    counts = Counter(values)
    lengths = sorted(len(value) for value in values)
    summary: dict[str, Any] = {
        "value_length": {
            "minimum": min(lengths) if lengths else None,
            "median": (
                round(_quantile([float(value) for value in lengths], 0.5), 6)
                if lengths else None
            ),
            "maximum": max(lengths) if lengths else None,
        },
        "pattern_counts": {
            "email": sum(bool(EMAIL_PATTERN.fullmatch(value)) for value in values),
            "phone": sum(bool(PHONE_PATTERN.fullmatch(value)) for value in values),
            "url": sum(bool(URL_PATTERN.match(value)) for value in values),
            "digits_only": sum(value.isdigit() for value in values),
        },
        "frequency_summary": {
            "distinct_profiled": len(counts),
            "singletons": sum(count == 1 for count in counts.values()),
            "low_frequency_values": sum(count <= 2 for count in counts.values()),
            "maximum_frequency": max(counts.values()) if counts else 0,
        },
    }
    if inferred_type in {"integer", "number"} and values:
        numeric = [float(value.replace(",", "")) for value in values]
        summary["numeric_summary"] = {
            "minimum": round(min(numeric), 6),
            "q1": round(_quantile(numeric, 0.25), 6),
            "median": round(_quantile(numeric, 0.5), 6),
            "q3": round(_quantile(numeric, 0.75), 6),
            "maximum": round(max(numeric), 6),
        }
    else:
        summary["numeric_summary"] = None
    return summary


def _profile_matrix(
    *,
    source_id: str,
    table_id: str,
    headers: list[str],
    rows: list[list[Any]],
    row_count: int,
    units: dict[str, Any],
    declared_grain: list[str],
    periodicity: str | None = None,
    geography: dict[str, Any] | None = None,
    time_zone: str | None = None,
    warnings: list[str] | None = None,
) -> dict[str, Any]:
    clean_headers = [str(header).strip() for header in headers]
    duplicate_headers = sorted(
        {header for header in clean_headers if clean_headers.count(header) > 1}
    )
    if duplicate_headers:
        return {
            "source_id": source_id,
            "table_id": table_id,
            "inspection_status": "BLOCKED",
            "row_count": row_count,
            "profiled_row_count": len(rows),
            "column_count": len(clean_headers),
            "duplicate_columns": duplicate_headers,
            "columns": [],
            "candidate_key_columns": [],
            "declared_grain": declared_grain,
            "periodicity": periodicity,
            "geography": geography,
            "time_zone": time_zone,
            "profile_complete": row_count <= len(rows),
            "observed_periods": [],
            "warnings": sorted(set(warnings or [])),
            "_records": [],
            "_column_lookup": {},
        }

    normalized_seen: dict[str, list[str]] = {}
    for header in clean_headers:
        normalized_seen.setdefault(_normalize_name(header), []).append(header)
    normalized_collisions = [
        values for values in normalized_seen.values() if len(values) > 1
    ]

    records: list[dict[str, Any]] = []
    for raw_row in rows:
        padded = list(raw_row[: len(clean_headers)])
        if len(padded) < len(clean_headers):
            padded.extend([""] * (len(clean_headers) - len(padded)))
        records.append(dict(zip(clean_headers, padded)))

    columns: list[dict[str, Any]] = []
    candidate_keys: list[str] = []
    observed_periods: list[dict[str, Any]] = []
    for header in clean_headers:
        values = [record.get(header) for record in records]
        nonempty_values = [_as_text(value) for value in values if _nonempty(value)]
        unique_values = set(nonempty_values[:UNIQUE_VALUE_LIMIT])
        nonempty_count = len(nonempty_values)
        uniqueness_ratio = (
            len(unique_values) / nonempty_count if nonempty_count else 0.0
        )
        inferred_type = _infer_type(values)
        column = {
            "name": header,
            "normalized_name": _normalize_name(header),
            "inferred_type": inferred_type,
            "nonempty_profiled": nonempty_count,
            "missing_profiled": len(records) - nonempty_count,
            "unique_profiled": len(unique_values),
            "uniqueness_ratio": round(uniqueness_ratio, 6),
            "unit": units.get(header),
            "structural_summary": _structural_summary(
                nonempty_values, inferred_type
            ),
        }
        columns.append(column)
        if nonempty_count >= 2 and uniqueness_ratio >= 0.98:
            candidate_keys.append(header)
        if _is_time_name(header) and nonempty_values:
            if inferred_type in {"integer", "number"}:
                numeric_values = [
                    float(value.replace(",", "")) for value in nonempty_values
                ]
                minimum: int | float = min(numeric_values)
                maximum: int | float = max(numeric_values)
                if all(value.is_integer() for value in numeric_values):
                    minimum = int(minimum)
                    maximum = int(maximum)
            else:
                minimum = min(nonempty_values)
                maximum = max(nonempty_values)
            observed_periods.append(
                {
                    "column": header,
                    "minimum": minimum,
                    "maximum": maximum,
                }
            )

    combined_warnings = list(warnings or [])
    if normalized_collisions:
        combined_warnings.append(
            "NORMALIZED_COLUMN_NAME_COLLISION:"
            + json.dumps(normalized_collisions, ensure_ascii=False)
        )
    if row_count > len(records):
        combined_warnings.append(
            f"PROFILE_LIMIT_APPLIED:{len(records)}/{row_count}"
        )
    return {
        "source_id": source_id,
        "table_id": table_id,
        "inspection_status": "INSPECTED",
        "row_count": row_count,
        "profiled_row_count": len(records),
        "column_count": len(clean_headers),
        "columns": columns,
        "candidate_key_columns": candidate_keys,
        "declared_grain": declared_grain,
        "periodicity": periodicity,
        "geography": geography,
        "time_zone": time_zone,
        "profile_complete": row_count <= len(records),
        "observed_periods": observed_periods,
        "warnings": sorted(set(combined_warnings)),
        "_records": records,
        "_column_lookup": {
            _normalize_name(column["name"]): column["name"] for column in columns
        },
    }


def _read_csv(
    path: Path,
    source: dict[str, Any],
    fmt: str,
) -> list[dict[str, Any]]:
    encoding = None
    sample = ""
    for candidate in ("utf-8-sig", "utf-8", "cp949"):
        try:
            sample = path.read_text(encoding=candidate)[:65_536]
            encoding = candidate
            break
        except UnicodeDecodeError:
            continue
    if encoding is None:
        raise ValueError("UNSUPPORTED_TEXT_ENCODING")

    delimiter = "\t" if fmt == "tsv" else ","
    if fmt == "csv" and sample:
        try:
            delimiter = csv.Sniffer().sniff(sample, delimiters=",\t;|").delimiter
        except csv.Error:
            pass

    warnings: list[str] = []
    rows: list[list[Any]] = []
    row_count = 0
    with path.open("r", encoding=encoding, newline="") as handle:
        reader = csv.reader(handle, delimiter=delimiter)
        try:
            headers = next(reader)
        except StopIteration:
            headers = []
        for row in reader:
            row_count += 1
            if len(row) != len(headers):
                warnings.append("INCONSISTENT_ROW_WIDTH")
            if len(rows) < PROFILE_ROW_LIMIT:
                rows.append(row)
    if not headers:
        raise ValueError("MISSING_HEADER")
    table = _profile_matrix(
        source_id=source["source_id"],
        table_id=source["source_id"],
        headers=headers,
        rows=rows,
        row_count=row_count,
        units=dict(source.get("column_units") or {}),
        declared_grain=list(source.get("declared_grain") or []),
        periodicity=_declared_periodicity(source),
        geography=(
            dict(source.get("geography"))
            if isinstance(source.get("geography"), dict)
            else None
        ),
        time_zone=source.get("time_zone"),
        warnings=warnings,
    )
    table["encoding"] = encoding
    table["delimiter"] = delimiter
    return [table]


def _json_records(payload: Any) -> tuple[list[dict[str, Any]], str]:
    if isinstance(payload, list) and all(
        isinstance(item, dict) for item in payload
    ):
        return payload, "$"
    if isinstance(payload, dict):
        candidates = [
            (key, value)
            for key, value in payload.items()
            if isinstance(value, list)
            and all(isinstance(item, dict) for item in value)
        ]
        if len(candidates) == 1:
            key, records = candidates[0]
            return records, f"$.{key}"
    raise ValueError("JSON_IS_NOT_A_SINGLE_TABULAR_RECORD_SET")


def _read_json(path: Path, source: dict[str, Any]) -> list[dict[str, Any]]:
    payload = json.loads(path.read_text(encoding="utf-8-sig"))
    records, json_path = _json_records(payload)
    headers: list[str] = []
    for record in records[:PROFILE_ROW_LIMIT]:
        for key in record:
            if str(key) not in headers:
                headers.append(str(key))
    rows = [
        [record.get(header) for header in headers]
        for record in records[:PROFILE_ROW_LIMIT]
    ]
    table = _profile_matrix(
        source_id=source["source_id"],
        table_id=source["source_id"],
        headers=headers,
        rows=rows,
        row_count=len(records),
        units=dict(source.get("column_units") or {}),
        declared_grain=list(source.get("declared_grain") or []),
        periodicity=_declared_periodicity(source),
        geography=(
            dict(source.get("geography"))
            if isinstance(source.get("geography"), dict)
            else None
        ),
        time_zone=source.get("time_zone"),
    )
    table["json_path"] = json_path
    return [table]


def _read_xlsx(path: Path, source: dict[str, Any]) -> list[dict[str, Any]]:
    try:
        import openpyxl
    except ImportError as exc:
        raise ValueError("OPENPYXL_NOT_AVAILABLE") from exc

    workbook = openpyxl.load_workbook(
        path, read_only=True, data_only=True
    )
    tables: list[dict[str, Any]] = []
    try:
        for sheet in workbook.worksheets:
            iterator = sheet.iter_rows(values_only=True)
            try:
                raw_headers = next(iterator)
            except StopIteration:
                continue
            headers = [
                _as_text(value) if _nonempty(value) else f"unnamed_{index + 1}"
                for index, value in enumerate(raw_headers)
            ]
            rows: list[list[Any]] = []
            row_count = 0
            for row in iterator:
                if not any(_nonempty(value) for value in row):
                    continue
                row_count += 1
                if len(rows) < PROFILE_ROW_LIMIT:
                    rows.append(list(row))
            tables.append(
                _profile_matrix(
                    source_id=source["source_id"],
                    table_id=f"{source['source_id']}::{sheet.title}",
                    headers=headers,
                    rows=rows,
                    row_count=row_count,
                    units=dict(source.get("column_units") or {}),
                    declared_grain=list(source.get("declared_grain") or []),
                    periodicity=_declared_periodicity(source),
                    geography=(
                        dict(source.get("geography"))
                        if isinstance(source.get("geography"), dict)
                        else None
                    ),
                    time_zone=source.get("time_zone"),
                )
            )
    finally:
        workbook.close()
    if not tables:
        raise ValueError("WORKBOOK_HAS_NO_NONEMPTY_SHEETS")
    return tables


def _key_stats(
    records: list[dict[str, Any]],
    columns: tuple[str, ...],
) -> dict[str, Any]:
    values: list[tuple[str, ...]] = []
    for record in records:
        key = tuple(_as_text(record.get(column)) for column in columns)
        if all(key):
            values.append(key)
    unique = set(values)
    return {
        "complete_rows": len(values),
        "unique_count": len(unique),
        "uniqueness_ratio": (
            len(unique) / len(values) if values else 0.0
        ),
        "_values": unique,
    }


def _column_unit_conflicts(
    left: dict[str, Any],
    right: dict[str, Any],
    normalized_keys: tuple[str, ...],
    *,
    include_keys: bool,
) -> list[dict[str, Any]]:
    left_columns = {
        column["normalized_name"]: column for column in left["columns"]
    }
    right_columns = {
        column["normalized_name"]: column for column in right["columns"]
    }
    conflicts: list[dict[str, Any]] = []
    shared = sorted(set(left_columns) & set(right_columns))
    selected = (
        [key for key in shared if key in normalized_keys]
        if include_keys
        else [key for key in shared if key not in normalized_keys]
    )
    for key in selected:
        left_unit = left_columns[key].get("unit")
        right_unit = right_columns[key].get("unit")
        if left_unit and right_unit and str(left_unit) != str(right_unit):
            conflicts.append(
                {
                    "normalized_name": key,
                    "left_unit": left_unit,
                    "right_unit": right_unit,
                }
            )
    return conflicts


def _metadata_alignment_issues(
    left: dict[str, Any], right: dict[str, Any]
) -> list[str]:
    issues: list[str] = []
    left_periodicity = str(left.get("periodicity") or "").strip().lower()
    right_periodicity = str(right.get("periodicity") or "").strip().lower()
    if (
        left_periodicity
        and right_periodicity
        and left_periodicity != right_periodicity
    ):
        issues.append("TEMPORAL_GRAIN_MISMATCH")
    left_time_zone = str(left.get("time_zone") or "").strip().lower()
    right_time_zone = str(right.get("time_zone") or "").strip().lower()
    if left_time_zone and right_time_zone and left_time_zone != right_time_zone:
        issues.append("TIME_ZONE_ALIGNMENT_MISMATCH")

    left_geography = left.get("geography")
    right_geography = right.get("geography")
    if isinstance(left_geography, dict) and isinstance(right_geography, dict):
        for field in ("level", "code_system", "boundary_version"):
            left_value = _normalize_name(str(left_geography.get(field) or ""))
            right_value = _normalize_name(str(right_geography.get(field) or ""))
            if left_value and right_value and left_value != right_value:
                issues.append("GEOGRAPHY_ALIGNMENT_MISMATCH")
                break
    return issues


def _join_candidate(
    left: dict[str, Any],
    right: dict[str, Any],
    normalized_keys: tuple[str, ...],
) -> dict[str, Any]:
    left_columns = tuple(
        left["_column_lookup"][key] for key in normalized_keys
    )
    right_columns = tuple(
        right["_column_lookup"][key] for key in normalized_keys
    )
    left_stats = _key_stats(left["_records"], left_columns)
    right_stats = _key_stats(right["_records"], right_columns)
    left_unique = left_stats["uniqueness_ratio"] >= 0.98
    right_unique = right_stats["uniqueness_ratio"] >= 0.98
    if left_unique and right_unique:
        cardinality = "ONE_TO_ONE"
        safety = "SAFE_CANDIDATE"
    elif left_unique:
        cardinality = "ONE_TO_MANY"
        safety = "REQUIRES_REVIEW"
    elif right_unique:
        cardinality = "MANY_TO_ONE"
        safety = "REQUIRES_REVIEW"
    else:
        cardinality = "MANY_TO_MANY"
        safety = "BLOCKED"
    left_values = left_stats.pop("_values")
    right_values = right_stats.pop("_values")
    denominator = min(len(left_values), len(right_values))
    overlap = (
        len(left_values & right_values) / denominator if denominator else 0.0
    )
    key_unit_conflicts = _column_unit_conflicts(
        left, right, normalized_keys, include_keys=True
    )
    measure_unit_conflicts = _column_unit_conflicts(
        left, right, normalized_keys, include_keys=False
    )
    alignment_issues = _metadata_alignment_issues(left, right)
    alignment_issues.extend(
        f"JOIN_KEY_UNIT_CONFLICT:{item['normalized_name']}"
        for item in key_unit_conflicts
    )
    alignment_issues.extend(
        f"UNIT_ALIGNMENT_REQUIRED:{item['normalized_name']}"
        for item in measure_unit_conflicts
    )
    if overlap == 0:
        alignment_issues.append("ZERO_KEY_OVERLAP")

    blocking_issues = {
        issue for issue in alignment_issues
        if issue.startswith(
            (
                "GEOGRAPHY_ALIGNMENT_MISMATCH",
                "JOIN_KEY_UNIT_CONFLICT:",
                "UNIT_ALIGNMENT_REQUIRED:",
            )
        )
    }
    if (
        "ZERO_KEY_OVERLAP" in alignment_issues
        and left.get("profile_complete")
        and right.get("profile_complete")
    ):
        blocking_issues.add("ZERO_KEY_OVERLAP")
    if blocking_issues:
        safety = "BLOCKED"
    elif alignment_issues and safety == "SAFE_CANDIDATE":
        safety = "REQUIRES_REVIEW"
    return {
        "left_source_id": left["source_id"],
        "left_table_id": left["table_id"],
        "right_source_id": right["source_id"],
        "right_table_id": right["table_id"],
        "normalized_keys": list(normalized_keys),
        "left_columns": list(left_columns),
        "right_columns": list(right_columns),
        "cardinality": cardinality,
        "left_key_stats": {
            **left_stats,
            "uniqueness_ratio": round(left_stats["uniqueness_ratio"], 6),
        },
        "right_key_stats": {
            **right_stats,
            "uniqueness_ratio": round(right_stats["uniqueness_ratio"], 6),
        },
        "sampled_key_overlap": round(overlap, 6),
        "unit_conflicts": key_unit_conflicts,
        "measure_unit_conflicts": measure_unit_conflicts,
        "alignment_issues": sorted(set(alignment_issues)),
        "safety": safety,
    }


def _best_join_candidates(tables: list[dict[str, Any]]) -> list[dict[str, Any]]:
    inspected = [
        table
        for table in tables
        if table.get("inspection_status") == "INSPECTED"
        and table.get("_records")
    ]
    results: list[dict[str, Any]] = []
    safety_rank = {
        "SAFE_CANDIDATE": 0,
        "REQUIRES_REVIEW": 1,
        "BLOCKED": 2,
    }
    cardinality_rank = {
        "ONE_TO_ONE": 0,
        "ONE_TO_MANY": 1,
        "MANY_TO_ONE": 1,
        "MANY_TO_MANY": 2,
    }
    for left, right in combinations(inspected, 2):
        if left["source_id"] == right["source_id"]:
            continue
        shared_columns = sorted(
            set(left["_column_lookup"]) & set(right["_column_lookup"])
        )
        left_grain = {
            _normalize_name(str(column))
            for column in left.get("declared_grain", [])
            if _normalize_name(str(column)) in left["_column_lookup"]
        }
        right_grain = {
            _normalize_name(str(column))
            for column in right.get("declared_grain", [])
            if _normalize_name(str(column)) in right["_column_lookup"]
        }
        if left_grain and right_grain:
            shared = sorted(left_grain & right_grain)
        elif left_grain or right_grain:
            shared = sorted(
                set(shared_columns) & (left_grain or right_grain)
            )
        else:
            shared = shared_columns
        candidates: list[dict[str, Any]] = []
        for size in range(1, min(3, len(shared)) + 1):
            for normalized_keys in combinations(shared, size):
                candidates.append(
                    _join_candidate(left, right, normalized_keys)
                )
        if not candidates:
            continue
        declared_grain_available = bool(left_grain and right_grain)
        candidates.sort(
            key=lambda item: (
                safety_rank[item["safety"]],
                cardinality_rank[item["cardinality"]],
                (
                    -len(item["normalized_keys"])
                    if declared_grain_available
                    else len(item["normalized_keys"])
                ),
                -item["sampled_key_overlap"],
                item["normalized_keys"],
            )
        )
        results.append(candidates[0])
    return sorted(
        results,
        key=lambda item: (
            item["left_source_id"],
            item["left_table_id"],
            item["right_source_id"],
            item["right_table_id"],
        ),
    )


def _strip_internal(value: Any) -> Any:
    if isinstance(value, dict):
        return {
            key: _strip_internal(item)
            for key, item in value.items()
            if not key.startswith("_")
        }
    if isinstance(value, list):
        return [_strip_internal(item) for item in value]
    return value


def _structure_confirmation_requests(
    request: dict[str, Any],
    tables: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    tables_by_source: dict[str, list[dict[str, Any]]] = {}
    for table in tables:
        tables_by_source.setdefault(str(table.get("source_id")), []).append(table)

    confirmations: list[dict[str, Any]] = []
    for source in request.get("sources", []):
        if not isinstance(source, dict):
            continue
        source_id = str(source.get("source_id"))
        source_tables = tables_by_source.get(source_id, [])
        if not source_tables:
            continue
        structure = (
            source.get("dataset_structure")
            if isinstance(source.get("dataset_structure"), dict)
            else {}
        )
        declared_grain = list(source.get("declared_grain") or [])
        time_columns = sorted(
            {
                str(column.get("name"))
                for table in source_tables
                for column in table.get("columns", [])
                if isinstance(column, dict)
                and _is_time_name(str(column.get("name") or ""))
            }
        )
        numeric_measures = sorted(
            {
                str(column.get("name"))
                for table in source_tables
                for column in table.get("columns", [])
                if isinstance(column, dict)
                and column.get("inferred_type") in {"integer", "number"}
                and str(column.get("name")) not in declared_grain
                and str(column.get("name")) not in time_columns
            }
        )
        if not declared_grain:
            confirmations.append(
                {
                    "request_id": f"{source_id}:observation_unit",
                    "source_id": source_id,
                    "field": "declared_grain",
                    "blocking": False,
                    "question": (
                        "이 자료에서 한 행이 나타내는 관측 단위와 이를 "
                        "유일하게 식별하는 열을 입력해 주세요."
                    ),
                    "observed_columns": [
                        str(column.get("name"))
                        for table in source_tables
                        for column in table.get("columns", [])
                        if isinstance(column, dict)
                    ],
                    "response_contract": {
                        "target": "sources[].declared_grain",
                        "type": "list[string]",
                    },
                }
            )
        if time_columns and not _declared_periodicity(source):
            confirmations.append(
                {
                    "request_id": f"{source_id}:time_granularity",
                    "source_id": source_id,
                    "field": "dataset_structure.time_granularity",
                    "blocking": False,
                    "question": (
                        f"{', '.join(time_columns)} 열의 관측 주기가 일·주·월·"
                        "분기·연 단위 중 무엇인지 입력해 주세요. 불규칙하면 "
                        "그대로 설명해 주세요."
                    ),
                    "observed_columns": time_columns,
                    "response_contract": {
                        "target": (
                            "sources[].dataset_structure.time_granularity"
                        ),
                        "type": "string",
                        "examples": [
                            "daily", "weekly", "monthly", "quarterly",
                            "annual", "irregular",
                        ],
                    },
                }
            )
        if time_columns and not _optional_text(structure.get("time_field_meaning")):
            confirmations.append(
                {
                    "request_id": f"{source_id}:time_field_meaning",
                    "source_id": source_id,
                    "field": "dataset_structure.time_field_meaning",
                    "blocking": False,
                    "question": (
                        f"{', '.join(time_columns)} 열이 사건 발생일, 기준 기간, "
                        "집계 기간 또는 발표일 중 무엇을 뜻하는지 입력해 주세요."
                    ),
                    "observed_columns": time_columns,
                    "response_contract": {
                        "target": (
                            "sources[].dataset_structure.time_field_meaning"
                        ),
                        "type": "string",
                    },
                }
            )
        declared_measure_basis = (
            structure.get("measure_time_basis")
            if isinstance(structure.get("measure_time_basis"), dict)
            else {}
        )
        missing_measure_basis = [
            column for column in numeric_measures
            if not _optional_text(declared_measure_basis.get(column))
        ]
        if missing_measure_basis and time_columns:
            confirmations.append(
                {
                    "request_id": f"{source_id}:measure_time_basis",
                    "source_id": source_id,
                    "field": "dataset_structure.measure_time_basis",
                    "blocking": False,
                    "question": (
                        "시간에 따라 기록된 수치가 시점값, 기간합계, 기간평균, "
                        "비율, 누계 또는 지수 중 무엇인지 변수별로 입력해 주세요."
                    ),
                    "measure_columns": missing_measure_basis,
                    "response_contract": {
                        "target": (
                            "sources[].dataset_structure.measure_time_basis"
                        ),
                        "type": "object[string,string]",
                        "examples": [
                            "snapshot", "period_total", "period_average",
                            "rate", "cumulative", "index",
                        ],
                    },
                }
            )
    return sorted(confirmations, key=lambda item: item["request_id"])


def inspect_request(request_path: Path) -> dict[str, Any]:
    request = json.loads(request_path.read_text(encoding="utf-8-sig"))
    if request.get("schema_version") != REQUEST_SCHEMA:
        raise ValueError(f"EXPECTED_SCHEMA:{REQUEST_SCHEMA}")
    sources = request.get("sources")
    if not isinstance(sources, list) or not sources:
        raise ValueError("SOURCES_MUST_BE_A_NONEMPTY_LIST")
    source_ids = [source.get("source_id") for source in sources]
    if any(not isinstance(value, str) or not value.strip() for value in source_ids):
        raise ValueError("EVERY_SOURCE_REQUIRES_SOURCE_ID")
    if len(set(source_ids)) != len(source_ids):
        raise ValueError("SOURCE_IDS_MUST_BE_UNIQUE")

    inventory_sources: list[dict[str, Any]] = []
    tables: list[dict[str, Any]] = []
    has_blocking_source = False

    for raw_source in sorted(sources, key=lambda item: item["source_id"]):
        source = dict(raw_source)
        source_id = source["source_id"]
        location = str(source.get("location") or "").strip()
        fmt = str(source.get("format") or _infer_format(location)).lower()
        provenance_values = {
            field: _optional_text(source.get(field))
            for field in PROVENANCE_FIELDS
        }
        missing_provenance = [
            field for field, value in provenance_values.items() if value is None
        ]
        provenance_note = _optional_text(source.get("provenance_note"))
        supplied_provenance = [
            field
            for field, value in provenance_values.items()
            if value is not None
        ]
        if not missing_provenance:
            provenance_status = "COMPLETE"
        elif supplied_provenance or provenance_note:
            provenance_status = "PARTIAL"
        else:
            provenance_status = "UNKNOWN"
        entry: dict[str, Any] = {
            "source_id": source_id,
            "location": location,
            "format": fmt,
            "title": provenance_values["title"],
            "publisher": provenance_values["publisher"],
            "source_url": provenance_values["source_url"],
            "license": provenance_values["license"],
            "missing_provenance": missing_provenance,
            "provenance_note": provenance_note,
            "provenance_status": provenance_status,
            "declared_grain": list(source.get("declared_grain") or []),
            "column_units": dict(source.get("column_units") or {}),
            "periodicity": _declared_periodicity(source),
            "dataset_structure": (
                dict(source.get("dataset_structure"))
                if isinstance(source.get("dataset_structure"), dict)
                else {}
            ),
            "time_zone": source.get("time_zone"),
            "geography": (
                dict(source.get("geography"))
                if isinstance(source.get("geography"), dict)
                else None
            ),
            "notes": source.get("notes"),
            "inspection_status": "PENDING",
            "errors": [],
        }
        if not location:
            entry["inspection_status"] = "BLOCKED"
            entry["errors"].append("MISSING_USER_PROVIDED_LOCAL_FILE")
            has_blocking_source = True
        elif fmt not in SUPPORTED_FORMATS:
            entry["inspection_status"] = "BLOCKED"
            entry["errors"].append(f"UNSUPPORTED_FORMAT:{fmt or 'unknown'}")
            has_blocking_source = True
        elif _is_url(location):
            entry["inspection_status"] = "BLOCKED"
            entry["errors"].append(
                "REMOTE_LOCATION_FORBIDDEN:REQUEST_USER_PROVIDED_LOCAL_FILE"
            )
            has_blocking_source = True
        else:
            path = Path(location)
            if not path.is_absolute():
                path = (request_path.parent / path).resolve()
            entry["resolved_location"] = str(path)
            if not path.is_file():
                entry["inspection_status"] = "BLOCKED"
                entry["errors"].append("USER_PROVIDED_LOCAL_FILE_NOT_FOUND")
                has_blocking_source = True
            else:
                try:
                    source_tables: list[dict[str, Any]] = []
                    if fmt in {"csv", "tsv"}:
                        source_tables = _read_csv(path, source, fmt)
                    elif fmt == "json":
                        source_tables = _read_json(path, source)
                    elif fmt == "xlsx":
                        source_tables = _read_xlsx(path, source)
                    tables.extend(source_tables)
                    entry["table_ids"] = [
                        table["table_id"] for table in source_tables
                    ]
                    entry["inspection_status"] = "INSPECTED"
                    if any(
                        table["inspection_status"] == "BLOCKED"
                        for table in source_tables
                    ):
                        entry["inspection_status"] = "BLOCKED"
                        entry["errors"].append("TABLE_STRUCTURE_BLOCKED")
                        has_blocking_source = True
                except Exception as exc:
                    entry["inspection_status"] = "BLOCKED"
                    entry["errors"].append(
                        f"INSPECTION_FAILED:{type(exc).__name__}:{exc}"
                    )
                    has_blocking_source = True
        inventory_sources.append(entry)

    join_candidates = _best_join_candidates(tables)
    if len(tables) <= 1:
        join_status = "SINGLE_TABLE"
    elif join_candidates:
        join_status = "CANDIDATES_FOUND"
    else:
        join_status = "NO_SHARED_KEYS"

    if has_blocking_source:
        status = "BLOCKED"
    else:
        status = "READY_FOR_PLANNING"

    structure_confirmations = _structure_confirmation_requests(request, tables)
    user_data_requests = []
    for source in inventory_sources:
        if source.get("inspection_status") != "BLOCKED":
            continue
        errors = source.get("errors", [])
        if not any(
            str(error).startswith(
                (
                    "MISSING_USER_PROVIDED_LOCAL_FILE",
                    "REMOTE_LOCATION_FORBIDDEN",
                    "USER_PROVIDED_LOCAL_FILE_NOT_FOUND",
                )
            )
            for error in errors
        ):
            continue
        user_data_requests.append(
            {
                "request_id": f"{source['source_id']}:local_file",
                "source_id": source["source_id"],
                "reason_codes": sorted(str(error) for error in errors),
                "requested_input": "user_provided_local_structured_file",
                "accepted_formats": sorted(STRUCTURED_FORMATS),
                "instruction": (
                    "분석할 로컬 CSV, TSV, XLSX 또는 tabular JSON 파일을 "
                    "사용자가 직접 제공해 주세요. Agent는 인터넷 탐색, "
                    "API 호출 또는 원격 파일 다운로드를 수행하지 않습니다."
                ),
            }
        )
    result = {
        "schema_version": SCHEMA_VERSION,
        "request_id": request.get("request_id"),
        "status": status,
        "sources": inventory_sources,
        "tables": tables,
        "structure_status": (
            "READY_WITH_DISCLOSURES"
            if structure_confirmations
            else "CONFIRMED"
        ),
        "structure_confirmation_requests": structure_confirmations,
        "user_data_requests": sorted(
            user_data_requests, key=lambda item: item["request_id"]
        ),
        "join_assessment": {
            "status": join_status,
            "candidates": join_candidates,
        },
        "safety": {
            "source_files_modified": False,
            "remote_sources_fetched": False,
            "network_access_attempted": False,
            "data_access_mode": "USER_PROVIDED_LOCAL_ONLY",
            "row_values_emitted": False,
        },
    }
    return _strip_internal(result)


def _write_json(payload: dict[str, Any], output: Path | None) -> None:
    text = json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    if output is None:
        sys.stdout.write(text)
        return
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(text, encoding="utf-8")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Inventory user-provided local structured sources without network access."
        )
    )
    parser.add_argument("request", type=Path, help="analysis_planning_request.v1 JSON")
    parser.add_argument("--output", type=Path, help="optional inventory JSON path")
    return parser


def main(argv: Iterable[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    request_path = args.request.resolve()
    try:
        payload = inspect_request(request_path)
        _write_json(payload, args.output)
        return 0
    except Exception as exc:
        error = {
            "schema_version": SCHEMA_VERSION,
            "status": "BLOCKED",
            "errors": [f"{type(exc).__name__}:{exc}"],
        }
        _write_json(error, args.output)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
