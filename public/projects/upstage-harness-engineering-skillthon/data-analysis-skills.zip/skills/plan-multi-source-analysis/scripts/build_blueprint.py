#!/usr/bin/env python3
"""Build a deterministic, approval-gated exploratory analysis blueprint."""

from __future__ import annotations

import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import re
import sys
from typing import Any, Iterable

from analysis_focus_contract import (
    build_generic_analysis_recipe,
    build_staged_eda_policy,
    resolve_analysis_focus,
)
from validate_contract import validate_blueprint, validate_request


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")


REQUEST_SCHEMA = "analysis_planning_request.v1"
INVENTORY_SCHEMA = "source_inventory.v1"
BLUEPRINT_SCHEMA = "analysis_blueprint.v1"
REFINEMENT_SCHEMA = "question_refinements.v1"
PREPARATION_PLAN_SCHEMA = "data_preparation_plan.v1"
VARIABLE_INVENTORY_SCHEMA = "variable_inventory.v1"
PREPARATION_AUDITS = {
    "unit_conversion_audit",
    "temporal_alignment_audit",
    "geography_key_alignment_audit",
    "grain_cardinality_resolution",
}
MODULE_ORDER = (
    "cross_source_consistency",
    "association",
    "temporal_pattern",
    "group_comparison",
    "spatial_pattern",
    "distribution",
    "anomaly_screen",
    "data_quality",
)
TIME_NAMES = {
    "year", "date", "time", "month", "quarter", "period", "week", "day",
    "연도", "년도", "날짜", "일자", "월", "분기", "기간", "시점",
}
GEO_NAMES = {
    "region", "area", "city", "district", "province", "country", "geo",
    "geocode", "geoname", "economycode", "economyname",
    "latitude", "longitude", "lat", "lon", "지역", "시도", "시군구",
    "행정구역", "국가", "구역",
}
UNSUPPORTED_TERMS = {
    "predict", "prediction", "forecast", "causal", "cause", "impact",
    "optimize", "optimization", "recommend", "예측", "전망", "인과",
    "원인", "효과", "영향", "최적화", "추천", "의사결정",
}
QUESTION_MODULE_TERMS = {
    "data_quality": {"quality", "missing", "duplicate", "품질", "결측", "중복"},
    "distribution": {"distribution", "frequency", "분포", "빈도"},
    "group_comparison": {
        "compare", "comparison", "group", "차이", "비교", "집단",
        "집단 간", "지역 간",
    },
    "temporal_pattern": {
        "time", "trend", "change", "year", "month", "기간", "추세", "변화",
        "연도", "월별", "시계열", "지속", "기간별",
    },
    "spatial_pattern": {
        "spatial", "region", "area", "geographic", "공간", "지역", "권역",
    },
    "association": {
        "association", "relationship", "correlation", "together", "연관",
        "관계", "상관", "같은 방향", "함께", "동반", "함께 변함",
    },
    "anomaly_screen": {"anomaly", "outlier", "unusual", "이상", "특이"},
    "cross_source_consistency": {
        "consistency", "agreement", "discrepancy", "일관성", "일치", "불일치",
    },
}
MODULE_OUTPUTS = {
    "data_quality": ["quality_summary"],
    "distribution": ["distribution_summary"],
    "group_comparison": ["group_comparison_summary"],
    "temporal_pattern": ["temporal_pattern_summary"],
    "spatial_pattern": ["spatial_pattern_summary"],
    "association": ["association_summary"],
    "anomaly_screen": ["anomaly_candidates"],
    "cross_source_consistency": ["cross_source_consistency_summary"],
}
MODULE_PURPOSE_KO = {
    "data_quality": "결측, 중복, 유효 범위와 분석 가능 범위를 확인한다.",
    "distribution": "주요 지표의 분포와 범주 구성을 요약한다.",
    "group_comparison": "집단별 차이와 비교 가능한 분모를 탐색한다.",
    "temporal_pattern": "기간별 변화와 변동이 큰 시점을 탐색한다.",
    "spatial_pattern": "지역별 분포와 공간적 차이를 탐색한다.",
    "association": "변수들이 함께 변하는 비인과적 연관을 탐색한다.",
    "anomaly_screen": "강건한 기준으로 검토할 이상 후보를 찾는다.",
    "cross_source_consistency": "출처 간 일치도, 불일치와 범위 차이를 점검한다.",
}
MODULE_PURPOSE_EN = {
    "data_quality": "Check missingness, duplicates, validity, and usable scope.",
    "distribution": "Summarize distributions and category composition.",
    "group_comparison": "Explore group differences with comparable denominators.",
    "temporal_pattern": "Explore change over time and high-variation periods.",
    "spatial_pattern": "Explore geographic distributions and contrasts.",
    "association": "Explore non-causal co-variation between measures.",
    "anomaly_screen": "Identify review candidates using robust reference rules.",
    "cross_source_consistency": "Audit agreement, discrepancies, and coverage.",
}


def _load_json(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(payload, dict):
        raise ValueError(f"TOP_LEVEL_JSON_MUST_BE_OBJECT:{path}")
    return payload


def _payload_sha256(payload: dict[str, Any]) -> str:
    encoded = json.dumps(
        payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _normalize_name(value: Any) -> str:
    return re.sub(r"[^0-9a-z가-힣]+", "", str(value).strip().lower())


def _contains_term(text: str, terms: set[str]) -> bool:
    lowered = text.lower()
    return any(term in lowered for term in terms)


def _is_named(column: dict[str, Any], names: set[str]) -> bool:
    normalized = _normalize_name(
        column.get("normalized_name") or column.get("name") or ""
    )
    return normalized in names or any(
        len(name) > 2
        and (normalized.startswith(name) or normalized.endswith(name))
        for name in names
    )


def _validate_alignment(
    request: dict[str, Any],
    inventory: dict[str, Any],
    variable_inventory: dict[str, Any],
) -> None:
    request_errors = validate_request(request)
    if request_errors:
        raise ValueError("INVALID_REQUEST:" + ",".join(request_errors))
    if inventory.get("schema_version") != INVENTORY_SCHEMA:
        raise ValueError(f"EXPECTED_SCHEMA:{INVENTORY_SCHEMA}")
    if request.get("request_id") != inventory.get("request_id"):
        raise ValueError("REQUEST_INVENTORY_ID_MISMATCH")
    if variable_inventory.get("schema_version") != VARIABLE_INVENTORY_SCHEMA:
        raise ValueError(f"EXPECTED_SCHEMA:{VARIABLE_INVENTORY_SCHEMA}")
    if request.get("request_id") != variable_inventory.get("request_id"):
        raise ValueError("REQUEST_VARIABLE_INVENTORY_ID_MISMATCH")
    request_ids = [
        source.get("source_id") for source in request.get("sources", [])
        if isinstance(source, dict)
    ]
    inventory_ids = [
        source.get("source_id") for source in inventory.get("sources", [])
        if isinstance(source, dict)
    ]
    if (
        not request_ids
        or len(request_ids) != len(set(request_ids))
        or set(request_ids) != set(inventory_ids)
    ):
        raise ValueError("REQUEST_INVENTORY_SOURCE_ID_MISMATCH")


def _source_inventory(inventory: dict[str, Any]) -> list[dict[str, Any]]:
    tables_by_source: dict[str, list[dict[str, Any]]] = {}
    structure_requests_by_source: dict[str, list[dict[str, Any]]] = {}
    for request in inventory.get("structure_confirmation_requests", []):
        if isinstance(request, dict) and request.get("source_id"):
            structure_requests_by_source.setdefault(
                str(request.get("source_id")), []
            ).append(deepcopy(request))
    for table in inventory.get("tables", []):
        if not isinstance(table, dict):
            continue
        summary = {
            "table_id": table.get("table_id"),
            "inspection_status": table.get("inspection_status"),
            "row_count": table.get("row_count"),
            "profiled_row_count": table.get("profiled_row_count"),
            "profile_complete": table.get("profile_complete"),
            "declared_grain": deepcopy(table.get("declared_grain", [])),
            "periodicity": table.get("periodicity"),
            "time_zone": table.get("time_zone"),
            "geography": deepcopy(table.get("geography")),
            "observed_periods": deepcopy(table.get("observed_periods", [])),
            "candidate_key_columns": deepcopy(
                table.get("candidate_key_columns", [])
            ),
            "columns": [
                {
                    key: column.get(key)
                    for key in (
                        "name",
                        "normalized_name",
                        "inferred_type",
                        "unit",
                        "missing_profiled",
                        "uniqueness_ratio",
                        "structural_summary",
                    )
                }
                for column in table.get("columns", [])
                if isinstance(column, dict)
            ],
        }
        tables_by_source.setdefault(str(table.get("source_id")), []).append(
            summary
        )
    output: list[dict[str, Any]] = []
    for source in sorted(
        inventory.get("sources", []), key=lambda item: str(item.get("source_id"))
    ):
        entry = deepcopy(source)
        entry["tables"] = sorted(
            tables_by_source.get(str(source.get("source_id")), []),
            key=lambda item: str(item.get("table_id")),
        )
        entry["structure_confirmation_requests"] = sorted(
            structure_requests_by_source.get(
                str(source.get("source_id")), []
            ),
            key=lambda item: str(item.get("request_id")),
        )
        output.append(entry)
    return output


def _prepared_column_name(value: str) -> str:
    normalized = re.sub(
        r"[^0-9A-Za-z가-힣]+", "_", str(value).strip()
    ).strip("_").lower()
    if not normalized:
        raise ValueError(f"EMPTY_PREPARED_COLUMN_NAME:{value}")
    if normalized[0].isdigit():
        normalized = f"column_{normalized}"
    return normalized


def _preparation_plan(
    source_inventory: list[dict[str, Any]],
    variable_inventory: dict[str, Any],
    selected: dict[str, Any],
    join_plan: dict[str, Any],
    validation_plan: list[dict[str, str]],
) -> dict[str, Any]:
    variables_by_table: dict[tuple[str, str], list[dict[str, Any]]] = {}
    for variable in variable_inventory.get("variables", []):
        if not isinstance(variable, dict):
            continue
        key = (str(variable.get("source_id")), str(variable.get("table_id")))
        variables_by_table.setdefault(key, []).append(variable)
    selected_ids = {
        str(value)
        for value in selected.get("required_source_ids", [])
        if value
    }
    if not selected_ids:
        selected_ids = {
            str(source.get("source_id"))
            for source in source_inventory
            if source.get("source_id")
        }
    planned_sources: list[dict[str, Any]] = []
    for source in source_inventory:
        source_id = str(source.get("source_id"))
        if source_id not in selected_ids:
            continue
        planned_tables: list[dict[str, Any]] = []
        for table in source.get("tables", []):
            if not isinstance(table, dict):
                continue
            mapping: dict[str, str] = {}
            target_types: dict[str, str] = {}
            for column in table.get("columns", []):
                if not isinstance(column, dict) or not column.get("name"):
                    continue
                original = str(column["name"])
                output = _prepared_column_name(original)
                mapping[original] = output
                inferred = str(column.get("inferred_type") or "string")
                target_types[output] = (
                    inferred
                    if inferred
                    in {"string", "integer", "number", "boolean", "datetime"}
                    else "string"
                )
            declared_keys = [
                mapping[key]
                for key in table.get("declared_grain", [])
                if key in mapping
            ]
            if len(set(mapping.values())) != len(mapping):
                raise ValueError(
                    f"PREPARED_COLUMN_NAME_COLLISION:"
                    f"{source_id}:{table.get('table_id')}"
                )
            table_id = str(table.get("table_id"))
            variable_metadata = [
                {
                    key: deepcopy(variable.get(key))
                    for key in (
                        "variable_id",
                        "source_column",
                        "prepared_column",
                        "physical_type",
                        "semantic_role",
                        "measurement_scale",
                        "analysis_roles",
                        "unit",
                        "status",
                        "allowed_analyses",
                        "prohibited_analyses",
                    )
                }
                for variable in sorted(
                    variables_by_table.get((source_id, table_id), []),
                    key=lambda item: str(item.get("variable_id")),
                )
            ]
            planned_tables.append(
                {
                    "table_id": table_id,
                    "row_count_expected": table.get("row_count"),
                    "key_columns": declared_keys,
                    "approved_transformations": [
                        {
                            "operation_id": f"{table_id}:normalize-columns",
                            "operation": "normalize_columns",
                            "column_mapping": mapping,
                        },
                        {
                            "operation_id": f"{table_id}:coerce-types",
                            "operation": "coerce_types",
                            "target_types": target_types,
                        },
                    ],
                    "variable_metadata": variable_metadata,
                }
            )
        planned_sources.append(
            {
                "source_id": source_id,
                "location": (
                    source.get("resolved_location") or source.get("location")
                ),
                "format": source.get("format"),
                "provenance_status": source.get("provenance_status", "UNKNOWN"),
                "missing_provenance": deepcopy(
                    source.get("missing_provenance", [])
                ),
                "provenance_note": source.get("provenance_note"),
                "dataset_structure": deepcopy(
                    source.get("dataset_structure", {})
                ),
                "structure_confirmation_requests": deepcopy(
                    source.get("structure_confirmation_requests", [])
                ),
                "tables": planned_tables,
            }
        )
    required_audits = sorted(
        {
            str(check.get("check"))
            for check in validation_plan
            if isinstance(check, dict)
            and check.get("check") in PREPARATION_AUDITS
        }
    )
    return {
        "schema_version": PREPARATION_PLAN_SCHEMA,
        "sources": planned_sources,
        "join_output": {
            "mode": "INNER",
            "prefix_non_key_columns": True,
        },
        "required_audits": required_audits,
        "mvp_limits": {
            "formats": ["csv", "tsv"],
            "maximum_sources": 3,
        },
        "join_strategy": join_plan.get("strategy"),
    }


def _connected_tree(
    nodes: list[str], edges: list[dict[str, Any]]
) -> list[dict[str, Any]] | None:
    parent = {node: node for node in nodes}

    def find(node: str) -> str:
        while parent[node] != node:
            parent[node] = parent[parent[node]]
            node = parent[node]
        return node

    selected: list[dict[str, Any]] = []
    for edge in sorted(
        edges,
        key=lambda item: (
            str(item.get("left_table_id")),
            str(item.get("right_table_id")),
        ),
    ):
        left = str(edge.get("left_table_id"))
        right = str(edge.get("right_table_id"))
        left_root = find(left)
        right_root = find(right)
        if left_root == right_root:
            continue
        parent[right_root] = left_root
        selected.append(edge)
    if nodes and len({find(node) for node in nodes}) == 1:
        return selected
    return None


def _join_plan(inventory: dict[str, Any]) -> dict[str, Any]:
    tables = [
        table for table in inventory.get("tables", [])
        if isinstance(table, dict)
        and table.get("inspection_status") == "INSPECTED"
    ]
    if len(tables) <= 1:
        grain = deepcopy(tables[0].get("declared_grain", [])) if tables else []
        return {
            "strategy": "NO_JOIN_REQUIRED",
            "target_grain": grain,
            "joins": [],
            "risks": [],
        }

    nodes = sorted(str(table.get("table_id")) for table in tables)
    candidates = [
        candidate
        for candidate in inventory.get("join_assessment", {}).get(
            "candidates", []
        )
        if isinstance(candidate, dict)
    ]
    safe_groups: dict[tuple[str, ...], list[dict[str, Any]]] = {}
    for candidate in candidates:
        keys = tuple(candidate.get("normalized_keys", []))
        if (
            keys
            and candidate.get("safety") == "SAFE_CANDIDATE"
            and candidate.get("cardinality") == "ONE_TO_ONE"
            and not candidate.get("unit_conflicts")
            and not candidate.get("measure_unit_conflicts")
            and not candidate.get("alignment_issues")
        ):
            safe_groups.setdefault(keys, []).append(candidate)
    for keys in sorted(safe_groups, key=lambda value: (len(value), value)):
        selected = _connected_tree(nodes, safe_groups[keys])
        if selected is not None:
            joins = []
            for candidate in selected:
                joins.append(
                    {
                        "left_source_id": candidate.get("left_source_id"),
                        "right_source_id": candidate.get("right_source_id"),
                        "left_table_id": candidate.get("left_table_id"),
                        "right_table_id": candidate.get("right_table_id"),
                        "keys": list(keys),
                        "left_columns": deepcopy(
                            candidate.get("left_columns", [])
                        ),
                        "right_columns": deepcopy(
                            candidate.get("right_columns", [])
                        ),
                        "cardinality": "ONE_TO_ONE",
                        "safety": "SAFE_CANDIDATE",
                        "sampled_key_overlap": candidate.get(
                            "sampled_key_overlap"
                        ),
                        "unit_conflicts": [],
                        "measure_unit_conflicts": [],
                        "alignment_issues": [],
                    }
                )
            return {
                "strategy": "INTEGRATED",
                "target_grain": list(keys),
                "joins": joins,
                "risks": [],
            }

    risks: list[str] = []
    for candidate in sorted(
        candidates,
        key=lambda item: (
            str(item.get("left_table_id")),
            str(item.get("right_table_id")),
        ),
    ):
        risks.extend(
            str(issue)
            for issue in candidate.get("alignment_issues", [])
            if issue
        )
        risks.append(
            "UNSAFE_JOIN:"
            f"{candidate.get('left_table_id')}:{candidate.get('right_table_id')}:"
            f"{candidate.get('cardinality')}:{candidate.get('safety')}"
        )
    if not risks:
        risks.append("NO_SAFE_SHARED_JOIN_KEY")
    else:
        risks.append("SAFE_JOIN_GRAPH_DOES_NOT_CONNECT_ALL_TABLES")
    return {
        "strategy": "SEPARATE",
        "target_grain": [],
        "joins": [],
        "risks": sorted(set(risks)),
    }


def _table_capabilities(
    inventory: dict[str, Any],
    variable_inventory: dict[str, Any],
    join_plan: dict[str, Any],
) -> tuple[
    set[str],
    dict[str, list[str]],
    dict[str, list[str]],
    dict[str, dict[str, list[str]]],
]:
    modules: set[str] = set()
    module_sources: dict[str, set[str]] = {}
    module_fields: dict[str, list[str]] = {}
    source_module_fields: dict[str, dict[str, list[str]]] = {}
    tables = [
        table for table in inventory.get("tables", [])
        if isinstance(table, dict)
        and table.get("inspection_status") == "INSPECTED"
    ]
    if tables:
        modules.add("data_quality")
        module_sources["data_quality"] = {
            str(table.get("source_id")) for table in tables
        }
    usable_statuses = {"AUTO_CONFIDENT", "USER_CONFIRMED"}
    variables = [
        item for item in variable_inventory.get("variables", [])
        if isinstance(item, dict) and item.get("status") in usable_statuses
    ]
    by_source: dict[str, list[dict[str, Any]]] = {}
    source_columns: dict[str, dict[str, dict[str, Any]]] = {}
    all_measures: list[tuple[str, str, str | None]] = []
    table_rows = {
        (str(table.get("source_id")), str(table.get("table_id"))):
        int(table.get("profiled_row_count") or 0)
        for table in tables
    }
    for variable in variables:
        source_id = str(variable.get("source_id"))
        by_source.setdefault(source_id, []).append(variable)
        normalized = _normalize_name(variable.get("source_column"))
        source_columns.setdefault(source_id, {})[normalized] = variable
    for source_id, source_variables in sorted(by_source.items()):
        measures = [
            item for item in source_variables
            if "MEASURE" in item.get("analysis_roles", [])
            and "distribution" in item.get("allowed_analyses", [])
        ]
        groups = [
            item for item in source_variables
            if "GROUP" in item.get("analysis_roles", [])
            and "group_comparison" in item.get("allowed_analyses", [])
        ]
        temporal = [
            item for item in source_variables
            if "TIME_AXIS" in item.get("analysis_roles", [])
            and "temporal_pattern" in item.get("allowed_analyses", [])
        ]
        spatial = [
            item for item in source_variables
            if "GEO_AXIS" in item.get("analysis_roles", [])
            and "spatial_pattern" in item.get("allowed_analyses", [])
        ]
        distributable = [
            item for item in source_variables
            if set(item.get("allowed_analyses", []))
            & {"distribution", "frequency", "ordered_summary"}
        ]
        for item in measures:
            all_measures.append(
                (source_id, str(item.get("source_column")), item.get("unit"))
            )
        if distributable:
            modules.add("distribution")
            module_sources.setdefault("distribution", set()).add(source_id)
            fields = [
                str(item.get("source_column")) for item in distributable[:2]
            ]
            module_fields.setdefault("distribution", []).extend(fields)
            source_module_fields.setdefault("distribution", {}).setdefault(
                source_id, []
            ).extend(fields)
        if measures and groups:
            modules.add("group_comparison")
            module_sources.setdefault("group_comparison", set()).add(source_id)
            fields = [
                str(groups[0].get("source_column")),
                str(measures[0].get("source_column")),
            ]
            module_fields.setdefault("group_comparison", []).extend(fields)
            source_module_fields.setdefault("group_comparison", {}).setdefault(
                source_id, []
            ).extend(fields)
        if measures and temporal:
            modules.add("temporal_pattern")
            module_sources.setdefault("temporal_pattern", set()).add(source_id)
            fields = [
                str(temporal[0].get("source_column")),
                str(measures[0].get("source_column")),
            ]
            module_fields.setdefault("temporal_pattern", []).extend(fields)
            source_module_fields.setdefault("temporal_pattern", {}).setdefault(
                source_id, []
            ).extend(fields)
        if measures and spatial:
            modules.add("spatial_pattern")
            module_sources.setdefault("spatial_pattern", set()).add(source_id)
            fields = [
                str(spatial[0].get("source_column")),
                str(measures[0].get("source_column")),
            ]
            module_fields.setdefault("spatial_pattern", []).extend(fields)
            source_module_fields.setdefault("spatial_pattern", {}).setdefault(
                source_id, []
            ).extend(fields)
        associable = [
            item for item in measures
            if "association" in item.get("allowed_analyses", [])
        ]
        if len(associable) >= 2:
            modules.add("association")
            module_sources.setdefault("association", set()).add(source_id)
            fields = [
                str(item.get("source_column")) for item in associable[:2]
            ]
            module_fields.setdefault("association", []).extend(fields)
            source_module_fields.setdefault("association", {}).setdefault(
                source_id, []
            ).extend(fields)
        anomaly = [
            item for item in measures
            if "anomaly_screen" in item.get("allowed_analyses", [])
            and table_rows.get(
                (source_id, str(item.get("table_id"))), 0
            ) >= 20
        ]
        if anomaly:
            modules.add("anomaly_screen")
            module_sources.setdefault("anomaly_screen", set()).add(source_id)
            field = str(anomaly[0].get("source_column"))
            module_fields.setdefault("anomaly_screen", []).append(field)
            source_module_fields.setdefault("anomaly_screen", {}).setdefault(
                source_id, []
            ).append(field)

    if join_plan.get("strategy") == "INTEGRATED" and len(all_measures) >= 2:
        associable_sources = {
            str(item.get("source_id"))
            for item in variables
            if "association" in item.get("allowed_analyses", [])
        }
        if len(associable_sources) >= 2:
            modules.add("association")
            module_sources["association"] = associable_sources
            module_fields["association"] = [
                field for _, field, _ in all_measures[:2]
            ]

    key_names = set(join_plan.get("target_grain", []))
    if join_plan.get("strategy") == "INTEGRATED" and len(source_columns) >= 2:
        source_ids = sorted(source_columns)
        shared = set(source_columns[source_ids[0]])
        for source_id in source_ids[1:]:
            shared &= set(source_columns[source_id])
        for name in sorted(shared - key_names):
            selected = [source_columns[source_id][name] for source_id in source_ids]
            units = [item.get("unit") for item in selected]
            roles = [item.get("semantic_role") for item in selected]
            scales = [item.get("measurement_scale") for item in selected]
            if (
                units
                and all(unit and unit == units[0] for unit in units)
                and len(set(roles)) == 1
                and len(set(scales)) == 1
                and roles[0] == "QUANTITATIVE_MEASURE"
            ):
                modules.add("cross_source_consistency")
                module_sources["cross_source_consistency"] = set(source_ids)
                module_fields["cross_source_consistency"] = [
                    str(selected[0].get("source_column"))
                ]
                break
    return (
        modules,
        {
            module: sorted(source_ids)
            for module, source_ids in module_sources.items()
        },
        {
            module: list(dict.fromkeys(fields))
            for module, fields in module_fields.items()
        },
        {
            module: {
                source_id: list(dict.fromkeys(fields))
                for source_id, fields in by_source.items()
            }
            for module, by_source in source_module_fields.items()
        },
    )


def _source_titles(
    request: dict[str, Any],
) -> dict[str, str]:
    return {
        str(source.get("source_id")): str(
            source.get("title") or source.get("source_id")
        )
        for source in request.get("sources", [])
        if isinstance(source, dict)
    }


def _question(
    *,
    question_id: str,
    text: str,
    rationale: str,
    source_ids: list[str],
    modules: list[str],
    feasibility: str,
    risks: list[str],
) -> dict[str, Any]:
    return {
        "question_id": question_id,
        "text": text,
        "rationale": rationale,
        "required_source_ids": sorted(set(source_ids)),
        "module_ids": modules,
        "feasibility": feasibility,
        "risks": risks,
    }


def _scope_phrase(
    inventory: dict[str, Any],
    korean: bool,
    source_ids: set[str] | None = None,
) -> str:
    minima: list[int] = []
    maxima: list[int] = []
    month_minima: list[int] = []
    month_maxima: list[int] = []
    geography_levels: set[str] = set()
    geography_counts: set[int] = set()
    for table in inventory.get("tables", []):
        if not isinstance(table, dict):
            continue
        if source_ids is not None and table.get("source_id") not in source_ids:
            continue
        for period in table.get("observed_periods", []):
            if not isinstance(period, dict):
                continue
            column = _normalize_name(period.get("column"))
            minimum = period.get("minimum")
            maximum = period.get("maximum")
            if (
                column in {"month", "월"}
                and isinstance(minimum, (int, float))
                and isinstance(maximum, (int, float))
            ):
                month_minima.append(int(minimum))
                month_maxima.append(int(maximum))
                continue
            if column not in {"year", "연도", "년도"}:
                continue
            if isinstance(minimum, (int, float)) and isinstance(
                maximum, (int, float)
            ):
                minima.append(int(minimum))
                maxima.append(int(maximum))
        geography = table.get("geography")
        if isinstance(geography, dict) and geography.get("level"):
            geography_levels.add(str(geography["level"]).strip().lower())
        table_counts = [
            int(column["unique_profiled"])
            for column in table.get("columns", [])
            if isinstance(column, dict)
            and _normalize_name(str(column.get("name") or "")) in GEO_NAMES
            and isinstance(column.get("unique_profiled"), int)
            and column["unique_profiled"] > 0
        ]
        if table_counts:
            geography_counts.add(min(table_counts))

    parts: list[str] = []
    if minima and maxima:
        minimum = min(minima)
        maximum = max(maxima)
        if korean:
            if minimum == maximum and month_minima and month_maxima:
                month_minimum = min(month_minima)
                month_maximum = max(month_maxima)
                parts.append(
                    f"{minimum}년 {month_minimum}월"
                    if month_minimum == month_maximum
                    else f"{minimum}년 {month_minimum}~{month_maximum}월"
                )
            else:
                parts.append(
                    f"{minimum}년" if minimum == maximum
                    else f"{minimum}~{maximum}년"
                )
        else:
            if minimum == maximum and month_minima and month_maxima:
                parts.append(
                    f"{minimum} months {min(month_minima)}-{max(month_maxima)}"
                )
            else:
                parts.append(
                    str(minimum) if minimum == maximum
                    else f"{minimum}-{maximum}"
                )
    if len(geography_levels) == 1:
        level = next(iter(geography_levels))
        if korean:
            nouns = {
                "country": "국가",
                "region": "지역",
                "province": "시도",
                "city": "도시",
                "district": "시군구",
                "world_bank_aggregate_region": "권역",
            }
            noun = nouns.get(level, level)
            if len(geography_counts) == 1:
                label = (
                    f"자료에 수록된 {next(iter(geography_counts))}개 "
                    f"{noun}에서"
                )
            else:
                label = f"{noun}별"
        else:
            if len(geography_counts) == 1:
                label = (
                    f"across {next(iter(geography_counts))} "
                    f"{level.replace('_', ' ')} units"
                )
            else:
                label = f"by {level.replace('_', ' ')}"
        parts.append(label)
    return " ".join(parts)


def _dimension_label(
    inventory: dict[str, Any], source_id: str, korean: bool
) -> str:
    dimensions: set[str] = set()
    for table in inventory.get("tables", []):
        if (
            not isinstance(table, dict)
            or table.get("source_id") != source_id
        ):
            continue
        for column in table.get("declared_grain", []):
            normalized = _normalize_name(column)
            if (
                normalized
                and normalized not in TIME_NAMES
                and normalized not in GEO_NAMES
            ):
                dimensions.add(normalized)
    if not dimensions:
        return ""
    dimension = sorted(dimensions)[0]
    if korean:
        return {
            "agegroup": "연령대별",
            "sex": "성별",
            "gender": "성별",
        }.get(dimension, f"{dimension}별")
    return {
        "agegroup": "by age group",
        "sex": "by sex",
        "gender": "by gender",
    }.get(dimension, f"by {dimension}")


def _generic_candidates(
    request: dict[str, Any],
    inventory: dict[str, Any],
    join_plan: dict[str, Any],
    modules: set[str],
    module_sources: dict[str, list[str]],
    module_fields: dict[str, list[str]],
    source_module_fields: dict[str, dict[str, list[str]]],
) -> list[dict[str, Any]]:
    language = str(request.get("preferences", {}).get("language", "ko")).lower()
    korean = language.startswith("ko")
    all_source_ids = sorted(
        str(source.get("source_id")) for source in request.get("sources", [])
    )
    titles = _source_titles(request)
    feasibility = "FEASIBLE"
    unsafe_reframe_risk = (
        [
            "원래 교차출처 질문은 조인·시간·지리·단위 정렬 근거를 "
            "보완하기 전에는 실행할 수 없다."
        ]
        if request.get("question") and join_plan.get("strategy") == "SEPARATE"
        else []
    )
    if unsafe_reframe_risk and not korean:
        unsafe_reframe_risk = [
            "The original cross-source question cannot run until join, time, "
            "geography, and unit alignment evidence is supplied."
        ]
    candidates: list[dict[str, Any]] = []
    source_question_counts = {
        source_id: 0 for source_id in all_source_ids
    }
    scope = _scope_phrase(inventory, korean)

    if join_plan.get("strategy") == "INTEGRATED" and "association" in modules:
        fields = module_fields.get("association", [])
        field_text = "와 ".join(fields[:2]) if korean else " and ".join(fields[:2])
        text = (
            f"{scope + ' ' if scope else ''}{field_text or '주요 지표'}는 "
            "결합 단위별로 함께 변하며 그 양상이 기간·집단별로 일관적인가?"
            if korean else
            f"Do {field_text or 'the main measures'} co-vary at the joined "
            f"grain{f' for {scope}' if scope else ''}, and is the pattern "
            "stable across periods or groups?"
        )
        candidates.append(
            _question(
                question_id="",
                text=text,
                rationale=(
                    "안전한 다중 출처 결합의 추가 분석 가치를 확인한다."
                    if korean else
                    "Use the defensible join to test added multi-source value."
                ),
                source_ids=all_source_ids,
                modules=[
                    module for module in ("temporal_pattern", "association")
                    if module in modules
                ],
                feasibility="FEASIBLE",
                risks=[
                    "연관을 인과로 해석하지 않는다."
                    if korean else
                    "Do not interpret association as causation."
                ],
            )
        )

    for module in MODULE_ORDER:
        if module not in modules or module in {
            "association", "cross_source_consistency", "data_quality"
        }:
            continue
        source_ids = module_sources.get(module, all_source_ids[:1])
        source_id = min(
            source_ids or all_source_ids,
            key=lambda item: (source_question_counts.get(item, 0), item),
        )
        source_scope = _scope_phrase(inventory, korean, {source_id})
        dimension = _dimension_label(inventory, source_id, korean)
        dimension_context = (
            f"{dimension}로 " if korean and dimension
            else f"{dimension} " if dimension
            else ""
        )
        title = titles.get(source_id, source_id)
        fields = source_module_fields.get(module, {}).get(
            source_id, module_fields.get(module, [])
        )
        field = fields[-1] if fields else "주요 지표"
        if module == "temporal_pattern":
            text = (
                f"{source_scope + ' ' if source_scope else ''}{title}의 {field}는 "
                f"{dimension_context}기간에 따라 어떻게 변하며 변동이 큰 시점은 언제인가?"
                if korean else
                f"How does {field} in {title}{f' for {source_scope}' if source_scope else ''} "
                f"{dimension_context}change over time, and when is variation greatest?"
            )
        elif module == "group_comparison":
            text = (
                f"{source_scope + ' ' if source_scope else ''}{title}의 {field}는 "
                f"{dimension_context or '집단별로 '}어떻게 다르며 그 차이는 안정적인가?"
                if korean else
                f"How does {field} in {title}{f' for {source_scope}' if source_scope else ''} "
                f"{dimension_context or 'across groups '}differ, and are the differences stable?"
            )
        elif module == "spatial_pattern":
            text = (
                f"{source_scope + ' ' if source_scope else ''}{title}의 {field}는 "
                f"{dimension_context}지역별로 어떻게 분포하며 대비가 큰 곳은 어디인가?"
                if korean else
                f"How is {field} in {title}{f' for {source_scope}' if source_scope else ''} "
                f"{dimension_context}distributed geographically, and where are contrasts largest?"
            )
        elif module == "distribution":
            text = (
                f"{source_scope + ' ' if source_scope else ''}{title}의 {field} "
                f"{dimension + ' ' if dimension else ''}분포와 "
                "데이터 범위의 특징은 무엇인가?"
                if korean else
                f"What characterizes the distribution and data range of "
                f"{field} {dimension + ' ' if dimension else ''}in {title}"
                f"{f' for {source_scope}' if source_scope else ''}?"
            )
        else:
            text = (
                f"{source_scope + ' ' if source_scope else ''}{title}의 {field}에서 검토할 "
                "이상 후보는 무엇인가?"
                if korean else
                f"Which observations in {field} from {title}"
                f"{f' for {source_scope}' if source_scope else ''} merit anomaly review?"
            )
        candidates.append(
            _question(
                question_id="",
                text=text,
                rationale=(
                    "관측 가능한 구조에 맞는 재현 가능한 탐색 질문이다."
                    if korean else
                    "This is a reproducible question supported by observed structure."
                ),
                source_ids=[source_id],
                modules=[module],
                feasibility="FEASIBLE",
                risks=unsafe_reframe_risk,
            )
        )
        source_question_counts[source_id] = (
            source_question_counts.get(source_id, 0) + 1
        )

    if len(candidates) < 2:
        for source_id in all_source_ids:
            title = titles.get(source_id, source_id)
            candidates.append(
                _question(
                    question_id="",
                    text=(
                        f"{title}의 결측·중복·유효 범위가 분석 가능성에 어떤 제약을 주는가?"
                        if korean else
                        f"How do missingness, duplicates, and validity in {title} constrain analysis?"
                    ),
                    rationale=(
                        "후속 분석 전에 최소 품질 근거를 확보한다."
                        if korean else
                        "Establish minimum quality evidence before downstream analysis."
                    ),
                    source_ids=[source_id],
                    modules=["data_quality"],
                    feasibility="FEASIBLE",
                    risks=[],
                )
            )
            if len(candidates) >= 2:
                break
    while len(candidates) < 2:
        source_id = all_source_ids[0]
        title = titles.get(source_id, source_id)
        candidates.append(
            _question(
                question_id="",
                text=(
                    f"{title}에서 분석 가능한 변수와 관측 범위는 무엇인가?"
                    if korean else
                    f"Which variables and observation ranges in {title} are usable for analysis?"
                ),
                rationale=(
                    "구조적 분석 가능 범위를 명확히 한다."
                    if korean else
                    "Clarify the structurally usable analysis scope."
                ),
                source_ids=[source_id],
                modules=["data_quality"],
                feasibility="FEASIBLE",
                risks=[],
            )
        )

    max_candidates = request.get("preferences", {}).get(
        "max_question_candidates", 3
    )
    try:
        limit = max(2, min(3, int(max_candidates)))
    except (TypeError, ValueError):
        limit = 3
    output = candidates[:limit]
    for index, candidate in enumerate(output, 1):
        candidate["question_id"] = f"q{index}"
    return output


def _explicit_candidate(
    request: dict[str, Any],
    join_plan: dict[str, Any],
    modules: set[str],
    module_sources: dict[str, list[str]],
) -> dict[str, Any]:
    question_text = str(request.get("question")).strip()
    requested_modules = (
        request.get("analysis_focus", {}).get("requested_modules")
        if isinstance(request.get("analysis_focus"), dict)
        else None
    )
    if requested_modules:
        selected_modules = list(requested_modules)
    else:
        selected_modules = [
            module
            for module in MODULE_ORDER
            if module in modules
            and _contains_term(question_text, QUESTION_MODULE_TERMS[module])
        ]
    if not selected_modules:
        selected_modules = [
            module for module in MODULE_ORDER if module in modules
        ][:1]
    if not selected_modules:
        selected_modules = ["data_quality"]
    source_ids = sorted(
        {
            source_id
            for module in selected_modules
            for source_id in module_sources.get(module, [])
        }
    )
    all_source_ids = sorted(
        str(source.get("source_id")) for source in request.get("sources", [])
    )
    if not source_ids or join_plan.get("strategy") == "INTEGRATED":
        source_ids = all_source_ids
    language = str(request.get("preferences", {}).get("language", "ko")).lower()
    korean = language.startswith("ko")
    risks = []
    if "association" in selected_modules:
        risks.append(
            "연관을 인과로 해석하지 않는다."
            if korean else
            "Do not interpret association as causation."
        )
    return _question(
        question_id="q1",
        text=question_text,
        rationale=(
            "사용자가 제시한 탐색 질문을 관측 가능한 모듈에 연결한다."
            if korean else
            "Connect the user's exploratory question to observable modules."
        ),
        source_ids=source_ids,
        modules=selected_modules,
        feasibility="FEASIBLE",
        risks=risks,
    )


def _apply_refinements(
    candidates: list[dict[str, Any]],
    refinements: dict[str, Any] | None,
    blueprint_id: str,
) -> list[dict[str, Any]]:
    if refinements is None:
        return candidates
    allowed_top = {"schema_version", "blueprint_id", "questions"}
    if set(refinements) - allowed_top:
        raise ValueError("QUESTION_REFINEMENT_HAS_FORBIDDEN_TOP_LEVEL_FIELD")
    if refinements.get("schema_version") != REFINEMENT_SCHEMA:
        raise ValueError(f"EXPECTED_SCHEMA:{REFINEMENT_SCHEMA}")
    if refinements.get("blueprint_id") != blueprint_id:
        raise ValueError("QUESTION_REFINEMENT_BLUEPRINT_ID_MISMATCH")
    questions = refinements.get("questions")
    if not isinstance(questions, list):
        raise ValueError("QUESTION_REFINEMENTS_MUST_BE_LIST")
    by_id = {candidate["question_id"]: deepcopy(candidate) for candidate in candidates}
    ranks: dict[str, int] = {}
    allowed_question = {"question_id", "text", "rationale", "rank"}
    for entry in questions:
        if not isinstance(entry, dict):
            raise ValueError("QUESTION_REFINEMENT_MUST_BE_OBJECT")
        if set(entry) - allowed_question:
            raise ValueError("QUESTION_REFINEMENT_CHANGES_STRUCTURAL_FIELD")
        question_id = entry.get("question_id")
        if question_id not in by_id:
            raise ValueError(f"UNKNOWN_QUESTION_REFINEMENT_ID:{question_id}")
        for field in ("text", "rationale"):
            if field in entry:
                if not isinstance(entry[field], str) or not entry[field].strip():
                    raise ValueError(f"INVALID_QUESTION_REFINEMENT_{field.upper()}")
                by_id[question_id][field] = entry[field].strip()
        if "rank" in entry:
            rank = entry["rank"]
            if not isinstance(rank, int) or rank < 1:
                raise ValueError("QUESTION_REFINEMENT_RANK_MUST_BE_POSITIVE_INTEGER")
            ranks[question_id] = rank
    if len(ranks.values()) != len(set(ranks.values())):
        raise ValueError("QUESTION_REFINEMENT_RANKS_MUST_BE_UNIQUE")
    original_order = {
        candidate["question_id"]: index for index, candidate in enumerate(candidates)
    }
    return sorted(
        by_id.values(),
        key=lambda item: (
            ranks.get(item["question_id"], 10_000 + original_order[item["question_id"]]),
            original_order[item["question_id"]],
        ),
    )


def _selected_question(candidate: dict[str, Any]) -> dict[str, Any]:
    return {
        "question_id": candidate["question_id"],
        "text": candidate["text"],
        "required_source_ids": deepcopy(candidate["required_source_ids"]),
        "module_ids": deepcopy(candidate["module_ids"]),
    }


def _analysis_steps(
    selected: dict[str, Any], language: str
) -> list[dict[str, Any]]:
    modules = ["data_quality", *selected.get("module_ids", [])]
    modules = list(dict.fromkeys(modules))
    purposes = MODULE_PURPOSE_KO if language.startswith("ko") else MODULE_PURPOSE_EN
    source_ids = selected.get("required_source_ids", [])
    steps = []
    for index, module in enumerate(modules, 1):
        steps.append(
            {
                "step_id": f"step-{index:02d}-{module}",
                "module": module,
                "source_ids": deepcopy(source_ids),
                "purpose": purposes[module],
                "expected_outputs": deepcopy(MODULE_OUTPUTS[module]),
            }
        )
    return steps


def _validation_plan(
    selected: dict[str, Any],
    join_plan: dict[str, Any],
    source_inventory: list[dict[str, Any]],
    language: str,
    analysis_focus: dict[str, Any] | None = None,
) -> list[dict[str, str]]:
    korean = language.startswith("ko")
    checks: list[tuple[str, str, str]] = [
        (
            "missingness_and_denominator",
            "결측과 분모 변화에 따른 결과 민감도를 확인한다.",
            "Check sensitivity to missingness and denominator changes.",
        )
    ]
    modules = set(selected.get("module_ids", []))
    selected_source_ids = set(selected.get("required_source_ids", []))
    incomplete_provenance = any(
        source.get("source_id") in selected_source_ids
        and source.get("missing_provenance")
        for source in source_inventory
    )
    if incomplete_provenance:
        checks.append(
            (
                "provenance_disclosure",
                "알려진 출처 정보와 사용자가 제공한 메모를 보존하고, 확인되지 않은 출처·라이선스는 미상으로 표시하되 분석은 계속한다.",
                "Preserve known source details and user notes, label unverified provenance or license as unknown, and continue the analysis.",
            )
        )
    if join_plan.get("strategy") == "INTEGRATED":
        checks.append(
            (
                "join_coverage",
                "미매칭 키와 결합 전후 행 수를 확인한다.",
                "Audit unmatched keys and row counts before and after joining.",
            )
        )
    join_risks = [str(risk) for risk in join_plan.get("risks", [])]
    if any(risk.startswith("UNIT_ALIGNMENT_REQUIRED:") for risk in join_risks):
        checks.append(
            (
                "unit_conversion_audit",
                "교차출처 비교 전 변환 배율·반올림 규칙을 명시하고 변환값을 원출처 값과 대조하며, 해결 전에는 출처를 분리한다.",
                "Before cross-source comparison, specify scale and rounding rules, verify transformed values against source values, and keep sources separate until resolved.",
            )
        )
    if "TEMPORAL_GRAIN_MISMATCH" in join_risks:
        checks.append(
            (
                "temporal_alignment_audit",
                "교차출처 비교 전 집계 주기·통계량·분모를 명시하고 집계 전후 기간 범위와 행 수를 대조한다.",
                "Before cross-source comparison, specify aggregation frequency, statistic, and denominator, then audit period coverage and row counts.",
            )
        )
    if any(
        risk in {"GEOGRAPHY_ALIGNMENT_MISMATCH", "ZERO_KEY_OVERLAP"}
        for risk in join_risks
    ):
        checks.append(
            (
                "geography_key_alignment_audit",
                "교차출처 비교 전 지리 수준·코드 체계·경계 버전을 정렬하고 키 겹침과 미매칭을 다시 측정한다.",
                "Before cross-source comparison, align geography level, code system, and boundary version, then remeasure key overlap and unmatched keys.",
            )
        )
    if any(":MANY_TO_MANY:BLOCKED" in risk for risk in join_risks):
        checks.append(
            (
                "grain_cardinality_resolution",
                "교차출처 비교 전 잔여 차원을 보존한 복합키, 승인된 집계 또는 브리지 테이블로 다대다를 해소하고 행 수·중복을 감사한다.",
                "Before cross-source comparison, resolve many-to-many grain with a dimension-preserving key, approved aggregation, or bridge, and audit rows and duplicates.",
            )
        )
    if "temporal_pattern" in modules:
        checks.append(
            (
                "time_window_stability",
                "기간 구간을 바꿔도 패턴이 유지되는지 확인한다.",
                "Check whether patterns persist across time windows.",
            )
        )
    selected_text = str(selected.get("text") or "").lower()
    geography_stability_requested = any(
        term in selected_text
        for term in (
            "국가", "지역", "권역", "시도", "시군구",
            "country", "region", "geograph",
        )
    )
    if (
        modules & {"group_comparison", "spatial_pattern"}
        or geography_stability_requested
    ):
        checks.append(
            (
                "subgroup_stability",
                "집단 또는 지역별 표본 범위와 결과 안정성을 확인한다.",
                "Check sample coverage and stability across groups or geographies.",
            )
        )
    if "cross_source_consistency" in modules:
        checks.append(
            (
                "source_agreement",
                "출처별 정의와 값의 일치도를 비교한다.",
                "Compare definitions and agreement across sources.",
            )
        )
    if "anomaly_screen" in modules:
        checks.append(
            (
                "threshold_sensitivity",
                "이상 후보 기준을 바꿨을 때 결과가 얼마나 달라지는지 확인한다.",
                "Check how anomaly candidates change across thresholds.",
            )
        )
    if analysis_focus and analysis_focus.get("sensitivity_pairs"):
        checks.append(
            (
                "declared_sensitivity_pairs",
                "선언된 주 정의와 대체 정의 쌍의 coverage, 방향, 순위와 임계값 분류 안정성을 각 후보 결과에 대해 확인한다.",
                "Check declared primary/alternative definition pairs for coverage, direction, rank, and threshold-classification stability for each candidate finding.",
            )
        )
    return [
        {"check": check, "description": ko if korean else en}
        for check, ko, en in checks
    ]


def build_blueprint(
    request: dict[str, Any],
    inventory: dict[str, Any],
    variable_inventory: dict[str, Any],
    *,
    refinements: dict[str, Any] | None = None,
    selected_question_id: str | None = None,
) -> dict[str, Any]:
    _validate_alignment(request, inventory, variable_inventory)
    request_id = str(request["request_id"])
    blueprint_id = f"{request_id}-plan"
    source_inventory = _source_inventory(inventory)
    join_plan = _join_plan(inventory)
    modules, module_sources, module_fields, source_module_fields = _table_capabilities(
        inventory, variable_inventory, join_plan
    )
    structure_confirmation_requests = deepcopy(
        inventory.get("structure_confirmation_requests", [])
    )
    needs_variable_confirmation = (
        variable_inventory.get("status") == "NEEDS_USER_CONFIRMATION"
        or bool(variable_inventory.get("confirmation_requests"))
    )
    analysis_focus = resolve_analysis_focus(
        None if needs_variable_confirmation else request.get("analysis_focus"),
        variable_inventory.get("variables", []),
        available_modules=modules,
    )
    question_text = request.get("question")
    unsupported = isinstance(question_text, str) and _contains_term(
        question_text, UNSUPPORTED_TERMS
    )
    unsafe_explicit_multi = (
        isinstance(question_text, str)
        and len(request.get("sources", [])) > 1
        and join_plan.get("strategy") == "SEPARATE"
    )
    if needs_variable_confirmation:
        candidates = []
    elif question_text and not unsupported and not unsafe_explicit_multi:
        candidates = [
            _explicit_candidate(request, join_plan, modules, module_sources)
        ]
    else:
        candidates = _generic_candidates(
            request,
            inventory,
            join_plan,
            modules,
            module_sources,
            module_fields,
            source_module_fields,
        )
    candidates = _apply_refinements(candidates, refinements, blueprint_id)
    by_id = {candidate["question_id"]: candidate for candidate in candidates}
    if selected_question_id and selected_question_id not in by_id:
        raise ValueError(f"UNKNOWN_SELECTED_QUESTION_ID:{selected_question_id}")

    source_blocked = any(
        source.get("inspection_status") == "BLOCKED"
        for source in source_inventory
    )
    auto_selected_id = (
        "q1"
        if question_text and not unsupported and not unsafe_explicit_multi
        else None
    )
    chosen_id = selected_question_id or auto_selected_id
    selected = _selected_question(by_id[chosen_id]) if chosen_id else {}

    if inventory.get("status") == "BLOCKED" or source_blocked:
        status = "BLOCKED"
        selected = {}
    elif needs_variable_confirmation:
        status = "NEEDS_VARIABLE_CONFIRMATION"
        selected = {}
    elif not selected:
        status = "NEEDS_QUESTION_SELECTION"
    else:
        status = "READY_FOR_APPROVAL"

    language = str(request.get("preferences", {}).get("language", "ko")).lower()
    steps = _analysis_steps(selected, language) if status == "READY_FOR_APPROVAL" else []
    validations = (
        _validation_plan(
            selected,
            join_plan,
            source_inventory,
            language,
            analysis_focus,
        )
        if status == "READY_FOR_APPROVAL"
        else []
    )
    preparation_plan = _preparation_plan(
        source_inventory,
        variable_inventory,
        selected,
        join_plan,
        validations,
    )
    selected_source_ids = set(selected.get("required_source_ids", []))
    selected_has_incomplete_provenance = any(
        source.get("source_id") in selected_source_ids
        and source.get("missing_provenance")
        for source in source_inventory
    )
    deliverables = (
        [
            *(
                ["join_audit"]
                if join_plan.get("strategy") == "INTEGRATED"
                else []
            ),
            "analysis_tables",
            "analysis_charts",
            "validation_summary",
            *(
                ["provenance_summary"]
                if selected_has_incomplete_provenance
                else []
            ),
            "evidence_report",
            "report_markdown",
            "report_pdf",
            "dashboard_html",
        ]
        if status == "READY_FOR_APPROVAL"
        else []
    )
    limitations = [
        (
            "탐색 결과는 예측·인과 효과·의사결정 최적화를 입증하지 않는다."
            if language.startswith("ko") else
            "Exploratory results do not establish prediction, causation, or optimization."
        ),
        (
            "구조 진단은 표본 프로파일과 선언된 메타데이터에 근거한다."
            if language.startswith("ko") else
            "Structural diagnostics rely on sampled profiles and declared metadata."
        ),
    ]
    limitations.extend(join_plan.get("risks", []))
    for item in structure_confirmation_requests:
        if isinstance(item, dict) and not item.get("blocking"):
            limitations.append(
                "UNCONFIRMED_DATASET_STRUCTURE:"
                f"{item.get('source_id')}:{item.get('field')}"
            )
    for source in source_inventory:
        missing = source.get("missing_provenance") or []
        if missing:
            limitations.append(
                f"PROVENANCE_{source.get('provenance_status', 'PARTIAL')}:"
                f"{source.get('source_id')}:missing={','.join(missing)}"
            )
    if unsupported:
        limitations.append("ORIGINAL_REQUEST_REFRAMED_FROM_UNSUPPORTED_GOAL")
    if unsafe_explicit_multi:
        limitations.append("ORIGINAL_REQUEST_REQUIRES_UNSAFE_MULTI_SOURCE_JOIN")

    staged_eda_policy = build_staged_eda_policy(analysis_focus)
    generic_analysis_recipe = build_generic_analysis_recipe(analysis_focus)
    payload = {
        "schema_version": BLUEPRINT_SCHEMA,
        "blueprint_id": blueprint_id,
        "request_id": request_id,
        "status": status,
        "source_inventory": source_inventory,
        "variable_inventory": deepcopy(variable_inventory),
        "variable_inventory_sha256": _payload_sha256(variable_inventory),
        "variable_confirmation_requests": deepcopy(
            variable_inventory.get("confirmation_requests", [])
        ),
        "structure_confirmation_requests": structure_confirmation_requests,
        "preparation_plan": preparation_plan,
        "join_plan": join_plan,
        "candidate_questions": candidates,
        "selected_question": selected,
        "analysis_steps": steps,
        "validation_plan": validations,
        "analysis_focus": analysis_focus,
        "staged_eda_policy": staged_eda_policy,
        "generic_analysis_recipe": generic_analysis_recipe,
        "deliverables": deliverables,
        "additional_data_requests": deepcopy(
            inventory.get("user_data_requests", [])
        ),
        "limitations": list(dict.fromkeys(limitations)),
        "approval": {"status": "PENDING", "required": True},
    }
    blueprint_errors = validate_blueprint(payload)
    if blueprint_errors:
        raise ValueError(
            "GENERATED_BLUEPRINT_INVALID:" + ",".join(blueprint_errors)
        )
    return payload


def _write_json(payload: dict[str, Any], output: Path | None) -> None:
    serialized = json.dumps(
        payload, ensure_ascii=False, indent=2, sort_keys=True
    ) + "\n"
    if output is None:
        sys.stdout.write(serialized)
    else:
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(serialized, encoding="utf-8")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Build a deterministic analysis_blueprint.v1."
    )
    parser.add_argument("request", type=Path)
    parser.add_argument("inventory", type=Path)
    parser.add_argument("--variable-inventory", type=Path, required=True)
    parser.add_argument("--question-refinements", type=Path)
    parser.add_argument("--select-question")
    parser.add_argument("--output", type=Path)
    return parser


def main(argv: Iterable[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        request = _load_json(args.request)
        inventory = _load_json(args.inventory)
        variable_inventory = _load_json(args.variable_inventory)
        refinements = (
            _load_json(args.question_refinements)
            if args.question_refinements
            else None
        )
        payload = build_blueprint(
            request,
            inventory,
            variable_inventory,
            refinements=refinements,
            selected_question_id=args.select_question,
        )
        _write_json(payload, args.output)
        return 0
    except Exception as exc:
        error = {
            "valid": False,
            "errors": [f"{type(exc).__name__}:{exc}"],
        }
        sys.stderr.write(
            json.dumps(error, ensure_ascii=False, indent=2, sort_keys=True)
            + "\n"
        )
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
