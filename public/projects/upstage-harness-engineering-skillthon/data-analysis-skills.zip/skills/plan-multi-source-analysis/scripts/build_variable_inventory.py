#!/usr/bin/env python3
"""Build a deterministic, privacy-preserving variable semantic inventory."""

from __future__ import annotations

import argparse
from copy import deepcopy
import json
from pathlib import Path
import re
import sys
from typing import Any, Iterable

from analysis_focus_contract import validate_metadata_overrides


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")


REQUEST_SCHEMA = "analysis_planning_request.v1"
SOURCE_INVENTORY_SCHEMA = "source_inventory.v1"
VARIABLE_INVENTORY_SCHEMA = "variable_inventory.v1"
REVIEW_SCHEMA = "llm_review_packet.v1"
OVERLAY_SCHEMA = "variable_semantic_overlay.v1"
CONFIRMATION_SCHEMA = "variable_confirmations.v1"

SEMANTIC_ROLES = {
    "IDENTIFIER",
    "PERSON_NAME",
    "ADDRESS",
    "EMAIL",
    "PHONE_NUMBER",
    "FREE_TEXT",
    "NOMINAL_CATEGORY",
    "ORDINAL_CATEGORY",
    "TEMPORAL",
    "GEOGRAPHIC",
    "QUANTITATIVE_MEASURE",
    "UNKNOWN",
}
MEASUREMENT_SCALES = {
    "NOMINAL", "ORDINAL", "INTERVAL", "RATIO", "NOT_APPLICABLE", "UNKNOWN"
}
ANALYSIS_ROLES = {
    "JOIN_KEY", "MEASURE", "GROUP", "TIME_AXIS", "GEO_AXIS",
    "QUALITY_ONLY", "EXCLUDED", "UNKNOWN",
}
STATUSES = {
    "AUTO_CONFIDENT",
    "LLM_SUGGESTED",
    "NEEDS_USER_CONFIRMATION",
    "USER_CONFIRMED",
    "UNKNOWN",
    "EXCLUDED_SENSITIVE",
}
ALL_ANALYSES = {
    "quality_missingness",
    "quality_format",
    "quality_uniqueness",
    "key_integrity",
    "approved_join",
    "frequency",
    "proportion",
    "crosstab",
    "group_comparison",
    "ordered_summary",
    "median",
    "rank_comparison",
    "distribution",
    "difference",
    "mean",
    "sum",
    "ratio",
    "multiplicative_comparison",
    "association",
    "temporal_pattern",
    "spatial_pattern",
    "anomaly_screen",
    "regression",
    "prediction",
    "causal_inference",
    "text_analysis",
}
BASE_QUALITY = {
    "quality_missingness", "quality_format", "quality_uniqueness"
}
UNSUPPORTED = {
    "regression", "prediction", "causal_inference", "text_analysis"
}

TIME_TERMS = {
    "year", "date", "datetime", "time", "month", "quarter", "week", "day",
    "연도", "년도", "날짜", "일자", "월", "분기", "시간", "시점",
}
GEO_TERMS = {
    "region", "country", "province", "district", "city", "county", "state",
    "latitude", "longitude", "lat", "lon", "geo", "area",
    "지역", "국가", "시도", "시군구", "도시", "위도", "경도", "권역",
}
PERSON_NAME_TERMS = {
    "name", "fullname", "personname", "성명", "이름", "고객명", "사용자명",
}
ADDRESS_TERMS = {
    "address", "streetaddress", "postaladdress", "주소", "도로명주소", "소재지",
}
EMAIL_TERMS = {"email", "emailaddress", "메일", "이메일"}
PHONE_TERMS = {
    "phone", "telephone", "mobile", "cellphone", "전화", "전화번호", "휴대폰",
}
TEXT_TERMS = {
    "text", "comment", "comments", "description", "note", "notes", "reason",
    "review", "content", "memo", "설명", "내용", "메모", "사유", "후기", "비고",
}
CATEGORY_TERMS = {
    "type", "category", "class", "group", "segment", "sex", "gender",
    "agegroup", "유형", "종류", "범주", "분류", "집단", "성별", "연령대",
}
ID_TERMS = {
    "id", "identifier", "key", "code", "uuid", "번호", "코드", "식별자",
}
ORDINAL_TERMS = {
    "score", "rating", "grade", "rank", "level", "index",
    "점수", "평점", "등급", "순위", "수준", "지수",
}
RATE_TERMS = {
    "rate", "ratio", "percent", "percentage", "share",
    "비율", "율", "퍼센트", "점유율",
}
COUNT_TERMS = {
    "count", "population", "quantity", "volume", "total",
    "수", "건수", "인구", "수량", "총계",
}
MONEY_TERMS = {
    "price", "income", "revenue", "cost", "amount", "salary", "wage",
    "가격", "소득", "매출", "비용", "금액", "급여", "임금",
}
INTERVAL_UNITS = {
    "c", "°c", "celsius", "섭씨", "f", "°f", "fahrenheit", "화씨",
}
RATIO_UNITS = {
    "%", "percent", "percentage", "ratio", "proportion", "people", "person",
    "persons", "명", "건", "개", "회", "원", "krw", "usd", "eur",
}
QUALITY_COUNT_PERIOD_TERMS = {
    "month", "months", "quarter", "quarters", "period", "periods",
    "week", "weeks", "day", "days", "월", "분기", "기간", "주", "일",
}
QUALITY_COUNT_MARKERS = {
    "observed", "observation", "coverage", "available", "availability",
    "관측", "가용", "커버리지",
}
QUALITY_FLAG_MARKERS = {
    "complete", "completeness", "available", "availability",
    "valid", "usable", "완전", "가용", "유효",
}
DISPLAY_ORDER_MARKERS = {
    "displayorder", "sortorder", "presentationorder", "표시순서", "정렬순서",
}
BASE_METADATA_MARKERS = {
    "baseperiod", "basevalue", "indexbaseperiod", "indexbasevalue",
    "기준시점", "기준기간", "기준값",
}


def _load_json(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(payload, dict):
        raise ValueError(f"TOP_LEVEL_JSON_MUST_BE_OBJECT:{path}")
    return payload


def _write_json(payload: dict[str, Any], output: Path | None) -> None:
    text = json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    if output is None:
        sys.stdout.write(text)
        return
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(text, encoding="utf-8")


def _normalize_name(value: Any) -> str:
    return re.sub(r"[^0-9a-z가-힣]+", "", str(value).strip().lower())


def _tokens(value: Any) -> set[str]:
    text = str(value).strip().lower()
    tokens = set(re.findall(r"[0-9a-z]+|[가-힣]+", text))
    normalized = _normalize_name(text)
    if normalized:
        tokens.add(normalized)
    return tokens


def _matches(value: Any, terms: set[str]) -> bool:
    name = _normalize_name(value)
    tokens = _tokens(value)
    return bool(tokens & terms) or any(
        len(term) >= 3 and (name.startswith(term) or name.endswith(term))
        for term in terms
    )


def _prepared_column_name(value: str) -> str:
    normalized = re.sub(
        r"[^0-9A-Za-z가-힣]+", "_", str(value).strip()
    ).strip("_").lower()
    if not normalized:
        raise ValueError(f"EMPTY_PREPARED_COLUMN_NAME:{value}")
    if normalized[0].isdigit():
        normalized = f"column_{normalized}"
    return normalized


def _quality_metadata_kind(name: str, inferred: str) -> str | None:
    normalized = _normalize_name(name)
    tokens = _tokens(name)
    has_period = bool(tokens & QUALITY_COUNT_PERIOD_TERMS) or any(
        term in normalized for term in QUALITY_COUNT_PERIOD_TERMS
    )
    has_coverage = bool(tokens & QUALITY_COUNT_MARKERS) or any(
        marker in normalized for marker in QUALITY_COUNT_MARKERS
    )
    if has_period and has_coverage:
        return "COVERAGE_COUNT"
    if any(marker in normalized for marker in BASE_METADATA_MARKERS):
        return "INDEX_BASE_METADATA"
    if any(marker in normalized for marker in DISPLAY_ORDER_MARKERS) or (
        normalized.endswith("order") and inferred in {"integer", "number"}
    ):
        return "DISPLAY_ORDER"
    if (
        any(marker in normalized for marker in QUALITY_FLAG_MARKERS)
        and inferred in {"boolean", "integer", "number", "string"}
    ):
        return "QUALITY_FLAG"
    return None


def _policy(
    semantic_role: str,
    measurement_scale: str,
    analysis_roles: list[str],
    *,
    unit_confirmed: bool,
) -> tuple[list[str], list[str]]:
    allowed = set(BASE_QUALITY)
    roles = set(analysis_roles)
    if "JOIN_KEY" in roles:
        allowed |= {"key_integrity", "approved_join"}
    if roles & {"QUALITY_ONLY", "EXCLUDED"}:
        allowed -= UNSUPPORTED
        return sorted(allowed), sorted(ALL_ANALYSES - allowed)
    if semantic_role == "IDENTIFIER":
        allowed |= {"key_integrity", "approved_join"}
    elif semantic_role in {
        "PERSON_NAME", "ADDRESS", "EMAIL", "PHONE_NUMBER", "FREE_TEXT"
    }:
        pass
    elif semantic_role == "NOMINAL_CATEGORY":
        allowed |= {"frequency", "proportion", "crosstab", "group_comparison"}
    elif semantic_role == "ORDINAL_CATEGORY":
        allowed |= {
            "frequency", "proportion", "crosstab", "group_comparison",
            "ordered_summary", "median", "rank_comparison", "distribution",
        }
    elif semantic_role == "TEMPORAL":
        allowed |= {"temporal_pattern"}
    elif semantic_role == "GEOGRAPHIC":
        allowed |= {"spatial_pattern"}
        if "GROUP" in roles:
            allowed |= {"frequency", "proportion", "group_comparison"}
        if "JOIN_KEY" in roles:
            allowed |= {"key_integrity", "approved_join"}
    elif semantic_role == "QUANTITATIVE_MEASURE":
        if measurement_scale == "INTERVAL":
            allowed |= {"distribution", "difference", "mean", "association"}
        elif measurement_scale == "RATIO" and unit_confirmed:
            allowed |= {
                "distribution", "difference", "mean", "sum", "ratio",
                "multiplicative_comparison", "association", "anomaly_screen",
            }
    allowed -= UNSUPPORTED
    return sorted(allowed), sorted(ALL_ANALYSES - allowed)


def _initial_classification(
    source: dict[str, Any],
    table: dict[str, Any],
    column: dict[str, Any],
) -> dict[str, Any]:
    name = str(column.get("name") or "")
    inferred = str(column.get("inferred_type") or "string")
    unit = column.get("unit")
    summary = deepcopy(column.get("structural_summary") or {})
    patterns = summary.get("pattern_counts") or {}
    nonempty = int(column.get("nonempty_profiled") or 0)
    uniqueness = float(column.get("uniqueness_ratio") or 0.0)
    declared = {
        _normalize_name(value) for value in table.get("declared_grain", [])
    }
    candidate_keys = {
        _normalize_name(value) for value in table.get("candidate_key_columns", [])
    }
    normalized = _normalize_name(name)
    is_declared_key = normalized in declared
    is_candidate_key = normalized in candidate_keys
    evidence = [f"PHYSICAL_TYPE:{inferred}"]
    role = "UNKNOWN"
    scale = "UNKNOWN"
    analysis_roles = ["UNKNOWN"]
    status = "UNKNOWN"
    confidence = 0.35
    sensitive = "LOW"
    confirmation_reason: str | None = None
    quality_kind = _quality_metadata_kind(name, inferred)

    if _matches(name, EMAIL_TERMS) or (
        nonempty and int(patterns.get("email") or 0) / nonempty >= 0.5
    ):
        role, scale = "EMAIL", "NOT_APPLICABLE"
        analysis_roles = ["EXCLUDED", "QUALITY_ONLY"]
        status, confidence, sensitive = "EXCLUDED_SENSITIVE", 0.99, "HIGH"
        evidence.append("SENSITIVE_EMAIL_PATTERN")
    elif _matches(name, PHONE_TERMS) or (
        inferred == "string"
        and nonempty
        and int(patterns.get("phone") or 0) / nonempty >= 0.5
        and float((summary.get("value_length") or {}).get("maximum") or 0) <= 18
    ):
        role, scale = "PHONE_NUMBER", "NOT_APPLICABLE"
        analysis_roles = ["EXCLUDED", "QUALITY_ONLY"]
        status, confidence, sensitive = "EXCLUDED_SENSITIVE", 0.99, "HIGH"
        evidence.append("SENSITIVE_PHONE_PATTERN")
    elif _matches(name, PERSON_NAME_TERMS) and not _matches(name, GEO_TERMS):
        role, scale = "PERSON_NAME", "NOT_APPLICABLE"
        analysis_roles = ["EXCLUDED", "QUALITY_ONLY"]
        status, confidence, sensitive = "EXCLUDED_SENSITIVE", 0.95, "HIGH"
        evidence.append("SENSITIVE_PERSON_NAME_HEADER")
    elif _matches(name, ADDRESS_TERMS):
        role, scale = "ADDRESS", "NOT_APPLICABLE"
        analysis_roles = ["EXCLUDED", "QUALITY_ONLY"]
        status, confidence, sensitive = "EXCLUDED_SENSITIVE", 0.95, "HIGH"
        evidence.append("SENSITIVE_ADDRESS_HEADER")
    elif quality_kind is not None:
        role, scale = "UNKNOWN", "NOT_APPLICABLE"
        analysis_roles = ["QUALITY_ONLY"]
        status, confidence = "AUTO_CONFIDENT", 0.96
        evidence.extend(
            [f"QUALITY_METADATA_PATTERN:{quality_kind}", "NON_ANALYTIC_METADATA"]
        )
    elif inferred == "datetime" or _matches(name, TIME_TERMS):
        role, scale = "TEMPORAL", "NOT_APPLICABLE"
        analysis_roles = ["TIME_AXIS"]
        if is_declared_key:
            analysis_roles.append("JOIN_KEY")
        status, confidence = "AUTO_CONFIDENT", 0.95
        evidence.extend(["TIME_HEADER_OR_TYPE", "NON_MEASURE_AXIS"])
    elif _matches(name, GEO_TERMS):
        role, scale = "GEOGRAPHIC", "NOMINAL"
        analysis_roles = ["GEO_AXIS", "GROUP"]
        if is_declared_key:
            analysis_roles.append("JOIN_KEY")
        if inferred in {"integer", "number"} and _matches(name, ID_TERMS):
            status, confidence = "NEEDS_USER_CONFIRMATION", 0.72
            confirmation_reason = "NUMERIC_GEOGRAPHY_CODE_MEANING"
            evidence.append("NUMERIC_GEOGRAPHY_CODE_AMBIGUOUS")
        else:
            status, confidence = "AUTO_CONFIDENT", 0.92
            evidence.extend(["GEOGRAPHY_HEADER", "NOMINAL_GEOGRAPHY"])
    elif _matches(name, ID_TERMS):
        role, scale = "IDENTIFIER", "NOMINAL"
        analysis_roles = ["JOIN_KEY", "QUALITY_ONLY"]
        status, confidence = "AUTO_CONFIDENT", 0.93
        evidence.extend(["IDENTIFIER_HEADER_OR_DECLARED_KEY", "NON_MEASURE_KEY"])
    elif _matches(name, TEXT_TERMS) or (
        inferred == "string"
        and float((summary.get("value_length") or {}).get("median") or 0) >= 40
    ):
        role, scale = "FREE_TEXT", "NOT_APPLICABLE"
        analysis_roles = ["QUALITY_ONLY"]
        status, confidence = "AUTO_CONFIDENT", 0.9
        evidence.extend(["FREE_TEXT_HEADER_OR_LENGTH", "TEXT_ANALYSIS_NOT_APPROVED"])
    elif inferred in {"boolean"}:
        role, scale = "NOMINAL_CATEGORY", "NOMINAL"
        analysis_roles = ["GROUP"]
        status, confidence = "AUTO_CONFIDENT", 0.95
        evidence.extend(["BOOLEAN_CATEGORY", "LOW_CARDINALITY_GROUP"])
    elif inferred == "string" and _matches(name, CATEGORY_TERMS):
        role, scale = "NOMINAL_CATEGORY", "NOMINAL"
        analysis_roles = ["GROUP"]
        status, confidence = "AUTO_CONFIDENT", 0.9
        evidence.extend(["CATEGORY_HEADER", "NOMINAL_GROUP"])
    elif inferred == "string" and uniqueness <= 0.2:
        role, scale = "NOMINAL_CATEGORY", "NOMINAL"
        analysis_roles = ["GROUP"]
        status, confidence = "AUTO_CONFIDENT", 0.9
        evidence.extend(["LOW_CARDINALITY_STRING", "NOMINAL_GROUP"])
    elif inferred == "string" and uniqueness >= 0.9:
        role, scale = "UNKNOWN", "UNKNOWN"
        analysis_roles = ["UNKNOWN"]
        status, confidence = "NEEDS_USER_CONFIRMATION", 0.55
        confirmation_reason = "HIGH_UNIQUENESS_STRING_ROLE"
        sensitive = "MEDIUM"
        evidence.append("HIGH_UNIQUENESS_STRING_AMBIGUOUS")
    elif inferred in {"integer", "number"} and _matches(name, ORDINAL_TERMS):
        role, scale = "ORDINAL_CATEGORY", "ORDINAL"
        analysis_roles = ["GROUP"]
        status, confidence = "NEEDS_USER_CONFIRMATION", 0.7
        confirmation_reason = "ORDINAL_VS_INTERVAL_SCORE"
        evidence.append("SCORE_OR_INDEX_SCALE_AMBIGUOUS")
    elif inferred in {"integer", "number"} and _matches(name, RATE_TERMS):
        role = "QUANTITATIVE_MEASURE"
        analysis_roles = ["MEASURE"]
        normalized_unit = str(unit or "").strip().lower()
        if (
            normalized_unit in RATIO_UNITS
            or "/" in normalized_unit
            or "_per_" in normalized_unit
            or " per " in normalized_unit
            or "당" in normalized_unit
        ):
            scale, status, confidence = "RATIO", "AUTO_CONFIDENT", 0.9
            evidence.extend(["RATE_HEADER", "DECLARED_RATIO_UNIT"])
        else:
            scale, status, confidence = "UNKNOWN", "NEEDS_USER_CONFIRMATION", 0.65
            confirmation_reason = "RATE_SCALE_AND_DENOMINATOR"
            evidence.append("RATE_WITHOUT_CONFIRMED_SCALE_OR_DENOMINATOR")
    elif inferred in {"integer", "number"} and _matches(name, MONEY_TERMS):
        role, scale = "QUANTITATIVE_MEASURE", "RATIO"
        analysis_roles = ["MEASURE"]
        status, confidence = "NEEDS_USER_CONFIRMATION", 0.65
        confirmation_reason = "CURRENCY_AND_REFERENCE_PERIOD"
        evidence.append("MONETARY_MEASURE_REQUIRES_BASIS")
    elif inferred in {"integer", "number"} and _matches(name, COUNT_TERMS):
        role, scale = "QUANTITATIVE_MEASURE", "RATIO"
        analysis_roles = ["MEASURE"]
        status, confidence = "AUTO_CONFIDENT", 0.91
        evidence.extend(["COUNT_MEASURE_HEADER", "MEANINGFUL_ZERO"])
    elif inferred in {"integer", "number"} and unit:
        role = "QUANTITATIVE_MEASURE"
        analysis_roles = ["MEASURE"]
        if str(unit).strip().lower() in INTERVAL_UNITS:
            scale = "INTERVAL"
            evidence.extend(["DECLARED_INTERVAL_UNIT", "QUANTITATIVE_TYPE"])
        else:
            scale = "RATIO"
            evidence.extend(["DECLARED_UNIT", "QUANTITATIVE_TYPE"])
        status, confidence = "AUTO_CONFIDENT", 0.88
    elif inferred in {"integer", "number"}:
        role, scale = "QUANTITATIVE_MEASURE", "UNKNOWN"
        analysis_roles = ["MEASURE"]
        status, confidence = "NEEDS_USER_CONFIRMATION", 0.55
        confirmation_reason = "NUMERIC_MEASURE_SCALE_AND_UNIT"
        evidence.append("NUMERIC_WITHOUT_SEMANTIC_SCALE")
    elif inferred == "string":
        role, scale = "NOMINAL_CATEGORY", "NOMINAL"
        analysis_roles = ["GROUP"]
        status, confidence = "NEEDS_USER_CONFIRMATION", 0.6
        confirmation_reason = "STRING_CATEGORY_VS_TEXT"
        evidence.append("STRING_ROLE_AMBIGUOUS")

    if is_declared_key and role in {
        "IDENTIFIER", "NOMINAL_CATEGORY", "ORDINAL_CATEGORY",
        "TEMPORAL", "GEOGRAPHIC",
    }:
        analysis_roles.append("JOIN_KEY")
    if is_candidate_key:
        evidence.append("HIGH_UNIQUENESS_CANDIDATE_KEY")
    if is_declared_key:
        evidence.append("DECLARED_GRAIN_COLUMN")
    unit_confirmed = bool(unit) and scale in {"INTERVAL", "RATIO"}
    allowed, prohibited = _policy(
        role, scale, analysis_roles, unit_confirmed=unit_confirmed
    )
    return {
        "semantic_role": role,
        "measurement_scale": scale,
        "analysis_roles": sorted(set(analysis_roles)),
        "status": status,
        "confidence": round(confidence, 6),
        "sensitive_data_likelihood": sensitive,
        "evidence": sorted(set(evidence)),
        "confirmation_reason": confirmation_reason,
        "allowed_analyses": allowed,
        "prohibited_analyses": prohibited,
    }


def _validate_overlay(
    overlay: dict[str, Any] | None, variable_ids: set[str]
) -> dict[str, dict[str, Any]]:
    if overlay is None:
        return {}
    if overlay.get("schema_version") != OVERLAY_SCHEMA:
        raise ValueError(f"EXPECTED_SCHEMA:{OVERLAY_SCHEMA}")
    if set(overlay) != {"schema_version", "variables"}:
        raise ValueError("OVERLAY_UNKNOWN_TOP_LEVEL_FIELD")
    items = overlay.get("variables")
    if not isinstance(items, list):
        raise ValueError("OVERLAY_VARIABLES_MUST_BE_LIST")
    allowed = {
        "variable_id", "candidate_semantic_role", "candidate_measurement_scale",
        "reason", "confidence", "needs_user_confirmation",
    }
    output: dict[str, dict[str, Any]] = {}
    for item in items:
        if not isinstance(item, dict) or set(item) - allowed:
            raise ValueError("OVERLAY_CONTAINS_STRUCTURAL_OR_UNKNOWN_FIELD")
        variable_id = item.get("variable_id")
        if variable_id not in variable_ids or variable_id in output:
            raise ValueError(f"OVERLAY_VARIABLE_ID_INVALID:{variable_id}")
        role = item.get("candidate_semantic_role")
        scale = item.get("candidate_measurement_scale")
        confidence = item.get("confidence")
        if role not in SEMANTIC_ROLES or scale not in MEASUREMENT_SCALES:
            raise ValueError(f"OVERLAY_SEMANTIC_VALUE_INVALID:{variable_id}")
        if (
            not isinstance(confidence, (int, float))
            or isinstance(confidence, bool)
            or not 0 <= confidence <= 1
            or not isinstance(item.get("reason"), str)
            or not item["reason"].strip()
            or not isinstance(item.get("needs_user_confirmation"), bool)
        ):
            raise ValueError(f"OVERLAY_CONTENT_INVALID:{variable_id}")
        output[variable_id] = deepcopy(item)
    return output


def _validate_confirmations(
    confirmations: dict[str, Any] | None, request_ids: set[str]
) -> dict[str, dict[str, Any]]:
    if confirmations is None:
        return {}
    if confirmations.get("schema_version") != CONFIRMATION_SCHEMA:
        raise ValueError(f"EXPECTED_SCHEMA:{CONFIRMATION_SCHEMA}")
    if set(confirmations) != {"schema_version", "confirmations"}:
        raise ValueError("CONFIRMATION_UNKNOWN_TOP_LEVEL_FIELD")
    items = confirmations.get("confirmations")
    if not isinstance(items, list):
        raise ValueError("CONFIRMATIONS_MUST_BE_LIST")
    allowed = {
        "variable_id", "action", "semantic_role", "measurement_scale",
        "analysis_roles", "unit", "rationale",
    }
    output: dict[str, dict[str, Any]] = {}
    for item in items:
        if not isinstance(item, dict) or set(item) - allowed:
            raise ValueError("CONFIRMATION_CONTAINS_UNKNOWN_FIELD")
        variable_id = item.get("variable_id")
        if variable_id not in request_ids or variable_id in output:
            raise ValueError(f"CONFIRMATION_VARIABLE_ID_INVALID:{variable_id}")
        action = item.get("action")
        if action not in {"CONFIRM", "DEFER"}:
            raise ValueError(f"CONFIRMATION_ACTION_INVALID:{variable_id}")
        if action == "CONFIRM":
            if item.get("semantic_role") not in SEMANTIC_ROLES:
                raise ValueError(f"CONFIRMATION_ROLE_INVALID:{variable_id}")
            if item.get("measurement_scale") not in MEASUREMENT_SCALES:
                raise ValueError(f"CONFIRMATION_SCALE_INVALID:{variable_id}")
            roles = item.get("analysis_roles")
            if (
                not isinstance(roles, list)
                or not roles
                or any(value not in ANALYSIS_ROLES for value in roles)
            ):
                raise ValueError(f"CONFIRMATION_ANALYSIS_ROLES_INVALID:{variable_id}")
        output[variable_id] = deepcopy(item)
    return output


def _confirmation_conflicts(
    variable: dict[str, Any], confirmation: dict[str, Any]
) -> list[str]:
    conflicts: list[str] = []
    role = confirmation.get("semantic_role")
    roles = set(confirmation.get("analysis_roles") or [])
    physical = variable.get("physical_type")
    if role == "QUANTITATIVE_MEASURE" and physical not in {"integer", "number"}:
        conflicts.append("QUANTITATIVE_ROLE_CONFLICTS_WITH_PHYSICAL_TYPE")
    if variable.get("status") == "EXCLUDED_SENSITIVE" and (
        role != variable.get("semantic_role")
        or roles - {"EXCLUDED", "QUALITY_ONLY"}
    ):
        conflicts.append("SENSITIVE_VARIABLE_CANNOT_BECOME_GENERAL_ANALYSIS_INPUT")
    if "QUALITY_ONLY" in roles and roles & {
        "MEASURE", "GROUP", "TIME_AXIS", "GEO_AXIS"
    }:
        conflicts.append("QUALITY_ONLY_CONFLICTS_WITH_ANALYSIS_ROLE")
    if role == "TEMPORAL" and roles and "TIME_AXIS" not in roles:
        conflicts.append("TEMPORAL_ROLE_REQUIRES_TIME_AXIS")
    if role == "GEOGRAPHIC" and roles and "GEO_AXIS" not in roles:
        conflicts.append("GEOGRAPHIC_ROLE_REQUIRES_GEO_AXIS")
    return conflicts


def _metadata_overrides(
    request: dict[str, Any], variables: list[dict[str, Any]]
) -> dict[str, dict[str, Any]]:
    raw = request.get("variable_metadata_overrides")
    errors = validate_metadata_overrides(raw)
    if errors:
        raise ValueError("INVALID_VARIABLE_METADATA_OVERRIDES:" + ",".join(errors))
    if raw is None:
        return {}
    by_id = {item["variable_id"]: item for item in variables}
    by_triple = {
        (
            item["source_id"],
            item["table_id"],
            item["source_column"],
        ): item
        for item in variables
    }
    resolved: dict[str, dict[str, Any]] = {}
    for item in raw:
        if item.get("variable_id"):
            variable = by_id.get(str(item["variable_id"]))
        else:
            variable = by_triple.get(
                (
                    str(item.get("source_id")),
                    str(item.get("table_id")),
                    str(item.get("source_column")),
                )
            )
        if variable is None:
            raise ValueError("VARIABLE_METADATA_OVERRIDE_REFERENCE_NOT_FOUND")
        variable_id = variable["variable_id"]
        if variable_id in resolved:
            raise ValueError(
                f"DUPLICATE_VARIABLE_METADATA_OVERRIDE:{variable_id}"
            )
        conflicts = _confirmation_conflicts(variable, item)
        if conflicts:
            raise ValueError(
                f"VARIABLE_METADATA_OVERRIDE_CONFLICT:{variable_id}:"
                + ",".join(conflicts)
            )
        resolved[variable_id] = deepcopy(item)
    return resolved


def build_variable_inventory(
    request: dict[str, Any],
    inventory: dict[str, Any],
    *,
    overlay: dict[str, Any] | None = None,
    confirmations: dict[str, Any] | None = None,
) -> tuple[dict[str, Any], dict[str, Any]]:
    if request.get("schema_version") != REQUEST_SCHEMA:
        raise ValueError(f"EXPECTED_SCHEMA:{REQUEST_SCHEMA}")
    if inventory.get("schema_version") != SOURCE_INVENTORY_SCHEMA:
        raise ValueError(f"EXPECTED_SCHEMA:{SOURCE_INVENTORY_SCHEMA}")
    if request.get("request_id") != inventory.get("request_id"):
        raise ValueError("REQUEST_INVENTORY_ID_MISMATCH")
    sources = {
        str(source.get("source_id")): source
        for source in inventory.get("sources", [])
        if isinstance(source, dict)
    }
    variables: list[dict[str, Any]] = []
    for table in sorted(
        (item for item in inventory.get("tables", []) if isinstance(item, dict)),
        key=lambda item: (str(item.get("source_id")), str(item.get("table_id"))),
    ):
        source_id = str(table.get("source_id"))
        source = sources.get(source_id, {})
        table_id = str(table.get("table_id"))
        for column in table.get("columns", []):
            if not isinstance(column, dict) or not column.get("name"):
                continue
            original = str(column["name"])
            variable_id = f"{source_id}::{table_id}::{_normalize_name(original)}"
            classification = _initial_classification(source, table, column)
            variables.append(
                {
                    "variable_id": variable_id,
                    "source_id": source_id,
                    "table_id": table_id,
                    "source_column": original,
                    "prepared_column": _prepared_column_name(original),
                    "physical_type": column.get("inferred_type"),
                    "unit": column.get("unit"),
                    "profile": {
                        "nonempty_profiled": column.get("nonempty_profiled"),
                        "missing_profiled": column.get("missing_profiled"),
                        "unique_profiled": column.get("unique_profiled"),
                        "uniqueness_ratio": column.get("uniqueness_ratio"),
                        "structural_summary": deepcopy(
                            column.get("structural_summary") or {}
                        ),
                    },
                    **classification,
                    "llm_suggestion": None,
                    "metadata_override": None,
                    "user_confirmation": None,
                    "confirmation_conflicts": [],
                }
            )
    variable_ids = [item["variable_id"] for item in variables]
    if len(variable_ids) != len(set(variable_ids)):
        raise ValueError("VARIABLE_IDS_MUST_BE_UNIQUE")
    metadata_overrides = _metadata_overrides(request, variables)
    for variable in variables:
        override = metadata_overrides.get(variable["variable_id"])
        if override is None:
            continue
        variable["metadata_override"] = deepcopy(override)
        variable["semantic_role"] = override["semantic_role"]
        variable["measurement_scale"] = override["measurement_scale"]
        variable["analysis_roles"] = sorted(set(override["analysis_roles"]))
        if "unit" in override:
            variable["unit"] = override.get("unit")
        variable["status"] = "USER_CONFIRMED"
        variable["confidence"] = 1.0
        variable["confirmation_reason"] = None
        variable["evidence"] = sorted(
            set(variable["evidence"] + ["USER_CONFIRMED_METADATA_OVERRIDE"])
        )
        variable["allowed_analyses"], variable["prohibited_analyses"] = _policy(
            variable["semantic_role"],
            variable["measurement_scale"],
            variable["analysis_roles"],
            unit_confirmed=bool(variable.get("unit"))
            or variable["measurement_scale"] == "INTERVAL",
        )
    overlay_by_id = _validate_overlay(overlay, set(variable_ids))
    for variable in variables:
        suggestion = overlay_by_id.get(variable["variable_id"])
        if suggestion is None or variable["status"] == "EXCLUDED_SENSITIVE":
            continue
        variable["llm_suggestion"] = suggestion
        if variable["status"] == "UNKNOWN":
            variable["semantic_role"] = suggestion["candidate_semantic_role"]
            variable["measurement_scale"] = suggestion[
                "candidate_measurement_scale"
            ]
            variable["status"] = (
                "NEEDS_USER_CONFIRMATION"
                if suggestion["needs_user_confirmation"]
                else "LLM_SUGGESTED"
            )
            variable["confidence"] = round(float(suggestion["confidence"]), 6)
            variable["evidence"] = sorted(
                set(variable["evidence"] + ["LLM_OVERLAY_SUGGESTION"])
            )
            variable["confirmation_reason"] = (
                "LLM_SUGGESTION_REQUIRES_CONFIRMATION"
                if suggestion["needs_user_confirmation"]
                else None
            )
            variable["analysis_roles"] = ["UNKNOWN"]
            variable["allowed_analyses"], variable["prohibited_analyses"] = _policy(
                variable["semantic_role"],
                variable["measurement_scale"],
                variable["analysis_roles"],
                unit_confirmed=False,
            )
    confirmation_request_ids = {
        item["variable_id"]
        for item in variables
        if item["status"] == "NEEDS_USER_CONFIRMATION"
    }
    confirmations_by_id = _validate_confirmations(
        confirmations, confirmation_request_ids
    )
    for variable in variables:
        confirmation = confirmations_by_id.get(variable["variable_id"])
        if confirmation is None:
            continue
        variable["user_confirmation"] = confirmation
        if confirmation["action"] == "DEFER":
            variable.update(
                {
                    "semantic_role": "UNKNOWN",
                    "measurement_scale": "UNKNOWN",
                    "analysis_roles": ["EXCLUDED", "UNKNOWN"],
                    "status": "UNKNOWN",
                    "confidence": 0.0,
                    "confirmation_reason": None,
                }
            )
            variable["evidence"] = sorted(
                set(variable["evidence"] + ["USER_DEFERRED_TO_UNKNOWN"])
            )
            variable["allowed_analyses"], variable["prohibited_analyses"] = _policy(
                "UNKNOWN", "UNKNOWN", variable["analysis_roles"],
                unit_confirmed=False,
            )
            continue
        conflicts = _confirmation_conflicts(variable, confirmation)
        if conflicts:
            variable["confirmation_conflicts"] = conflicts
            variable["evidence"] = sorted(set(variable["evidence"] + conflicts))
            continue
        variable["semantic_role"] = confirmation["semantic_role"]
        variable["measurement_scale"] = confirmation["measurement_scale"]
        variable["analysis_roles"] = sorted(set(confirmation["analysis_roles"]))
        if "unit" in confirmation:
            variable["unit"] = confirmation.get("unit")
        variable["status"] = "USER_CONFIRMED"
        variable["confidence"] = 1.0
        variable["confirmation_reason"] = None
        variable["evidence"] = sorted(
            set(variable["evidence"] + ["USER_CONFIRMED_SEMANTICS"])
        )
        variable["allowed_analyses"], variable["prohibited_analyses"] = _policy(
            variable["semantic_role"],
            variable["measurement_scale"],
            variable["analysis_roles"],
            unit_confirmed=bool(variable.get("unit"))
            or variable["measurement_scale"] == "INTERVAL",
        )
    confirmation_requests = [
        {
            "variable_id": item["variable_id"],
            "source_id": item["source_id"],
            "table_id": item["table_id"],
            "source_column": item["source_column"],
            "reason": item["confirmation_reason"],
            "candidate_semantic_role": item["semantic_role"],
            "candidate_measurement_scale": item["measurement_scale"],
            "allowed_actions": ["CONFIRM", "DEFER"],
        }
        for item in variables
        if item["status"] == "NEEDS_USER_CONFIRMATION"
    ]
    payload = {
        "schema_version": VARIABLE_INVENTORY_SCHEMA,
        "request_id": request.get("request_id"),
        "status": (
            "NEEDS_USER_CONFIRMATION" if confirmation_requests else "READY"
        ),
        "variables": variables,
        "confirmation_requests": confirmation_requests,
        "safety": {
            "raw_rows_emitted": False,
            "raw_sensitive_values_emitted": False,
            "llm_called": False,
        },
    }
    review = {
        "schema_version": REVIEW_SCHEMA,
        "request_id": request.get("request_id"),
        "variables": [
            {
                "variable_id": item["variable_id"],
                "source_id": item["source_id"],
                "table_id": item["table_id"],
                "column_name": item["source_column"],
                "physical_type": item["physical_type"],
                "declared_unit": item["unit"],
                "profile": deepcopy(item["profile"]),
                "deterministic_candidate": {
                    "semantic_role": item["semantic_role"],
                    "measurement_scale": item["measurement_scale"],
                    "status": item["status"],
                    "evidence": item["evidence"],
                },
            }
            for item in variables
        ],
        "safety": {
            "raw_rows_included": False,
            "raw_sensitive_values_included": False,
            "top_value_labels_included": False,
        },
    }
    return payload, review


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Build deterministic variable semantics before question planning."
    )
    parser.add_argument("request", type=Path)
    parser.add_argument("inventory", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--review-output", type=Path)
    parser.add_argument("--llm-overlay", type=Path)
    parser.add_argument("--user-confirmations", type=Path)
    return parser


def main(argv: Iterable[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        payload, review = build_variable_inventory(
            _load_json(args.request),
            _load_json(args.inventory),
            overlay=_load_json(args.llm_overlay) if args.llm_overlay else None,
            confirmations=(
                _load_json(args.user_confirmations)
                if args.user_confirmations else None
            ),
        )
        _write_json(payload, args.output)
        if args.review_output:
            _write_json(review, args.review_output)
        return 0
    except Exception as exc:
        error = {
            "schema_version": VARIABLE_INVENTORY_SCHEMA,
            "status": "BLOCKED",
            "errors": [f"{type(exc).__name__}:{exc}"],
        }
        _write_json(error, args.output)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
