#!/usr/bin/env python3
"""Generic request-time analysis focus and pre-approval EDA policy helpers."""

from __future__ import annotations

from copy import deepcopy
from typing import Any


ANALYSIS_MODULES = {
    "data_quality",
    "distribution",
    "group_comparison",
    "temporal_pattern",
    "spatial_pattern",
    "association",
    "anomaly_screen",
    "cross_source_consistency",
}
VARIABLE_SEMANTIC_ROLES = {
    "IDENTIFIER",
    "PERSON_NAME",
    "ADDRESS",
    "EMAIL",
    "PHONE_NUMBER",
    "FREE_TEXT",
    "NOMINAL_CATEGORY",
    "ORDINAL_CATEGORY",
    "TEMPORAL",
    "GEOGRAPHIC",
    "QUANTITATIVE_MEASURE",
    "UNKNOWN",
}
MEASUREMENT_SCALES = {
    "NOMINAL",
    "ORDINAL",
    "INTERVAL",
    "RATIO",
    "NOT_APPLICABLE",
    "UNKNOWN",
}
ANALYSIS_ROLES = {
    "JOIN_KEY",
    "MEASURE",
    "GROUP",
    "TIME_AXIS",
    "GEO_AXIS",
    "QUALITY_ONLY",
    "EXCLUDED",
    "UNKNOWN",
}
USABLE_VARIABLE_STATUSES = {"AUTO_CONFIDENT", "USER_CONFIRMED"}
SENSITIVITY_CHECKS = {
    "pairwise_complete_coverage",
    "direction_agreement",
    "pearson_co_movement",
    "spearman_co_movement",
    "group_rank_stability",
    "threshold_classification_agreement",
    "exclude_latest_period_stability",
    "time_window_stability",
}
DERIVED_OPERATIONS = {
    "proportion_below_threshold",
    "consecutive_periods_below_threshold",
    "window_mean_difference",
    "first_latest_difference",
}
MISSING_POLICIES = {"exclude_missing", "break_sequence"}
PARTIAL_PERIOD_POLICIES = {
    "exclude_partial_periods",
    "use_observed_with_disclosure",
}
STAGE_2_TRIGGERS = {
    "missingness",
    "join_loss",
    "robust_outlier_candidates",
    "distribution_asymmetry",
    "strong_numeric_association",
    "unstable_numeric_association",
}
EVIDENCE_STATUSES = {"validated", "qualified", "rejected"}
GROUP_SELECTOR_OPERATORS = {"equal", "at_least", "at_most"}
GROUP_COMPARISON_STATISTICS = {"median_of_group_medians_difference"}
GROUP_COMPARISON_MISSING_POLICIES = {"exclude_missing"}
GROUP_COMPARISON_CLAIM_BOUNDARIES = {
    "observed_non_causal_group_contrast"
}


def _nonempty(value: Any) -> bool:
    return isinstance(value, str) and bool(value.strip())


def _number(value: Any) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def _reference_error(
    reference: Any, label: str, *, resolved: bool = False
) -> list[str]:
    if not isinstance(reference, dict):
        return [f"{label}_REFERENCE_MUST_BE_OBJECT"]
    allowed = {"variable_id", "source_id", "table_id", "source_column"}
    if resolved:
        allowed |= {
            "prepared_column",
            "semantic_role",
            "measurement_scale",
            "analysis_roles",
            "unit",
        }
    unknown = set(reference) - allowed
    errors = [
        f"{label}_REFERENCE_UNKNOWN_FIELD:{field}" for field in sorted(unknown)
    ]
    has_variable_id = _nonempty(reference.get("variable_id"))
    triple = ("source_id", "table_id", "source_column")
    has_triple = all(_nonempty(reference.get(field)) for field in triple)
    if resolved:
        if not has_variable_id or not has_triple:
            errors.append(
                f"{label}_RESOLVED_REFERENCE_REQUIRES_ID_AND_SOURCE_TABLE_COLUMN"
            )
    elif has_variable_id == has_triple:
        errors.append(
            f"{label}_REFERENCE_REQUIRES_EXACTLY_VARIABLE_ID_OR_SOURCE_TABLE_COLUMN"
        )
    if not has_variable_id and any(field in reference for field in triple) and not has_triple:
        errors.append(f"{label}_REFERENCE_INCOMPLETE_SOURCE_TABLE_COLUMN")
    return errors


def validate_metadata_overrides(value: Any) -> list[str]:
    if value is None:
        return []
    if not isinstance(value, list):
        return ["VARIABLE_METADATA_OVERRIDES_MUST_BE_LIST"]
    errors: list[str] = []
    allowed = {
        "variable_id",
        "source_id",
        "table_id",
        "source_column",
        "semantic_role",
        "measurement_scale",
        "analysis_roles",
        "unit",
        "rationale",
    }
    seen: set[tuple[str, ...]] = set()
    for index, item in enumerate(value):
        label = f"VARIABLE_METADATA_OVERRIDE:{index}"
        if not isinstance(item, dict):
            errors.append(f"{label}:MUST_BE_OBJECT")
            continue
        for field in sorted(set(item) - allowed):
            errors.append(f"{label}:UNKNOWN_FIELD:{field}")
        errors.extend(
            _reference_error(
                {
                    field: item[field]
                    for field in (
                        "variable_id",
                        "source_id",
                        "table_id",
                        "source_column",
                    )
                    if field in item
                },
                label,
            )
        )
        if item.get("semantic_role") not in VARIABLE_SEMANTIC_ROLES:
            errors.append(f"{label}:INVALID_SEMANTIC_ROLE")
        if item.get("measurement_scale") not in MEASUREMENT_SCALES:
            errors.append(f"{label}:INVALID_MEASUREMENT_SCALE")
        roles = item.get("analysis_roles")
        if (
            not isinstance(roles, list)
            or not roles
            or any(role not in ANALYSIS_ROLES for role in roles)
        ):
            errors.append(f"{label}:INVALID_ANALYSIS_ROLES")
        if "QUALITY_ONLY" in (roles or []) and set(roles or []) & {
            "MEASURE",
            "GROUP",
            "TIME_AXIS",
            "GEO_AXIS",
        }:
            errors.append(f"{label}:QUALITY_ONLY_CONFLICTS_WITH_ANALYSIS_ROLE")
        if not _nonempty(item.get("rationale")):
            errors.append(f"{label}:RATIONALE_REQUIRED")
        if "unit" in item and item["unit"] is not None and not _nonempty(item["unit"]):
            errors.append(f"{label}:INVALID_UNIT")
        if _nonempty(item.get("variable_id")):
            key = ("id", str(item["variable_id"]))
        else:
            key = (
                "triple",
                str(item.get("source_id")),
                str(item.get("table_id")),
                str(item.get("source_column")),
            )
        if key in seen:
            errors.append(f"{label}:DUPLICATE_REFERENCE")
        seen.add(key)
    return errors


def validate_analysis_focus(value: Any, *, resolved: bool = False) -> list[str]:
    if value is None:
        return []
    if not isinstance(value, dict):
        return ["ANALYSIS_FOCUS_MUST_BE_OBJECT"]
    errors: list[str] = []
    allowed = {
        "schema_version",
        "requested_modules",
        "primary_measure",
        "comparison_measures",
        "time_axis",
        "group_axis",
        "geography_axis",
        "geography_label",
        "association_pairs",
        "sensitivity_pairs",
        "derived_rules",
        "derived_group_comparisons",
    }
    for field in sorted(set(value) - allowed):
        errors.append(f"ANALYSIS_FOCUS_UNKNOWN_FIELD:{field}")
    if resolved and value.get("schema_version") != "analysis_focus.v1":
        errors.append("ANALYSIS_FOCUS_RESOLVED_SCHEMA_REQUIRED")
    modules = value.get("requested_modules")
    if (
        not isinstance(modules, list)
        or (not modules and not resolved)
        or any(module not in ANALYSIS_MODULES for module in (modules or []))
        or (
            isinstance(modules, list)
            and len(modules) != len(set(modules))
        )
    ):
        errors.append("ANALYSIS_FOCUS_INVALID_REQUESTED_MODULES")
    if resolved and modules == []:
        for field in (
            "primary_measure",
            "time_axis",
            "group_axis",
            "geography_axis",
        ):
            if value.get(field) != {}:
                errors.append(f"ANALYSIS_FOCUS_EMPTY_FALLBACK_REQUIRES_EMPTY_{field}")
        for field in (
            "comparison_measures",
            "association_pairs",
            "sensitivity_pairs",
            "derived_rules",
            "derived_group_comparisons",
        ):
            if value.get(field) != []:
                errors.append(f"ANALYSIS_FOCUS_EMPTY_FALLBACK_REQUIRES_EMPTY_{field}")
        return errors
    reference_fields = (
        "primary_measure",
        "time_axis",
        "group_axis",
        "geography_axis",
    )
    for field in reference_fields:
        errors.extend(
            _reference_error(
                value.get(field),
                f"ANALYSIS_FOCUS_{field}",
                resolved=resolved,
            )
        )
    if "geography_label" in value:
        errors.extend(
            _reference_error(
                value.get("geography_label"),
                "ANALYSIS_FOCUS_geography_label",
                resolved=resolved,
            )
        )
    comparisons = value.get("comparison_measures")
    if not isinstance(comparisons, list):
        errors.append("ANALYSIS_FOCUS_COMPARISON_MEASURES_MUST_BE_LIST")
    else:
        for index, item in enumerate(comparisons):
            errors.extend(
                _reference_error(
                    item,
                    f"ANALYSIS_FOCUS_COMPARISON_MEASURES:{index}",
                    resolved=resolved,
                )
            )
    association_pairs = value.get("association_pairs", [])
    if not isinstance(association_pairs, list):
        errors.append("ANALYSIS_FOCUS_ASSOCIATION_PAIRS_MUST_BE_LIST")
        association_pairs = []
    association_pair_ids: set[str] = set()
    association_pair_keys: set[tuple[str, str]] = set()
    for index, pair in enumerate(association_pairs):
        label = f"ANALYSIS_FOCUS_ASSOCIATION_PAIR:{index}"
        if not isinstance(pair, dict):
            errors.append(f"{label}:MUST_BE_OBJECT")
            continue
        allowed_pair = {"pair_id", "left_variable", "right_variable"}
        for field in sorted(set(pair) - allowed_pair):
            errors.append(f"{label}:UNKNOWN_FIELD:{field}")
        pair_id = pair.get("pair_id")
        if not _nonempty(pair_id) or pair_id in association_pair_ids:
            errors.append(f"{label}:INVALID_OR_DUPLICATE_PAIR_ID")
        elif isinstance(pair_id, str):
            association_pair_ids.add(pair_id)
        for field in ("left_variable", "right_variable"):
            errors.extend(
                _reference_error(
                    pair.get(field), f"{label}:{field}", resolved=resolved
                )
            )
        if resolved and isinstance(pair, dict):
            left = pair.get("left_variable", {}).get("variable_id")
            right = pair.get("right_variable", {}).get("variable_id")
            if left and right:
                key = tuple(sorted((str(left), str(right))))
                if left == right:
                    errors.append(f"{label}:SELF_PAIR_NOT_ALLOWED")
                if key in association_pair_keys:
                    errors.append(f"{label}:DUPLICATE_VARIABLE_PAIR")
                association_pair_keys.add(key)
    pairs = value.get("sensitivity_pairs")
    if not isinstance(pairs, list):
        errors.append("ANALYSIS_FOCUS_SENSITIVITY_PAIRS_MUST_BE_LIST")
        pairs = []
    pair_ids: set[str] = set()
    for index, pair in enumerate(pairs):
        label = f"ANALYSIS_FOCUS_SENSITIVITY_PAIR:{index}"
        if not isinstance(pair, dict):
            errors.append(f"{label}:MUST_BE_OBJECT")
            continue
        allowed_pair = {
            "pair_id",
            "primary_variable",
            "alternative_variable",
            "require_same_unit",
            "require_same_measurement_scale",
            "time_axis",
            "group_axis",
            "geography_axis",
            "checks",
            "threshold",
            "minimum_pairwise_observations",
        }
        for field in sorted(set(pair) - allowed_pair):
            errors.append(f"{label}:UNKNOWN_FIELD:{field}")
        pair_id = pair.get("pair_id")
        if not _nonempty(pair_id) or pair_id in pair_ids:
            errors.append(f"{label}:INVALID_OR_DUPLICATE_PAIR_ID")
        elif isinstance(pair_id, str):
            pair_ids.add(pair_id)
        for field in (
            "primary_variable",
            "alternative_variable",
            "time_axis",
            "group_axis",
            "geography_axis",
        ):
            errors.extend(
                _reference_error(
                    pair.get(field), f"{label}:{field}", resolved=resolved
                )
            )
        for field in ("require_same_unit", "require_same_measurement_scale"):
            if pair.get(field) is not True:
                errors.append(f"{label}:{field.upper()}_MUST_BE_TRUE")
        checks = pair.get("checks")
        if (
            not isinstance(checks, list)
            or not checks
            or any(check not in SENSITIVITY_CHECKS for check in checks)
            or len(checks) != len(set(checks))
        ):
            errors.append(f"{label}:INVALID_CHECKS")
        if "threshold_classification_agreement" in (checks or []) and not _number(
            pair.get("threshold")
        ):
            errors.append(f"{label}:THRESHOLD_REQUIRED")
        minimum = pair.get("minimum_pairwise_observations")
        if not isinstance(minimum, int) or isinstance(minimum, bool) or minimum < 2:
            errors.append(f"{label}:INVALID_MINIMUM_PAIRWISE_OBSERVATIONS")
    rules = value.get("derived_rules")
    if not isinstance(rules, list):
        errors.append("ANALYSIS_FOCUS_DERIVED_RULES_MUST_BE_LIST")
        rules = []
    rule_ids: set[str] = set()
    for index, rule in enumerate(rules):
        label = f"ANALYSIS_FOCUS_DERIVED_RULE:{index}"
        if not isinstance(rule, dict):
            errors.append(f"{label}:MUST_BE_OBJECT")
            continue
        allowed_rule = {
            "rule_id",
            "operation",
            "input_variable",
            "time_axis",
            "group_axis",
            "threshold",
            "minimum_observations",
            "recent_window_size",
            "previous_window_size",
            "missing_policy",
            "partial_period_policy",
        }
        for field in sorted(set(rule) - allowed_rule):
            errors.append(f"{label}:UNKNOWN_FIELD:{field}")
        rule_id = rule.get("rule_id")
        if not _nonempty(rule_id) or rule_id in rule_ids:
            errors.append(f"{label}:INVALID_OR_DUPLICATE_RULE_ID")
        elif isinstance(rule_id, str):
            rule_ids.add(rule_id)
        operation = rule.get("operation")
        if operation not in DERIVED_OPERATIONS:
            errors.append(f"{label}:INVALID_OPERATION")
        for field in ("input_variable", "time_axis", "group_axis"):
            errors.extend(
                _reference_error(
                    rule.get(field), f"{label}:{field}", resolved=resolved
                )
            )
        if operation in {
            "proportion_below_threshold",
            "consecutive_periods_below_threshold",
        } and not _number(rule.get("threshold")):
            errors.append(f"{label}:THRESHOLD_REQUIRED")
        minimum = rule.get("minimum_observations")
        if not isinstance(minimum, int) or isinstance(minimum, bool) or minimum < 2:
            errors.append(f"{label}:INVALID_MINIMUM_OBSERVATIONS")
        if operation == "window_mean_difference":
            for field in ("recent_window_size", "previous_window_size"):
                size = rule.get(field)
                if not isinstance(size, int) or isinstance(size, bool) or size < 1:
                    errors.append(f"{label}:INVALID_{field.upper()}")
        if rule.get("missing_policy") not in MISSING_POLICIES:
            errors.append(f"{label}:INVALID_MISSING_POLICY")
        if rule.get("partial_period_policy") not in PARTIAL_PERIOD_POLICIES:
            errors.append(f"{label}:INVALID_PARTIAL_PERIOD_POLICY")
    comparisons_by_rule = value.get("derived_group_comparisons", [])
    if not isinstance(comparisons_by_rule, list):
        errors.append(
            "ANALYSIS_FOCUS_DERIVED_GROUP_COMPARISONS_MUST_BE_LIST"
        )
        comparisons_by_rule = []
    comparison_ids: set[str] = set()
    for index, comparison in enumerate(comparisons_by_rule):
        label = f"ANALYSIS_FOCUS_DERIVED_GROUP_COMPARISON:{index}"
        if not isinstance(comparison, dict):
            errors.append(f"{label}:MUST_BE_OBJECT")
            continue
        allowed_comparison = {
            "comparison_id",
            "selector_rule_id",
            "selector_operator",
            "selector_value",
            "comparison_measures",
            "comparison_statistic",
            "minimum_selected_groups",
            "minimum_remaining_groups",
            "minimum_observations_per_group",
            "missing_policy",
            "claim_boundary",
        }
        for field in sorted(set(comparison) - allowed_comparison):
            errors.append(f"{label}:UNKNOWN_FIELD:{field}")
        comparison_id = comparison.get("comparison_id")
        if (
            not _nonempty(comparison_id)
            or comparison_id in comparison_ids
        ):
            errors.append(
                f"{label}:INVALID_OR_DUPLICATE_COMPARISON_ID"
            )
        elif isinstance(comparison_id, str):
            comparison_ids.add(comparison_id)
        if comparison.get("selector_rule_id") not in rule_ids:
            errors.append(f"{label}:SELECTOR_RULE_NOT_FOUND")
        if comparison.get("selector_operator") not in GROUP_SELECTOR_OPERATORS:
            errors.append(f"{label}:INVALID_SELECTOR_OPERATOR")
        if not _number(comparison.get("selector_value")):
            errors.append(f"{label}:INVALID_SELECTOR_VALUE")
        measure_references = comparison.get("comparison_measures")
        if not isinstance(measure_references, list) or not measure_references:
            errors.append(f"{label}:COMPARISON_MEASURES_REQUIRED")
        else:
            for measure_index, reference in enumerate(measure_references):
                errors.extend(
                    _reference_error(
                        reference,
                        f"{label}:COMPARISON_MEASURES:{measure_index}",
                        resolved=resolved,
                    )
                )
        if (
            comparison.get("comparison_statistic")
            not in GROUP_COMPARISON_STATISTICS
        ):
            errors.append(f"{label}:INVALID_COMPARISON_STATISTIC")
        for field in (
            "minimum_selected_groups",
            "minimum_remaining_groups",
            "minimum_observations_per_group",
        ):
            minimum = comparison.get(field)
            if (
                not isinstance(minimum, int)
                or isinstance(minimum, bool)
                or minimum < 1
            ):
                errors.append(f"{label}:INVALID_{field.upper()}")
        if (
            comparison.get("missing_policy")
            not in GROUP_COMPARISON_MISSING_POLICIES
        ):
            errors.append(f"{label}:INVALID_MISSING_POLICY")
        if (
            comparison.get("claim_boundary")
            not in GROUP_COMPARISON_CLAIM_BOUNDARIES
        ):
            errors.append(f"{label}:INVALID_CLAIM_BOUNDARY")
    return errors


def _index_variables(
    variables: list[dict[str, Any]],
) -> tuple[dict[str, dict[str, Any]], dict[tuple[str, str, str], dict[str, Any]]]:
    by_id: dict[str, dict[str, Any]] = {}
    by_triple: dict[tuple[str, str, str], dict[str, Any]] = {}
    for variable in variables:
        if not isinstance(variable, dict):
            continue
        variable_id = str(variable.get("variable_id") or "")
        triple = (
            str(variable.get("source_id") or ""),
            str(variable.get("table_id") or ""),
            str(variable.get("source_column") or ""),
        )
        by_id[variable_id] = variable
        by_triple[triple] = variable
    return by_id, by_triple


def resolve_reference(
    reference: dict[str, Any],
    variables: list[dict[str, Any]],
    *,
    label: str,
) -> dict[str, Any]:
    by_id, by_triple = _index_variables(variables)
    if _nonempty(reference.get("variable_id")):
        variable = by_id.get(str(reference["variable_id"]))
    else:
        variable = by_triple.get(
            (
                str(reference.get("source_id") or ""),
                str(reference.get("table_id") or ""),
                str(reference.get("source_column") or ""),
            )
        )
    if variable is None:
        raise ValueError(f"ANALYSIS_FOCUS_REFERENCE_NOT_FOUND:{label}")
    if variable.get("status") not in USABLE_VARIABLE_STATUSES:
        raise ValueError(
            f"ANALYSIS_FOCUS_VARIABLE_NOT_APPROVED:{label}:"
            f"{variable.get('variable_id')}:{variable.get('status')}"
        )
    return {
        "variable_id": variable["variable_id"],
        "source_id": variable["source_id"],
        "table_id": variable["table_id"],
        "source_column": variable["source_column"],
        "prepared_column": variable["prepared_column"],
        "semantic_role": variable["semantic_role"],
        "measurement_scale": variable["measurement_scale"],
        "analysis_roles": deepcopy(variable["analysis_roles"]),
        "unit": variable.get("unit"),
    }


def _require_role(variable: dict[str, Any], role: str, label: str) -> None:
    if role not in variable.get("analysis_roles", []):
        raise ValueError(
            f"ANALYSIS_FOCUS_ROLE_MISMATCH:{label}:"
            f"{variable.get('variable_id')}:requires={role}"
        )
    if set(variable.get("analysis_roles", [])) & {"QUALITY_ONLY", "EXCLUDED"}:
        raise ValueError(
            f"ANALYSIS_FOCUS_QUALITY_VARIABLE_NOT_ALLOWED:{label}:"
            f"{variable.get('variable_id')}"
        )


def resolve_analysis_focus(
    focus: dict[str, Any] | None,
    variables: list[dict[str, Any]],
    *,
    available_modules: set[str],
) -> dict[str, Any]:
    if focus is None:
        return {
            "schema_version": "analysis_focus.v1",
            "requested_modules": [],
            "primary_measure": {},
            "comparison_measures": [],
            "time_axis": {},
            "group_axis": {},
            "geography_axis": {},
            "association_pairs": [],
            "sensitivity_pairs": [],
            "derived_rules": [],
            "derived_group_comparisons": [],
        }
    errors = validate_analysis_focus(focus)
    if errors:
        raise ValueError("INVALID_ANALYSIS_FOCUS:" + ",".join(errors))
    requested_modules = list(focus["requested_modules"])
    unsupported = [
        module for module in requested_modules if module not in available_modules
    ]
    if unsupported:
        raise ValueError(
            "REQUESTED_MODULE_NOT_SUPPORTED_BY_VARIABLES:" + ",".join(unsupported)
        )
    result: dict[str, Any] = {
        "schema_version": "analysis_focus.v1",
        "requested_modules": requested_modules,
        "primary_measure": resolve_reference(
            focus["primary_measure"], variables, label="primary_measure"
        ),
        "comparison_measures": [
            resolve_reference(item, variables, label=f"comparison_measures:{index}")
            for index, item in enumerate(focus["comparison_measures"])
        ],
        "time_axis": resolve_reference(
            focus["time_axis"], variables, label="time_axis"
        ),
        "group_axis": resolve_reference(
            focus["group_axis"], variables, label="group_axis"
        ),
        "geography_axis": resolve_reference(
            focus["geography_axis"], variables, label="geography_axis"
        ),
        "association_pairs": [],
        "sensitivity_pairs": [],
        "derived_rules": [],
        "derived_group_comparisons": [],
    }
    if "geography_label" in focus:
        result["geography_label"] = resolve_reference(
            focus["geography_label"], variables, label="geography_label"
        )
    _require_role(result["primary_measure"], "MEASURE", "primary_measure")
    for index, variable in enumerate(result["comparison_measures"]):
        _require_role(variable, "MEASURE", f"comparison_measures:{index}")
    _require_role(result["time_axis"], "TIME_AXIS", "time_axis")
    _require_role(result["group_axis"], "GROUP", "group_axis")
    _require_role(result["geography_axis"], "GEO_AXIS", "geography_axis")
    if "geography_label" in result:
        _require_role(result["geography_label"], "GEO_AXIS", "geography_label")
    if "association" in requested_modules and not result["comparison_measures"]:
        if not focus.get("association_pairs"):
            raise ValueError("ASSOCIATION_REQUIRES_COMPARISON_MEASURE_OR_PAIR")
    raw_association_pairs = focus.get("association_pairs")
    if raw_association_pairs:
        for pair in raw_association_pairs:
            resolved_pair = {
                "pair_id": pair["pair_id"],
                "left_variable": resolve_reference(
                    pair["left_variable"],
                    variables,
                    label=f"association:{pair['pair_id']}:left_variable",
                ),
                "right_variable": resolve_reference(
                    pair["right_variable"],
                    variables,
                    label=f"association:{pair['pair_id']}:right_variable",
                ),
            }
            _require_role(
                resolved_pair["left_variable"], "MEASURE", pair["pair_id"]
            )
            _require_role(
                resolved_pair["right_variable"], "MEASURE", pair["pair_id"]
            )
            result["association_pairs"].append(resolved_pair)
    elif "association" in requested_modules:
        for index, comparison in enumerate(result["comparison_measures"], 1):
            result["association_pairs"].append(
                {
                    "pair_id": f"primary-comparison-{index:03d}",
                    "left_variable": deepcopy(result["primary_measure"]),
                    "right_variable": deepcopy(comparison),
                }
            )
    sensitivity_only_ids = {
        pair["alternative_variable"]["variable_id"]
        for pair in result["sensitivity_pairs"]
        if isinstance(pair, dict)
    }
    for pair in focus["sensitivity_pairs"]:
        resolved_pair = deepcopy(pair)
        for field in (
            "primary_variable",
            "alternative_variable",
            "time_axis",
            "group_axis",
            "geography_axis",
        ):
            resolved_pair[field] = resolve_reference(
                pair[field], variables, label=f"sensitivity:{pair['pair_id']}:{field}"
            )
        _require_role(resolved_pair["primary_variable"], "MEASURE", pair["pair_id"])
        _require_role(
            resolved_pair["alternative_variable"], "MEASURE", pair["pair_id"]
        )
        _require_role(resolved_pair["time_axis"], "TIME_AXIS", pair["pair_id"])
        _require_role(resolved_pair["group_axis"], "GROUP", pair["pair_id"])
        _require_role(resolved_pair["geography_axis"], "GEO_AXIS", pair["pair_id"])
        primary = resolved_pair["primary_variable"]
        alternative = resolved_pair["alternative_variable"]
        if pair["require_same_unit"] and (
            not _nonempty(primary.get("unit"))
            or not _nonempty(alternative.get("unit"))
            or str(primary["unit"]).strip().casefold()
            != str(alternative["unit"]).strip().casefold()
        ):
            raise ValueError(
                f"SENSITIVITY_PAIR_INCOMPATIBLE:{pair['pair_id']}:UNIT"
            )
        if pair["require_same_measurement_scale"] and (
            primary.get("measurement_scale")
            != alternative.get("measurement_scale")
            or primary.get("measurement_scale") not in {"INTERVAL", "RATIO"}
        ):
            raise ValueError(
                f"SENSITIVITY_PAIR_INCOMPATIBLE:{pair['pair_id']}:"
                "MEASUREMENT_SCALE"
            )
        result["sensitivity_pairs"].append(resolved_pair)
    sensitivity_only_ids = {
        pair["alternative_variable"]["variable_id"]
        for pair in result["sensitivity_pairs"]
        if isinstance(pair, dict)
    } - {
        item["variable_id"] for item in result["comparison_measures"]
    }
    seen_pairs: set[tuple[str, str]] = set()
    for pair in result["association_pairs"]:
        left = pair["left_variable"]
        right = pair["right_variable"]
        if left["variable_id"] == right["variable_id"]:
            raise ValueError(
                f"ASSOCIATION_PAIR_SELF_REFERENCE:{pair['pair_id']}"
            )
        if (
            left["variable_id"] in sensitivity_only_ids
            or right["variable_id"] in sensitivity_only_ids
        ):
            raise ValueError(
                f"ASSOCIATION_PAIR_USES_SENSITIVITY_ONLY_VARIABLE:"
                f"{pair['pair_id']}"
            )
        for variable in (left, right):
            if variable.get("measurement_scale") not in {"INTERVAL", "RATIO"}:
                raise ValueError(
                    f"ASSOCIATION_PAIR_INCOMPATIBLE_SCALE:{pair['pair_id']}"
                )
        key = tuple(sorted((left["variable_id"], right["variable_id"])))
        if key in seen_pairs:
            raise ValueError(
                f"ASSOCIATION_PAIR_DUPLICATE_VARIABLE_PAIR:{pair['pair_id']}"
            )
        seen_pairs.add(key)
    for rule in focus["derived_rules"]:
        resolved_rule = deepcopy(rule)
        for field, role in (
            ("input_variable", "MEASURE"),
            ("time_axis", "TIME_AXIS"),
            ("group_axis", "GROUP"),
        ):
            resolved_rule[field] = resolve_reference(
                rule[field], variables, label=f"derived:{rule['rule_id']}:{field}"
            )
            _require_role(resolved_rule[field], role, rule["rule_id"])
        result["derived_rules"].append(resolved_rule)
    approved_comparison_ids = {
        item["variable_id"] for item in result["comparison_measures"]
    }
    resolved_rules = {
        rule["rule_id"]: rule for rule in result["derived_rules"]
    }
    for comparison in focus.get("derived_group_comparisons", []):
        resolved_comparison = deepcopy(comparison)
        selector_rule = resolved_rules.get(comparison["selector_rule_id"])
        if selector_rule is None:
            raise ValueError(
                "DERIVED_GROUP_COMPARISON_RULE_NOT_FOUND:"
                f"{comparison['comparison_id']}"
            )
        resolved_comparison["comparison_measures"] = [
            resolve_reference(
                reference,
                variables,
                label=(
                    "derived_group_comparison:"
                    f"{comparison['comparison_id']}:measure:{index}"
                ),
            )
            for index, reference in enumerate(
                comparison["comparison_measures"]
            )
        ]
        for measure in resolved_comparison["comparison_measures"]:
            _require_role(
                measure, "MEASURE", comparison["comparison_id"]
            )
            if measure["variable_id"] not in approved_comparison_ids:
                raise ValueError(
                    "DERIVED_GROUP_COMPARISON_MEASURE_NOT_APPROVED:"
                    f"{comparison['comparison_id']}:{measure['variable_id']}"
                )
        result["derived_group_comparisons"].append(resolved_comparison)
    return result


def build_staged_eda_policy(analysis_focus: dict[str, Any]) -> dict[str, Any]:
    requested = list(analysis_focus["requested_modules"])
    core_modules = list(
        dict.fromkeys(["data_quality", "distribution", *requested])
    )
    return {
        "schema_version": "staged_eda_policy.v1",
        "requested_modules": deepcopy(requested),
        "core_modules": core_modules,
        "stage_1_modules": deepcopy(core_modules),
        "stage_2_modules": deepcopy(requested),
        "stage_2_drilldowns": [
            "outlier_robustness",
            "latest_period_exclusion",
            "association_detail",
            "group_spatial_detail",
        ],
        "stage_2_triggers": [
            "missingness",
            "join_loss",
            "robust_outlier_candidates",
            "distribution_asymmetry",
            "strong_numeric_association",
            "unstable_numeric_association",
        ],
        "stage_3_checks": [
            "coverage",
            "denominator",
            "candidate_sensitivity",
            "declared_definition_sensitivity",
        ],
        "stage_2_requires_recorded_trigger": True,
        "stage_3_applies_to_each_candidate_finding": True,
        "evidence_statuses": ["validated", "qualified", "rejected"],
        "maximum_report_charts": 8,
        "claim_policy": {
            "causal_language": False,
            "prediction_language": False,
            "policy_optimization_language": False,
        },
    }


def build_generic_analysis_recipe(
    analysis_focus: dict[str, Any],
) -> dict[str, Any]:
    return {
        "schema_version": "generic_analysis_recipe.v1",
        "selection_basis": [
            "approved_analysis_focus",
            "frozen_semantic_role",
            "frozen_measurement_scale",
            "frozen_analysis_roles",
            "frozen_allowed_analyses",
            "observed_sample_size",
            "observed_cardinality",
        ],
        "axes": {
            "primary_time_axis": deepcopy(analysis_focus["time_axis"]),
            "primary_group_axis": deepcopy(analysis_focus["group_axis"]),
            "primary_geography_axis": deepcopy(analysis_focus["geography_axis"]),
            **(
                {
                    "geography_label": deepcopy(
                        analysis_focus["geography_label"]
                    )
                }
                if "geography_label" in analysis_focus
                else {}
            ),
        },
        "measures": {
            "primary": deepcopy(analysis_focus["primary_measure"]),
            "comparisons": deepcopy(analysis_focus["comparison_measures"]),
        },
        "association_pairs": deepcopy(
            analysis_focus.get("association_pairs", [])
        ),
        "derived_rules": deepcopy(analysis_focus["derived_rules"]),
        "sensitivity_pairs": deepcopy(analysis_focus["sensitivity_pairs"]),
        "derived_group_comparisons": deepcopy(
            analysis_focus.get("derived_group_comparisons", [])
        ),
        "cost_bounds": {
            "maximum_detailed_measures_per_table": 20,
            "measure_selection_order": [
                "analysis_focus_first",
                "missing_rate_ascending",
                "variable_id_ascending",
            ],
            "maximum_association_pairs_per_table": max(
                1, len(analysis_focus.get("association_pairs", []))
            ),
        },
        "univariate": {
            "statistics": [
                "count",
                "missing_rate",
                "zero_rate",
                "negative_rate",
                "mean",
                "median",
                "standard_deviation",
                "coefficient_of_variation",
                "skewness",
                "quartiles",
                "iqr_outliers",
                "mad_outliers",
            ],
            "skewness_trigger": 1.0,
            "mad_z_threshold": 3.5,
        },
        "temporal": {
            "minimum_periods_for_trend": 3,
            "minimum_periods_for_window_comparison": 5,
            "window_size": 2,
            "derive_absolute_change": True,
            "derive_percentage_point_change_for_percent_units": True,
            "derive_percent_change_only_for_confirmed_ratio_basis": True,
        },
        "group_comparison": {
            "maximum_groups_for_full_chart": 30,
            "minimum_groups": 2,
            "statistics": [
                "group_median",
                "gap_from_overall_median",
                "group_rank",
                "max_min_gap",
            ],
        },
        "association": {
            "minimum_pairwise_rows": 5,
            "strong_threshold": 0.5,
            "methods": ["pearson", "spearman"],
            "check_outlier_sensitivity": True,
            "check_latest_period_sensitivity": True,
            "pair_scope": "frozen_association_pairs_only",
        },
        "spatial_baseline": {
            "geography_axis": deepcopy(analysis_focus["geography_axis"]),
            "geography_label": deepcopy(
                analysis_focus.get("geography_label", {})
            ),
            "primary_measure": deepcopy(analysis_focus["primary_measure"]),
            "outputs": [
                "geography_rank_comparison",
                "geography_time_heatmap",
            ],
            "require_one_to_one_id_label_mapping": True,
            "geometry_methods_allowed": False,
            "geometry_required_methods": [
                "map",
                "spatial_autocorrelation",
                "distance_analysis",
            ],
            "when_geometry_method_is_requested": "REQUEST_USER_LOCAL_FILE",
        },
        "finding_validation": {
            "applies_to_each_candidate": True,
            "check_statuses": [
                "applied",
                "not_applicable",
                "insufficient_data",
                "failed",
            ],
            "minimum_default_denominator": 5,
            "definition_sensitivity_direction_agreement_minimum": 0.8,
            "definition_sensitivity_rank_correlation_minimum": 0.5,
            "definition_sensitivity_classification_agreement_minimum": 0.8,
            "candidate_specific_minimum_denominator": True,
        },
        "visual_selection": {
            "missingness": "heatmap",
            "numeric_distribution": ["histogram_kde", "boxplot"],
            "time_numeric": "line",
            "group_numeric": "ranked_bar",
            "group_time_numeric": "heatmap",
            "numeric_pair": "scatter_regression",
            "numeric_matrix": "correlation_heatmap",
            "selection_rule": (
                "question_module_coverage_then_primary_and_declared_evidence"
            ),
            "maximum_missingness_charts": 1,
            "distribution_scope": "primary_measure_only",
            "temporal_scope": "primary_measure_only",
            "association_scope": "each_frozen_pair",
            "required_requested_module_coverage": True,
            "maximum_group_time_charts": 0,
        },
        "insight_ranking": {
            "status_weight": {
                "validated": 40,
                "qualified": 20,
                "rejected": 0,
            },
            "maximum_report_insights": 8,
            "require_comparison_or_pattern": True,
            "selection_rule": "question_coverage_and_diversity_first",
            "required_evidence_classes": [
                "derived_rule",
                "cohort_comparison",
                "association",
                "sensitivity",
            ],
            "required_requested_module_coverage": True,
            "maximum_per_requested_module": 4,
            "maximum_per_kind": 3,
            "exclude_statuses": ["rejected"],
        },
        "evidence_promotion": {
            "derived_rules": "one_summary_candidate_per_rule",
            "frozen_association_pairs": (
                "one_stage_1_baseline_candidate_per_pair"
            ),
            "sensitivity_pairs": "one_summary_candidate_per_pair",
            "derived_group_comparisons": (
                "one_summary_candidate_per_declared_comparison"
            ),
            "required_question_fields": [
                "requested_module",
                "uses_primary_measure",
                "declared_rule_related",
                "question_relevance",
            ],
        },
        "data_request_policy": {
            "scope": "approved_focus_variables_and_blocked_findings_only",
            "structural_period_gaps_are_not_missing_values": True,
            "table_wide_missingness_alone_creates_request": False,
            "minimum_denominator_source": "candidate_specific_contract",
            "successful_declared_window_creates_request": False,
        },
        "claim_policy": {
            "causal_language": False,
            "prediction_language": False,
            "policy_optimization_language": False,
            "domain_interpretation_requires_user_context": True,
        },
    }


def validate_staged_eda_policy(value: Any) -> list[str]:
    if not isinstance(value, dict):
        return ["STAGED_EDA_POLICY_MUST_BE_OBJECT"]
    errors: list[str] = []
    if value.get("schema_version") != "staged_eda_policy.v1":
        errors.append("INVALID_STAGED_EDA_POLICY_SCHEMA")
    for field in (
        "requested_modules",
        "core_modules",
        "stage_1_modules",
        "stage_2_modules",
    ):
        modules = value.get(field)
        if (
            not isinstance(modules, list)
            or any(module not in ANALYSIS_MODULES for module in modules)
            or len(modules) != len(set(modules))
        ):
            errors.append(f"STAGED_EDA_POLICY_INVALID_{field.upper()}")
    if value.get("stage_1_modules") != value.get("core_modules"):
        errors.append("STAGED_EDA_POLICY_CORE_STAGE_1_MISMATCH")
    requested = value.get("requested_modules") or []
    core = value.get("core_modules") or []
    if not set(requested) <= set(core):
        errors.append("STAGED_EDA_POLICY_REQUESTED_MODULE_NOT_CORE")
    drilldowns = value.get("stage_2_drilldowns")
    if not isinstance(drilldowns, list) or not drilldowns:
        errors.append("STAGED_EDA_POLICY_INVALID_STAGE_2_DRILLDOWNS")
    triggers = value.get("stage_2_triggers")
    if (
        not isinstance(triggers, list)
        or not triggers
        or any(trigger not in STAGE_2_TRIGGERS for trigger in triggers)
    ):
        errors.append("STAGED_EDA_POLICY_INVALID_STAGE_2_TRIGGERS")
    checks = value.get("stage_3_checks")
    if not isinstance(checks, list) or not checks:
        errors.append("STAGED_EDA_POLICY_INVALID_STAGE_3_CHECKS")
    if value.get("stage_2_requires_recorded_trigger") is not True:
        errors.append("STAGED_EDA_POLICY_REQUIRES_STAGE_2_TRIGGER_GATE")
    if value.get("stage_3_applies_to_each_candidate_finding") is not True:
        errors.append("STAGED_EDA_POLICY_REQUIRES_CANDIDATE_VALIDATION")
    if value.get("evidence_statuses") != ["validated", "qualified", "rejected"]:
        errors.append("STAGED_EDA_POLICY_INVALID_EVIDENCE_STATUSES")
    maximum = value.get("maximum_report_charts")
    if not isinstance(maximum, int) or isinstance(maximum, bool) or maximum < 1:
        errors.append("STAGED_EDA_POLICY_INVALID_MAXIMUM_REPORT_CHARTS")
    claim = value.get("claim_policy")
    if (
        not isinstance(claim, dict)
        or claim.get("causal_language") is not False
        or claim.get("prediction_language") is not False
        or claim.get("policy_optimization_language") is not False
    ):
        errors.append("STAGED_EDA_POLICY_INVALID_CLAIM_POLICY")
    return errors


def validate_generic_analysis_recipe(value: Any) -> list[str]:
    if not isinstance(value, dict):
        return ["GENERIC_ANALYSIS_RECIPE_MUST_BE_OBJECT"]
    errors: list[str] = []
    if value.get("schema_version") != "generic_analysis_recipe.v1":
        errors.append("INVALID_GENERIC_ANALYSIS_RECIPE_SCHEMA")
    for field in (
        "selection_basis",
        "axes",
        "measures",
        "derived_rules",
        "derived_group_comparisons",
        "sensitivity_pairs",
        "association_pairs",
        "cost_bounds",
        "univariate",
        "temporal",
        "group_comparison",
        "association",
        "spatial_baseline",
        "finding_validation",
        "visual_selection",
        "insight_ranking",
        "evidence_promotion",
        "data_request_policy",
        "claim_policy",
    ):
        if field not in value:
            errors.append(f"GENERIC_ANALYSIS_RECIPE_MISSING_FIELD:{field}")
    if value.get("cost_bounds", {}).get("maximum_detailed_measures_per_table") != 20:
        errors.append("GENERIC_ANALYSIS_RECIPE_INVALID_MEASURE_BOUND")
    if value.get("univariate", {}).get("mad_z_threshold") != 3.5:
        errors.append("GENERIC_ANALYSIS_RECIPE_INVALID_MAD_THRESHOLD")
    if value.get("association", {}).get("strong_threshold") != 0.5:
        errors.append("GENERIC_ANALYSIS_RECIPE_INVALID_ASSOCIATION_THRESHOLD")
    pairs = value.get("association_pairs")
    if not isinstance(pairs, list):
        errors.append("GENERIC_ANALYSIS_RECIPE_INVALID_ASSOCIATION_PAIRS")
    if value.get("association", {}).get("pair_scope") != (
        "frozen_association_pairs_only"
    ):
        errors.append("GENERIC_ANALYSIS_RECIPE_INVALID_PAIR_SCOPE")
    spatial = value.get("spatial_baseline", {})
    if (
        not isinstance(spatial, dict)
        or spatial.get("geometry_methods_allowed") is not False
        or spatial.get("require_one_to_one_id_label_mapping") is not True
    ):
        errors.append("GENERIC_ANALYSIS_RECIPE_INVALID_SPATIAL_BASELINE")
    finding_validation = value.get("finding_validation", {})
    if (
        not isinstance(finding_validation, dict)
        or finding_validation.get("applies_to_each_candidate") is not True
        or finding_validation.get("check_statuses")
        != [
            "applied",
            "not_applicable",
            "insufficient_data",
            "failed",
        ]
    ):
        errors.append("GENERIC_ANALYSIS_RECIPE_INVALID_FINDING_VALIDATION")
    if value.get("insight_ranking", {}).get("maximum_report_insights") != 8:
        errors.append("GENERIC_ANALYSIS_RECIPE_INVALID_INSIGHT_BOUND")
    if value.get("insight_ranking", {}).get("exclude_statuses") != [
        "rejected"
    ]:
        errors.append("GENERIC_ANALYSIS_RECIPE_INVALID_STATUS_EXCLUSION")
    visual = value.get("visual_selection", {})
    if (
        visual.get("maximum_missingness_charts") != 1
        or visual.get("distribution_scope") != "primary_measure_only"
        or visual.get("association_scope") != "each_frozen_pair"
        or visual.get("required_requested_module_coverage") is not True
    ):
        errors.append("GENERIC_ANALYSIS_RECIPE_INVALID_VISUAL_SELECTION")
    promotion = value.get("evidence_promotion", {})
    if (
        promotion.get("derived_rules")
        != "one_summary_candidate_per_rule"
        or promotion.get("frozen_association_pairs")
        != "one_stage_1_baseline_candidate_per_pair"
        or promotion.get("sensitivity_pairs")
        != "one_summary_candidate_per_pair"
    ):
        errors.append("GENERIC_ANALYSIS_RECIPE_INVALID_EVIDENCE_PROMOTION")
    request_policy = value.get("data_request_policy", {})
    if (
        request_policy.get("table_wide_missingness_alone_creates_request")
        is not False
        or request_policy.get("successful_declared_window_creates_request")
        is not False
    ):
        errors.append("GENERIC_ANALYSIS_RECIPE_INVALID_DATA_REQUEST_POLICY")
    claim = value.get("claim_policy", {})
    if (
        claim.get("causal_language") is not False
        or claim.get("prediction_language") is not False
        or claim.get("policy_optimization_language") is not False
    ):
        errors.append("GENERIC_ANALYSIS_RECIPE_INVALID_CLAIM_POLICY")
    return errors
