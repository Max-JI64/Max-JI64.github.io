---
name: plan-multi-source-analysis
description: Plan approval-gated exploratory analysis across user-provided local CSV, TSV, XLSX, or tabular JSON sources. Use when Codex must inventory structured sources, classify variable semantics and measurement scales, protect sensitive fields, assess join safety, resolve high-impact ambiguity, propose feasible questions, or prepare a traceable execution request without network access or analysis before approval.
---

# Plan Multi-Source Analysis

Create a platform-neutral, evidence-backed analysis blueprint. Treat multi-source
compatibility as the primary problem. Never make an unsafe join or start execution
before the user approves a complete blueprint.

## Load the relevant rules

- Read [input-contract.md](references/input-contract.md) before normalizing inputs.
- Read [multi-source-joins.md](references/multi-source-joins.md) whenever two or
  more sources may be combined.
- Read [analysis-catalog.md](references/analysis-catalog.md) before proposing
  questions or analysis steps.
- Read [variable-semantics.md](references/variable-semantics.md) before assigning
  semantic roles, measurement scales, or allowed analyses.
- Read [output-contract.md](references/output-contract.md) before emitting a
  blueprint or an approved execution request.

## Workflow

1. Normalize the request as `analysis_planning_request.v1`.
   - When the request is supplied as run settings, generate it with
     `scripts/build_planning_request.py SETTINGS.json --output REQUEST.json`;
     never hand-edit the generated request.
   - Require at least one source.
   - Accept only files the user has already provided in the local workspace.
   - Never browse the web, call a data API, or download a missing source.
     Generate a `user_data_requests` item and ask the user to provide the file.
   - Accept a missing or vague user question.
   - Accept provenance and license as optional, user-supplied metadata.
   - When details are missing, offer one non-blocking prompt such as
     `아는 범위만 적어주세요: 제공한 파일의 출처, 직접 생성 여부, 또는 출처 모름`.
     Continue planning if the user skips it.
   - Preserve missing values as `PARTIAL` or `UNKNOWN`; never invent them and
     never block analysis solely because provenance or license is missing.
   - When the user has declared an execution-specific analysis focus, encode
     requested modules, primary/comparison measures, primary time/group/
     geography axes, sensitivity pairs, derived rules, and any rule-selected
     group comparison in `analysis_focus`.
     Source/table/column references are run-specific data, not Skill constants.
2. Inventory every source.
   - Run `scripts/inspect_sources.py REQUEST.json --output INVENTORY.json` for
     local structured sources.
   - For CSV, XLSX, and tabular JSON, use the reported tables, columns, inferred
     types, candidate keys, row counts, profile completeness, and observed time
     ranges.
   - Reject PDF, image, free-form document, and remote-file locations in this
     MVP. Ask the user to provide a local structured file; never acquire it on
     the user's behalf.
   - Read `structure_confirmation_requests` before building questions.
   - Treat structure confirmations as advisory. Continue planning when the user
     does not answer, preserve each item in limitations, and allow later
     correction if preparation or analysis exposes a material problem.
   - Accept answers through `declared_grain` and `dataset_structure`, then
     refresh inspection when practical.
   - Never infer observation meaning, temporal cadence, time-field meaning, or
     measure aggregation semantics as confirmed facts. Record them as unknown
     while continuing the best-effort analysis.
3. Build `variable_inventory.v1` before generating questions.
   - Run `scripts/build_variable_inventory.py REQUEST.json INVENTORY.json
     --output VARIABLES.json --review-output REVIEW.json`.
   - Use only the restricted overlay and confirmation contracts documented in
     `variable-semantics.md`.
   - Apply `variable_metadata_overrides` before overlays and confirmation
     gating. This restricted user-confirmed metadata may correct an
     `AUTO_CONFIDENT` role but may never make an excluded sensitive variable a
     general analysis input.
   - If high-impact ambiguity remains, stop at
     `NEEDS_VARIABLE_CONFIRMATION`. Ask once for the generated batch and do not
     create question candidates.
4. Build `analysis_blueprint.v1` deterministically.
   - Run
     `scripts/build_blueprint.py REQUEST.json INVENTORY.json
     --variable-inventory VARIABLES.json --output BLUEPRINT.json`.
   - Let the generator decide status, join strategy, module availability,
     candidate structure, analysis steps, validation, and deliverables.
   - Resolve every analysis-focus reference to a frozen variable ID. Reject
     missing, disallowed, role-incompatible, or unit/scale-incompatible
     references instead of guessing.
   - Include the proposed `staged_eda_policy.v1` and
     `generic_analysis_recipe.v1` in the Blueprint so modules, thresholds,
     derived rules, sensitivity checks, evidence promotion, question-coverage
     ranking, data-request gates, triggers, charts, and claim boundaries are
     reviewable before approval.
   - Freeze resolved association pairs. By default use only the primary measure
     crossed with each comparison measure. Keep alternative-definition
     variables sensitivity-only unless they are also declared comparisons.
   - Treat every requested temporal, group, spatial, or association module as a
     core baseline. Reserve stage 2 for triggered drilldowns.
   - Never handwrite or structurally edit the generated contract.
   - If useful, refine only question text, rationale, and rank through
     `question_refinements.v1` and rebuild with `--question-refinements`.
5. Resolve question selection.
   - Preserve a feasible explicit exploratory question.
   - When status is `NEEDS_QUESTION_SELECTION`, present the generated candidates
     and wait for the user to choose a `question_id`.
   - Rebuild with `--select-question QUESTION_ID`; do not insert the selection
     manually.
6. Review combination feasibility.
   - Confirm that an `INTEGRATED` plan uses only a connected set of safe
     one-to-one joins with a common composite key, positive profiled overlap,
     and aligned time, geography, and units.
   - Keep review-required, many-to-many, unit-conflicted, or disconnected inputs
     under `SEPARATE`.
7. Validate the generated blueprint.
   - Run `scripts/validate_contract.py blueprint BLUEPRINT.json`.
   - Fix contract errors before showing the plan.
8. Stop for approval.
   - Present the question, sources, join decision, analysis steps, validation,
     deliverables, frozen preparation operations, and material risks.
   - Do not extract, transform, join, analyze, or dispatch another Skill while
     approval is pending.
9. After explicit approval, create `analysis_execution_request.v1`.
   - Run
     `scripts/build_execution_request.py BLUEPRINT.json --approved-by user --output EXECUTION.json`.
   - Do not invoke this generator without explicit user approval.
   - Freeze the question, source identifiers, join plan,
     preparation plan, analysis focus, staged EDA policy, generic recipe,
     analysis steps, validation, and task order.
   - Deep-copy those approved Blueprint fields exactly. The execution generator
     must not add modules, rules, thresholds, or chart policies after approval.
   - Freeze `data_access_policy.v1` as `USER_PROVIDED_LOCAL_ONLY`, with network
     access and remote fetching disabled and missing data routed to the user.
   - Validate with `scripts/validate_contract.py execution REQUEST.json`.
   - Dispatch only to real, available executors. Never simulate their results.

## Decision discipline

- Keep structural inspection, blueprint construction, and contract validation
  deterministic.
- Select measures, groups, time axes, and geography axes from the approved
  variable policy, never from physical type alone.
- Use model judgment only through the question refinement overlay; never change
  source requirements, modules, feasibility, risks, joins, or status directly.
- Separate observed metadata from assumptions and requested user confirmation.
- Preserve source-level provenance through every proposed join and deliverable.
- Analyze only user-provided local files and approved derived local artifacts.
  Additional data needs are user requests, never autonomous collection tasks.
- Carry incomplete provenance as a disclosure and trace requirement. Unknown
  licensing may affect later redistribution review, not whether analysis can
  proceed.
- Reject prediction, causal effects, and decision optimization in v1. Reframe
  them as descriptive, comparative, temporal, spatial, association, anomaly, or
  cross-source consistency questions when useful.
- Treat statistical association as non-causal.
- Do not expose sensitive row values in the blueprint; report structure and
  aggregate diagnostics only.

## Representative requests

- "이 두 공공데이터를 결합해 어떤 분석을 할지 설계해줘."
- "질문은 아직 없는데, 이 CSV와 엑셀로 분석 가능한 주제를 제안해줘."
- "지역별 통계 두 개를 합쳐 비교해도 되는지 먼저 확인해줘."

The first milestone ends at a validated execution request. Data preparation,
exploratory computation, and reporting belong to downstream Skills.
