#!/usr/bin/env python3
"""Prepare approved CSV/TSV sources and emit deterministic audit artifacts."""

from __future__ import annotations

import argparse
import csv
from datetime import datetime
from decimal import Decimal, InvalidOperation
import hashlib
import json
from pathlib import Path
import re
import sys
from typing import Any, Iterable
from urllib.parse import urlparse


if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")


EXECUTION_SCHEMA = "analysis_execution_request.v1"
PLAN_SCHEMA = "data_preparation_plan.v1"
MANIFEST_SCHEMA = "preparation_manifest.v1"
VARIABLE_INVENTORY_SCHEMA = "variable_inventory.v1"
ALLOWED_FORMATS = {"csv", "tsv"}
ALLOWED_TYPES = {"string", "integer", "number", "boolean", "datetime"}
PREPARATION_AUDITS = {
    "unit_conversion_audit",
    "temporal_alignment_audit",
    "geography_key_alignment_audit",
    "grain_cardinality_resolution",
}


class ContractError(ValueError):
    """An approval, contract, or authorization failure."""


class DataSafetyError(ValueError):
    """A full-data condition that blocks safe preparation."""

    def __init__(self, code: str, evidence: dict[str, Any] | None = None):
        super().__init__(code)
        self.code = code
        self.evidence = evidence or {}


def _load_json(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(payload, dict):
        raise ContractError("TOP_LEVEL_JSON_MUST_BE_OBJECT")
    return payload


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(65_536), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _safe_name(value: str) -> str:
    name = re.sub(r"[^0-9A-Za-z가-힣_-]+", "-", value).strip("-_")
    if not name:
        raise ContractError("EMPTY_ARTIFACT_NAME")
    return name


def _is_remote(value: str) -> bool:
    parsed = urlparse(value)
    return parsed.scheme.lower() in {"http", "https"} and bool(parsed.netloc)


def _resolve_location(value: str, execution_path: Path) -> Path:
    if _is_remote(value):
        raise ContractError(
            "REMOTE_SOURCE_FORBIDDEN:REQUEST_USER_PROVIDED_LOCAL_FILE"
        )
    path = Path(value)
    if not path.is_absolute():
        path = (execution_path.parent / path).resolve()
    if not path.is_file():
        raise ContractError(
            f"USER_PROVIDED_LOCAL_SOURCE_NOT_FOUND:REQUEST_USER:{path}"
        )
    return path


def _canonical_json_bytes(payload: dict[str, Any]) -> bytes:
    return (
        json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    ).encode("utf-8")


def _validate_execution(
    payload: dict[str, Any], execution_path: Path
) -> list[dict[str, Any]]:
    if payload.get("schema_version") != EXECUTION_SCHEMA:
        raise ContractError(f"EXPECTED_SCHEMA:{EXECUTION_SCHEMA}")
    approval = payload.get("approval")
    if (
        not isinstance(approval, dict)
        or approval.get("status") != "APPROVED"
        or not isinstance(approval.get("approved_by"), str)
        or not approval["approved_by"].strip()
    ):
        raise ContractError("EXPLICIT_APPROVAL_REQUIRED")
    data_policy = payload.get("data_access_policy")
    if (
        not isinstance(data_policy, dict)
        or data_policy.get("schema_version") != "data_access_policy.v1"
        or data_policy.get("mode") != "USER_PROVIDED_LOCAL_ONLY"
        or data_policy.get("network_access") is not False
        or data_policy.get("remote_fetch") is not False
        or data_policy.get("when_data_is_missing") != "REQUEST_USER"
    ):
        raise ContractError("USER_PROVIDED_LOCAL_DATA_POLICY_REQUIRED")
    source_refs = payload.get("source_refs")
    if (
        not isinstance(source_refs, list)
        or not 1 <= len(source_refs) <= 3
        or not all(isinstance(value, str) and value for value in source_refs)
        or len(set(source_refs)) != len(source_refs)
    ):
        raise ContractError("UNSUPPORTED_SOURCE_COUNT_MVP")
    frozen_variables = payload.get("frozen_variable_inventory")
    if (
        not isinstance(frozen_variables, dict)
        or frozen_variables.get("schema_version") != VARIABLE_INVENTORY_SCHEMA
        or frozen_variables.get("status") != "READY"
        or not isinstance(frozen_variables.get("variables"), list)
        or frozen_variables.get("confirmation_requests") != []
    ):
        raise ContractError("RESOLVED_FROZEN_VARIABLE_INVENTORY_REQUIRED")
    variables_by_table: dict[tuple[str, str], list[dict[str, Any]]] = {}
    variable_ids: set[str] = set()
    variable_source_ids: set[str] = set()
    metadata_keys = (
        "variable_id",
        "source_column",
        "prepared_column",
        "physical_type",
        "semantic_role",
        "measurement_scale",
        "analysis_roles",
        "unit",
        "status",
        "allowed_analyses",
        "prohibited_analyses",
    )
    for variable in frozen_variables["variables"]:
        if not isinstance(variable, dict):
            raise ContractError("FROZEN_VARIABLE_MUST_BE_OBJECT")
        variable_id = variable.get("variable_id")
        source_id = variable.get("source_id")
        table_id = variable.get("table_id")
        if (
            not isinstance(variable_id, str)
            or not variable_id
            or variable_id in variable_ids
            or not isinstance(source_id, str)
            or not source_id
            or not isinstance(table_id, str)
            or not table_id
            or variable.get("status")
            not in {
                "AUTO_CONFIDENT", "USER_CONFIRMED", "UNKNOWN",
                "EXCLUDED_SENSITIVE", "LLM_SUGGESTED",
            }
        ):
            raise ContractError("INVALID_FROZEN_VARIABLE_METADATA")
        variable_ids.add(variable_id)
        variable_source_ids.add(source_id)
        variables_by_table.setdefault((source_id, table_id), []).append(variable)
    if not set(source_refs) <= variable_source_ids:
        raise ContractError("SOURCE_REFS_NOT_COVERED_BY_VARIABLE_INVENTORY")
    plan = payload.get("frozen_preparation_plan")
    if not isinstance(plan, dict) or plan.get("schema_version") != PLAN_SCHEMA:
        raise ContractError("FROZEN_PREPARATION_PLAN_REQUIRED")
    if plan.get("mvp_limits") != {
        "formats": ["csv", "tsv"],
        "maximum_sources": 3,
    }:
        raise ContractError("INVALID_MVP_LIMITS")
    join_output = plan.get("join_output")
    if join_output != {"mode": "INNER", "prefix_non_key_columns": True}:
        raise ContractError("INVALID_JOIN_OUTPUT_POLICY")
    audits = plan.get("required_audits")
    if not isinstance(audits, list) or any(
        audit not in PREPARATION_AUDITS for audit in audits
    ):
        raise ContractError("INVALID_REQUIRED_AUDITS")
    sources = plan.get("sources")
    if not isinstance(sources, list) or len(sources) != len(source_refs):
        raise ContractError("FROZEN_PREPARATION_SOURCES_MISMATCH")
    source_by_id: dict[str, dict[str, Any]] = {}
    for source in sources:
        if not isinstance(source, dict):
            raise ContractError("PREPARATION_SOURCE_MUST_BE_OBJECT")
        source_id = source.get("source_id")
        if source_id not in source_refs or source_id in source_by_id:
            raise ContractError("PREPARATION_SOURCE_ID_MISMATCH")
        fmt = source.get("format")
        if fmt not in ALLOWED_FORMATS:
            raise ContractError(f"UNSUPPORTED_FORMAT_MVP:{fmt}")
        location = source.get("location")
        if not isinstance(location, str) or not location.strip():
            raise ContractError(f"SOURCE_LOCATION_REQUIRED:{source_id}")
        resolved = _resolve_location(location, execution_path)
        tables = source.get("tables")
        if not isinstance(tables, list) or len(tables) != 1:
            raise ContractError(
                f"EXACTLY_ONE_TABLE_PER_SOURCE_REQUIRED_MVP:{source_id}"
            )
        table = tables[0]
        if not isinstance(table, dict) or not isinstance(
            table.get("table_id"), str
        ):
            raise ContractError(f"TABLE_PLAN_REQUIRED:{source_id}")
        expected_variable_metadata = [
            {key: variable.get(key) for key in metadata_keys}
            for variable in sorted(
                variables_by_table.get(
                    (source_id, str(table.get("table_id"))), []
                ),
                key=lambda item: str(item.get("variable_id")),
            )
        ]
        if (
            not expected_variable_metadata
            or table.get("variable_metadata") != expected_variable_metadata
        ):
            raise ContractError(
                f"VARIABLE_METADATA_NOT_FROZEN:{source_id}"
            )
        transformations = table.get("approved_transformations")
        if not isinstance(transformations, list) or len(transformations) != 2:
            raise ContractError(f"UNAPPROVED_TRANSFORMATION:{source_id}")
        if [
            item.get("operation") if isinstance(item, dict) else None
            for item in transformations
        ] != ["normalize_columns", "coerce_types"]:
            raise ContractError(f"UNAPPROVED_TRANSFORMATION:{source_id}")
        mapping = transformations[0].get("column_mapping")
        target_types = transformations[1].get("target_types")
        if (
            not isinstance(mapping, dict)
            or not mapping
            or not all(
                isinstance(key, str)
                and key
                and isinstance(value, str)
                and value
                for key, value in mapping.items()
            )
            or len(set(mapping.values())) != len(mapping)
        ):
            raise ContractError(f"INVALID_COLUMN_MAPPING:{source_id}")
        if (
            not isinstance(target_types, dict)
            or set(target_types) != set(mapping.values())
            or any(value not in ALLOWED_TYPES for value in target_types.values())
        ):
            raise ContractError(f"INVALID_TARGET_TYPES:{source_id}")
        for variable in expected_variable_metadata:
            if (
                variable.get("source_column") not in mapping
                or mapping[variable["source_column"]]
                != variable.get("prepared_column")
                or variable.get("prepared_column") not in target_types
            ):
                raise ContractError(
                    f"VARIABLE_COLUMN_MAPPING_MISMATCH:{source_id}"
                )
        key_columns = table.get("key_columns", [])
        if not isinstance(key_columns, list) or any(
            key not in mapping.values() for key in key_columns
        ):
            raise ContractError(f"INVALID_KEY_COLUMNS:{source_id}")
        source_copy = dict(source)
        source_copy["_resolved_location"] = resolved
        source_by_id[source_id] = source_copy
    if set(source_by_id) != set(source_refs):
        raise ContractError("FROZEN_PREPARATION_SOURCES_MISMATCH")

    tasks = payload.get("tasks")
    if not isinstance(tasks, list):
        raise ContractError("TASKS_REQUIRED")
    clean_tasks: dict[str, dict[str, Any]] = {}
    join_tasks: list[dict[str, Any]] = []
    for task in tasks:
        if not isinstance(task, dict) or not isinstance(task.get("inputs"), dict):
            raise ContractError("INVALID_TASK")
        if task.get("task_type") == "clean_transform":
            if task.get("executor") != "prepare-multi-source-data":
                raise ContractError("CLEAN_TRANSFORM_EXECUTOR_MISMATCH")
            source_id = task["inputs"].get("source_id")
            if source_id in clean_tasks or source_id not in source_by_id:
                raise ContractError("CLEAN_TRANSFORM_SOURCE_MISMATCH")
            if task["inputs"].get("preparation_source") != {
                key: value
                for key, value in source_by_id[source_id].items()
                if not key.startswith("_")
            }:
                raise ContractError("CLEAN_TRANSFORM_PLAN_NOT_FROZEN")
            clean_tasks[source_id] = task
        elif task.get("task_type") == "join_sources":
            join_tasks.append(task)
    if set(clean_tasks) != set(source_refs):
        raise ContractError("ONE_CLEAN_TRANSFORM_PER_SOURCE_REQUIRED")

    join_plan = payload.get("frozen_join_plan")
    if not isinstance(join_plan, dict):
        raise ContractError("FROZEN_JOIN_PLAN_REQUIRED")
    strategy = join_plan.get("strategy")
    joins = join_plan.get("joins")
    if strategy == "INTEGRATED":
        if (
            len(source_refs) not in {2, 3}
            or not isinstance(joins, list)
            or len(joins) != len(source_refs) - 1
        ):
            raise ContractError("INTEGRATED_REQUIRES_CONNECTED_JOIN_TREE")
        if audits:
            raise ContractError("INTEGRATED_HAS_UNRESOLVED_ALIGNMENT_AUDIT")
        connected: set[str] = set()
        for join in joins:
            if (
                not isinstance(join, dict)
                or join.get("cardinality") != "ONE_TO_ONE"
                or join.get("safety") != "SAFE_CANDIDATE"
                or not isinstance(join.get("sampled_key_overlap"), (int, float))
                or isinstance(join.get("sampled_key_overlap"), bool)
                or join["sampled_key_overlap"] <= 0
                or join.get("unit_conflicts")
                or join.get("measure_unit_conflicts")
                or join.get("alignment_issues")
                or join.get("left_source_id") not in source_refs
                or join.get("right_source_id") not in source_refs
            ):
                raise ContractError("UNSAFE_JOIN_BLOCKED")
            connected.update(
                [join["left_source_id"], join["right_source_id"]]
            )
        if connected != set(source_refs):
            raise ContractError("INTEGRATED_JOIN_TREE_NOT_CONNECTED")
        if len(join_tasks) != 1:
            raise ContractError("INTEGRATED_JOIN_TASK_REQUIRED")
        task = join_tasks[0]
        if task.get("executor") != "prepare-multi-source-data":
            raise ContractError("JOIN_EXECUTOR_MISMATCH")
        inputs = task["inputs"]
        if (
            inputs.get("join_plan") != join_plan
            or inputs.get("join_output") != join_output
            or inputs.get("required_audits") != audits
        ):
            raise ContractError("JOIN_TASK_PLAN_NOT_FROZEN")
    elif strategy in {"SEPARATE", "NO_JOIN_REQUIRED"}:
        if joins not in (None, []) or join_tasks:
            raise ContractError("NON_INTEGRATED_REQUEST_MUST_NOT_JOIN")
    else:
        raise ContractError(f"UNSUPPORTED_JOIN_STRATEGY:{strategy}")
    return [source_by_id[source_id] for source_id in source_refs]


def _read_table(
    source: dict[str, Any],
) -> tuple[list[str], list[list[str]]]:
    delimiter = "," if source["format"] == "csv" else "\t"
    path: Path = source["_resolved_location"]
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.reader(handle, delimiter=delimiter))
    if not rows:
        raise DataSafetyError(
            "EMPTY_SOURCE_FILE", {"source_id": source["source_id"]}
        )
    header = rows[0]
    if not header or any(not value for value in header):
        raise DataSafetyError(
            "INVALID_EMPTY_HEADER", {"source_id": source["source_id"]}
        )
    if len(set(header)) != len(header):
        raise DataSafetyError(
            "DUPLICATE_INPUT_HEADER", {"source_id": source["source_id"]}
        )
    for row_number, row in enumerate(rows[1:], 2):
        if len(row) != len(header):
            raise DataSafetyError(
                "ROW_WIDTH_MISMATCH",
                {
                    "source_id": source["source_id"],
                    "row_number": row_number,
                },
            )
    return header, rows[1:]


def _convert(value: str, target: str) -> str:
    if value == "":
        return ""
    if target == "string":
        return value
    stripped = value.strip()
    if target == "integer":
        if not re.fullmatch(r"[+-]?\d+", stripped):
            raise ValueError("not an integer")
        return str(int(stripped))
    if target == "number":
        try:
            number = Decimal(stripped.replace(",", ""))
        except InvalidOperation as exc:
            raise ValueError("not a number") from exc
        if not number.is_finite():
            raise ValueError("number must be finite")
        normalized = format(number.normalize(), "f")
        return "0" if normalized in {"-0", "+0"} else normalized
    if target == "boolean":
        lowered = stripped.lower()
        if lowered in {"true", "yes", "y"}:
            return "true"
        if lowered in {"false", "no", "n"}:
            return "false"
        raise ValueError("not a boolean")
    if target == "datetime":
        candidates = (
            stripped,
            stripped.replace("Z", "+00:00"),
            stripped.replace("/", "-"),
        )
        for candidate in candidates:
            try:
                return datetime.fromisoformat(candidate).isoformat()
            except ValueError:
                continue
        raise ValueError("not an ISO-compatible datetime")
    raise ValueError(f"unsupported target type {target}")


def _duplicate_count(
    header: list[str], rows: list[list[str]], keys: list[str]
) -> int | None:
    if not keys:
        return None
    positions = [header.index(key) for key in keys]
    counts: dict[tuple[str, ...], int] = {}
    for row in rows:
        key = tuple(row[position] for position in positions)
        counts[key] = counts.get(key, 0) + 1
    return sum(count - 1 for count in counts.values() if count > 1)


def _prepare_source(source: dict[str, Any]) -> dict[str, Any]:
    path: Path = source["_resolved_location"]
    before_hash = _sha256(path)
    input_header, input_rows = _read_table(source)
    table = source["tables"][0]
    expected = table.get("row_count_expected")
    if isinstance(expected, int) and len(input_rows) != expected:
        raise DataSafetyError(
            "ROW_COUNT_CHANGED_SINCE_APPROVAL",
            {
                "source_id": source["source_id"],
                "expected": expected,
                "observed": len(input_rows),
            },
        )
    normalize, coerce = table["approved_transformations"]
    mapping = normalize["column_mapping"]
    if set(input_header) != set(mapping):
        raise DataSafetyError(
            "HEADER_CHANGED_SINCE_APPROVAL",
            {
                "source_id": source["source_id"],
                "expected": list(mapping),
                "observed": input_header,
            },
        )
    output_header = [mapping[column] for column in input_header]
    target_types = coerce["target_types"]
    output_rows: list[list[str]] = []
    for row_number, row in enumerate(input_rows, 2):
        converted: list[str] = []
        for column, value in zip(output_header, row):
            try:
                converted.append(_convert(value, target_types[column]))
            except ValueError as exc:
                raise DataSafetyError(
                    "TYPE_COERCION_FAILED",
                    {
                        "source_id": source["source_id"],
                        "row_number": row_number,
                        "column": column,
                        "target_type": target_types[column],
                        "reason": str(exc),
                    },
                ) from exc
        output_rows.append(converted)
    after_hash = _sha256(path)
    if before_hash != after_hash:
        raise DataSafetyError(
            "SOURCE_CHANGED_DURING_PREPARATION",
            {"source_id": source["source_id"]},
        )
    key_columns = table.get("key_columns", [])
    return {
        "source_id": source["source_id"],
        "path": path,
        "table_id": table["table_id"],
        "input_header": input_header,
        "header": output_header,
        "rows": output_rows,
        "target_types": target_types,
        "key_columns": key_columns,
        "duplicate_key_count": _duplicate_count(
            output_header, output_rows, key_columns
        ),
        "input_sha256_before": before_hash,
        "input_sha256_after": after_hash,
        "approved_transformations": table["approved_transformations"],
        "variable_metadata": table["variable_metadata"],
        "provenance_status": source.get("provenance_status", "UNKNOWN"),
        "missing_provenance": source.get("missing_provenance", []),
        "provenance_note": source.get("provenance_note"),
    }


def _join_prepared(
    payload: dict[str, Any], prepared: list[dict[str, Any]]
) -> dict[str, Any] | None:
    join_plan = payload["frozen_join_plan"]
    if join_plan["strategy"] != "INTEGRATED":
        return None
    by_id = {item["source_id"]: item for item in prepared}
    joins = join_plan["joins"]
    canonical_keys = list(joins[0].get("keys", []))
    if not canonical_keys or any(
        list(join.get("keys", [])) != canonical_keys for join in joins
    ):
        raise ContractError("MULTI_SOURCE_JOIN_KEYS_MUST_MATCH")

    def output_keys(item: dict[str, Any], originals: list[str]) -> list[str]:
        mapping = item["approved_transformations"][0]["column_mapping"]
        try:
            return [mapping[column] for column in originals]
        except KeyError as exc:
            raise ContractError("JOIN_KEY_NOT_IN_APPROVED_MAPPING") from exc

    keys_by_source: dict[str, list[str]] = {}
    for join in joins:
        for source_field, columns_field in (
            ("left_source_id", "left_columns"),
            ("right_source_id", "right_columns"),
        ):
            source_id = join.get(source_field)
            originals = join.get(columns_field)
            if (
                source_id not in by_id
                or not isinstance(originals, list)
                or len(originals) != len(canonical_keys)
            ):
                raise ContractError("JOIN_COLUMN_MAPPING_REQUIRED")
            prepared_keys = output_keys(by_id[source_id], originals)
            if len(set(prepared_keys)) != len(prepared_keys):
                raise ContractError("JOIN_KEYS_MUST_BE_UNIQUE_COLUMNS")
            if (
                source_id in keys_by_source
                and keys_by_source[source_id] != prepared_keys
            ):
                raise ContractError("SOURCE_JOIN_KEY_MAPPING_DRIFT")
            keys_by_source[source_id] = prepared_keys
    if set(keys_by_source) != set(by_id):
        raise ContractError("INTEGRATED_JOIN_TREE_NOT_CONNECTED")

    def keyed(
        item: dict[str, Any], keys: list[str]
    ) -> tuple[dict[tuple[str, ...], list[str]], int]:
        positions = [item["header"].index(key) for key in keys]
        result: dict[tuple[str, ...], list[str]] = {}
        duplicates = 0
        for row in item["rows"]:
            key = tuple(row[position] for position in positions)
            if key in result:
                duplicates += 1
            else:
                result[key] = row
        return result, duplicates

    keyed_by_source: dict[str, dict[tuple[str, ...], list[str]]] = {}
    duplicate_counts: dict[str, int] = {}
    for source_id in sorted(by_id):
        keyed_rows, duplicates = keyed(
            by_id[source_id], keys_by_source[source_id]
        )
        keyed_by_source[source_id] = keyed_rows
        duplicate_counts[source_id] = duplicates
    if any(duplicate_counts.values()):
        raise DataSafetyError(
            "FULL_DATA_ONE_TO_ONE_VIOLATION",
            {
                "duplicate_key_counts": duplicate_counts,
            },
        )
    key_sets = [set(rows) for rows in keyed_by_source.values()]
    matched_set = set.intersection(*key_sets) if key_sets else set()
    matched = sorted(matched_set)
    unmatched_by_source = {
        source_id: sorted(set(rows) - matched_set)
        for source_id, rows in keyed_by_source.items()
    }
    output_header = [
        *canonical_keys,
        *[
            f"{source_id}__{column}"
            for source_id in [item["source_id"] for item in prepared]
            for index, column in enumerate(by_id[source_id]["header"])
            if index
            not in {
                by_id[source_id]["header"].index(key)
                for key in keys_by_source[source_id]
            }
        ]
    ]
    output_rows = []
    for key in matched:
        row = [*key]
        for item in prepared:
            source_id = item["source_id"]
            key_positions = {
                item["header"].index(column)
                for column in keys_by_source[source_id]
            }
            row.extend(
                value
                for index, value in enumerate(keyed_by_source[source_id][key])
                if index not in key_positions
            )
        output_rows.append(row)
    denominator = min((len(rows) for rows in keyed_by_source.values()), default=0)
    coverage = len(matched) / denominator if denominator else 0.0
    return {
        "sources": prepared,
        "keys": canonical_keys,
        "header": output_header,
        "rows": output_rows,
        "unmatched_by_source": unmatched_by_source,
        "duplicate_counts": duplicate_counts,
        "coverage": round(coverage, 6),
    }


def _write_csv(
    path: Path, header: list[str], rows: list[list[str] | tuple[str, ...]]
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle, lineterminator="\n")
        writer.writerow(header)
        writer.writerows(rows)


def _artifact(path: Path, output_dir: Path) -> dict[str, Any]:
    return {
        "path": path.relative_to(output_dir).as_posix(),
        "sha256": _sha256(path),
    }


def _ensure_output_available(output_dir: Path) -> None:
    if output_dir.exists():
        raise ContractError(f"OUTPUT_DIRECTORY_ALREADY_EXISTS:{output_dir}")


def _write_blocked_manifest(
    output_dir: Path,
    payload: dict[str, Any],
    execution_sha256: str,
    error: DataSafetyError,
) -> Path:
    output_dir.mkdir(parents=True, exist_ok=False)
    manifest = {
        "schema_version": MANIFEST_SCHEMA,
        "status": "BLOCKED",
        "execution_id": payload.get("execution_id"),
        "blueprint_id": payload.get("blueprint_id"),
        "execution_request_sha256": execution_sha256,
        "blocked_reasons": [
            {"code": error.code, "evidence": error.evidence}
        ],
        "sources": [],
        "join": None,
    }
    path = output_dir / "preparation_manifest.json"
    path.write_bytes(_canonical_json_bytes(manifest))
    return path


def execute(
    execution_path: Path, output_dir: Path
) -> dict[str, Any]:
    payload = _load_json(execution_path)
    sources = _validate_execution(payload, execution_path)
    _ensure_output_available(output_dir)
    execution_sha256 = _sha256(execution_path)
    try:
        prepared = [_prepare_source(source) for source in sources]
        joined = _join_prepared(payload, prepared)
    except DataSafetyError as exc:
        path = _write_blocked_manifest(
            output_dir, payload, execution_sha256, exc
        )
        raise DataSafetyError(
            exc.code,
            {**exc.evidence, "manifest": str(path)},
        ) from exc

    output_dir.mkdir(parents=True, exist_ok=False)
    source_manifests: list[dict[str, Any]] = []
    for item in prepared:
        filename = (
            f"{_safe_name(item['source_id'])}--"
            f"{_safe_name(item['table_id'])}.csv"
        )
        path = output_dir / "prepared" / filename
        _write_csv(path, item["header"], item["rows"])
        source_manifests.append(
            {
                "source_id": item["source_id"],
                "table_id": item["table_id"],
                "location": str(item["path"]),
                "provenance_status": item["provenance_status"],
                "missing_provenance": item["missing_provenance"],
                "provenance_note": item["provenance_note"],
                "input_sha256_before": item["input_sha256_before"],
                "input_sha256_after": item["input_sha256_after"],
                "row_counts": {
                    "before": len(item["rows"]),
                    "after": len(item["rows"]),
                },
                "schema_before": item["input_header"],
                "schema_after": [
                    {
                        "name": column,
                        "type": item["target_types"][column],
                    }
                    for column in item["header"]
                ],
                "applied_transformations": item[
                    "approved_transformations"
                ],
                "variables": [
                    {
                        **metadata,
                        "final_column": metadata["prepared_column"],
                    }
                    for metadata in item["variable_metadata"]
                ],
                "key_columns": item["key_columns"],
                "duplicate_key_count": item["duplicate_key_count"],
                "artifact": _artifact(path, output_dir),
            }
        )

    join_manifest: dict[str, Any] | None = None
    if joined is not None:
        integrated = output_dir / "prepared" / "integrated.csv"
        _write_csv(integrated, joined["header"], joined["rows"])
        unmatched_manifest: dict[str, dict[str, Any]] = {}
        for source_id, keys in joined["unmatched_by_source"].items():
            audit_path = (
                output_dir
                / "audit"
                / f"unmatched-{_safe_name(source_id)}.csv"
            )
            _write_csv(audit_path, joined["keys"], keys)
            unmatched_manifest[source_id] = {
                "count": len(keys),
                "artifact": _artifact(audit_path, output_dir),
            }
        source_ids = [item["source_id"] for item in joined["sources"]]
        source_row_counts = {
            item["source_id"]: len(item["rows"])
            for item in joined["sources"]
        }
        first_id, second_id = source_ids[:2]
        row_counts_manifest: dict[str, Any] = {
            "left_before": source_row_counts[first_id],
            "right_before": source_row_counts[second_id],
            "after": len(joined["rows"]),
        }
        duplicate_manifest: dict[str, Any] = {
            "left": joined["duplicate_counts"][first_id],
            "right": joined["duplicate_counts"][second_id],
        }
        unmatched_keys_manifest: dict[str, Any] = {
            "left_count": unmatched_manifest[first_id]["count"],
            "right_count": unmatched_manifest[second_id]["count"],
            "left_artifact": unmatched_manifest[first_id]["artifact"],
            "right_artifact": unmatched_manifest[second_id]["artifact"],
        }
        if len(source_ids) > 2:
            row_counts_manifest["by_source"] = source_row_counts
            duplicate_manifest["by_source"] = joined["duplicate_counts"]
            unmatched_keys_manifest["by_source"] = unmatched_manifest
        join_manifest = {
            "strategy": "INTEGRATED",
            "join_type": "INNER",
            "keys": joined["keys"],
            "source_ids": source_ids,
            "left_source_id": first_id,
            "right_source_id": second_id,
            "row_counts": row_counts_manifest,
            "duplicate_key_counts": duplicate_manifest,
            "join_coverage": joined["coverage"],
            "unmatched_keys": unmatched_keys_manifest,
            "variables": [
                {
                    **metadata,
                    "final_column": (
                        metadata["prepared_column"]
                        if metadata["prepared_column"] in joined["keys"]
                        else (
                            f"{source_manifest['source_id']}__"
                            f"{metadata['prepared_column']}"
                        )
                    ),
                }
                for source_manifest in source_manifests
                for metadata in source_manifest["variables"]
            ],
            "artifact": _artifact(integrated, output_dir),
        }

    manifest = {
        "schema_version": MANIFEST_SCHEMA,
        "status": "COMPLETED",
        "execution_id": payload["execution_id"],
        "blueprint_id": payload["blueprint_id"],
        "execution_request_sha256": execution_sha256,
        "required_audits": payload["frozen_preparation_plan"][
            "required_audits"
        ],
        "sources": source_manifests,
        "join": join_manifest,
    }
    manifest_path = output_dir / "preparation_manifest.json"
    manifest_path.write_bytes(_canonical_json_bytes(manifest))
    return manifest


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Execute an approved deterministic data preparation request."
    )
    parser.add_argument("execution", type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    return parser


def main(argv: Iterable[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    execution = args.execution.resolve()
    output_dir = args.output_dir.resolve()
    try:
        manifest = execute(execution, output_dir)
        sys.stdout.write(
            json.dumps(
                {
                    "valid": True,
                    "status": manifest["status"],
                    "manifest": str(
                        output_dir / "preparation_manifest.json"
                    ),
                },
                ensure_ascii=False,
                sort_keys=True,
            )
            + "\n"
        )
        return 0
    except ContractError as exc:
        sys.stderr.write(
            json.dumps(
                {
                    "valid": False,
                    "error_type": "CONTRACT",
                    "errors": [str(exc)],
                },
                ensure_ascii=False,
                sort_keys=True,
            )
            + "\n"
        )
        return 2
    except DataSafetyError as exc:
        sys.stderr.write(
            json.dumps(
                {
                    "valid": False,
                    "error_type": "DATA_SAFETY",
                    "errors": [exc.code],
                    "evidence": exc.evidence,
                },
                ensure_ascii=False,
                sort_keys=True,
            )
            + "\n"
        )
        return 3
    except Exception as exc:
        sys.stderr.write(
            json.dumps(
                {
                    "valid": False,
                    "error_type": "UNEXPECTED",
                    "errors": [f"{type(exc).__name__}:{exc}"],
                },
                ensure_ascii=False,
                sort_keys=True,
            )
            + "\n"
        )
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
