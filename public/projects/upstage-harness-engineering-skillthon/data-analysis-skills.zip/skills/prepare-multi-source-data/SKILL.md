---
name: prepare-multi-source-data
description: Execute an explicitly approved analysis_execution_request.v1 to prepare user-provided local CSV/TSV data while preserving frozen variable semantics, or safely inner-join a connected tree of up to three approved ONE_TO_ONE sources. Use when Codex must produce deterministic prepared tables, strict type normalization, join audits, and a provenance and variable-metadata manifest without network access or exploratory analysis.
---

# Prepare Multi-Source Data

Execute only the preparation tasks frozen by the Planner. Fail closed when the
request is unapproved, a transform was added after approval, or a join is not a
safe one-to-one candidate.

## Load the rules

- Read [input-contract.md](references/input-contract.md) before accepting a
  request.
- Read [preparation-rules.md](references/preparation-rules.md) before
  transforming or joining rows.
- Read [output-contract.md](references/output-contract.md) before writing
  artifacts.

## Workflow

1. Require one `analysis_execution_request.v1` produced after explicit approval.
   Require its frozen `data_access_policy.v1` to be
   `USER_PROVIDED_LOCAL_ONLY`.
2. Confirm that `frozen_preparation_plan`, `clean_transform`, and optional
   `join_sources` tasks are byte-equivalent in meaning.
   Confirm that the resolved `frozen_variable_inventory` and every table's
   `variable_metadata` are unchanged.
3. Run:

   ```powershell
   python scripts/prepare_data.py EXECUTION.json --output-dir OUTPUT_DIR
   ```

4. Treat exit code 0 as completed preparation, 2 as a contract or authorization
   failure with no output, and 3 as a full-data safety block with a
   `preparation_manifest.v1` record.
5. Pass only completed prepared tables and their manifest to downstream
   exploratory analysis. Never fabricate EDA results.

## MVP boundaries

- Accept local CSV and TSV only.
- Never browse, call an API, or download a missing file. If an approved file is
  absent, fail before output and ask the user to provide it.
- Accept one to three sources.
- Apply only the approved canonical operations `normalize_columns` and
  `coerce_types`.
- Preserve rows and missing values. Do not impute, drop, deduplicate, aggregate,
  convert units, merge categories, or remap geography codes.
- Preserve semantic role, measurement scale, analysis roles, unit, status, and
  allowed/prohibited analyses; never infer or upgrade them during preparation.
- Join only a fully rechecked connected tree of two or three `ONE_TO_ONE`
  sources with common canonical keys and an inner join.
- Never overwrite an existing output directory.
