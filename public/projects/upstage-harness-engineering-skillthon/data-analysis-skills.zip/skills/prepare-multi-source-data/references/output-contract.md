# Output Contract

Write `preparation_manifest.json` with
`schema_version: preparation_manifest.v1`.

For `COMPLETED`, include:

- execution and blueprint identifiers plus the input execution SHA-256;
- each source's location, provenance status, input SHA-256 before and after,
  row counts, schemas, approved transformations, duplicate-key count, and
  prepared CSV artifact path and SHA-256;
- each source column's frozen variable metadata and prepared output column;
- for an integrated request, source IDs, join type, composite keys, per-source
  and output row counts, join coverage, per-source duplicate counts,
  per-source unmatched-key artifact references, the integrated CSV artifact
  reference, and each variable's final source-prefixed column name.

For a full-data safety failure, write only a `BLOCKED` manifest containing the
error code and evidence gathered before the block.

Use UTF-8, LF newlines, deterministic column order, sorted JSON keys, and no
timestamps. Paths in artifact references are relative to the output directory.
Never overwrite an existing output directory.
