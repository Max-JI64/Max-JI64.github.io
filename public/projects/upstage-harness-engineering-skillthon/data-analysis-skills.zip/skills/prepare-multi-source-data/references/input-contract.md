# Input Contract

Accept exactly one `analysis_execution_request.v1`.

Require:

- `approval.status` equal to `APPROVED` and a non-empty `approved_by`.
- `data_access_policy.v1` with `mode: USER_PROVIDED_LOCAL_ONLY`,
  `network_access: false`, `remote_fetch: false`, and
  `when_data_is_missing: REQUEST_USER`.
- One to three unique `source_refs`.
- `frozen_preparation_plan.schema_version` equal to
  `data_preparation_plan.v1`.
- A resolved `frozen_variable_inventory` with no pending confirmation requests.
- Per-table `variable_metadata` exactly matching the frozen inventory's source,
  table, original column, prepared column, semantic role, measurement scale,
  analysis roles, unit, status, and allowed/prohibited analyses.
- One `clean_transform` task per source, assigned to
  `prepare-multi-source-data`, with a `preparation_source` exactly matching the
  frozen source plan.
- Local `csv` or `tsv` locations and exactly one table per source.
- Only `normalize_columns` followed by `coerce_types`.

For `INTEGRATED`, require two or three sources connected by a join tree with
exactly `source_count - 1` joins, one `join_sources` task, common canonical
keys, `ONE_TO_ONE`, `SAFE_CANDIDATE`, positive profiled overlap, no unit
conflicts, no alignment issues, `INNER`, and no unresolved preparation audit.

Reject unsupported formats, source counts, operations, missing approval,
remote locations, unsafe joins, or task-plan drift before creating the output
directory. A missing or remote source produces a user-facing request for the
local file; this Skill never attempts acquisition.

Do not reinterpret semantic metadata. Recheck full-data physical constraints
such as headers, types, row counts, and duplicate keys; block contradictions
without changing the approved meaning.
