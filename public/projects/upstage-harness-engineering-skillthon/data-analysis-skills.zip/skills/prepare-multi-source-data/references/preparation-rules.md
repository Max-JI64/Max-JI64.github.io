# Preparation Rules

## Canonical transformations

- Rename columns only through the approved exact `column_mapping`.
- Require the mapping to cover the complete input header and to produce unique
  output names.
- Coerce every non-empty value using its approved target type:
  `string`, `integer`, `number`, `boolean`, or `datetime`.
- Preserve empty values as empty CSV fields.
- Emit booleans as `true` or `false` and datetimes as ISO 8601.
- Preserve row order in source-level prepared tables.
- Fail the full operation when any non-empty value cannot be parsed.

## Join safety

- Recompute composite keys over all rows.
- Block the join if either side contains duplicate composite keys.
- Inner-join only the sorted intersection of keys.
- Keep canonical key columns once.
- Prefix every non-key column with `{source_id}__`.
- Write exact left-only and right-only composite keys to separate audit CSVs,
  including header-only files when there are no unmatched keys.

Never perform row deletion, imputation, deduplication, aggregation, unit
conversion, category consolidation, or geography-code remapping in this MVP.
