#!/usr/bin/env python3
"""Render Markdown, deterministic PDF, and offline HTML from EDA evidence."""

from __future__ import annotations

import argparse
import hashlib
import html
import json
from pathlib import Path
import re
import shutil
import sys
from typing import Any, Iterable

import pandas as pd
from plotly.offline import get_plotlyjs
from reportlab import rl_config
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    Image,
    PageBreak,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)


rl_config.invariant = 1
EXECUTION_SCHEMA = "analysis_execution_request.v1"
PREPARATION_SCHEMA = "preparation_manifest.v1"
EDA_SCHEMA = "eda_manifest.v1"
REPORTABLE = {"validated", "qualified"}


class ContractError(ValueError):
    """Raised before output creation when artifact lineage is invalid."""


def _load_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(value, dict):
        raise ContractError(f"TOP_LEVEL_JSON_MUST_BE_OBJECT:{path}")
    return value


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(65_536), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _json_bytes(value: Any) -> bytes:
    return (
        json.dumps(
            value,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
            allow_nan=False,
        )
        + "\n"
    ).encode("utf-8")


def _artifact(path: Path, root: Path) -> dict[str, Any]:
    return {
        "path": path.relative_to(root).as_posix(),
        "sha256": _sha256(path),
    }


def _resolve(root: Path, artifact: dict[str, Any]) -> Path:
    rel = artifact.get("path")
    expected = artifact.get("sha256")
    if not isinstance(rel, str) or not rel:
        raise ContractError("ARTIFACT_PATH_REQUIRED")
    path = (root / rel).resolve()
    try:
        path.relative_to(root.resolve())
    except ValueError as exc:
        raise ContractError(f"ARTIFACT_OUTSIDE_ROOT:{rel}") from exc
    if not path.is_file():
        raise ContractError(f"ARTIFACT_NOT_FOUND:{rel}")
    if not isinstance(expected, str) or _sha256(path) != expected:
        raise ContractError(f"ARTIFACT_HASH_MISMATCH:{rel}")
    return path


def _validate(
    execution_path: Path,
    preparation_path: Path,
    eda_path: Path,
) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any]]:
    execution = _load_json(execution_path)
    preparation = _load_json(preparation_path)
    eda = _load_json(eda_path)
    if execution.get("schema_version") != EXECUTION_SCHEMA:
        raise ContractError(f"EXPECTED_SCHEMA:{EXECUTION_SCHEMA}")
    if execution.get("approval", {}).get("status") != "APPROVED":
        raise ContractError("EXPLICIT_APPROVAL_REQUIRED")
    if (
        preparation.get("schema_version") != PREPARATION_SCHEMA
        or preparation.get("status") != "COMPLETED"
    ):
        raise ContractError("COMPLETED_PREPARATION_REQUIRED")
    if (
        eda.get("schema_version") != EDA_SCHEMA
        or eda.get("status") not in {"COMPLETE", "PARTIAL_EXECUTION"}
    ):
        raise ContractError("COMPLETED_OR_PARTIAL_EDA_REQUIRED")
    for field in ("execution_id", "blueprint_id"):
        if not (
            execution.get(field)
            == preparation.get(field)
            == eda.get(field)
        ):
            raise ContractError(f"LINEAGE_{field.upper()}_MISMATCH")
    if preparation.get("execution_request_sha256") != _sha256(execution_path):
        raise ContractError("PREPARATION_EXECUTION_HASH_MISMATCH")
    if eda.get("execution_request_sha256") != _sha256(execution_path):
        raise ContractError("EDA_EXECUTION_HASH_MISMATCH")
    if eda.get("preparation_manifest_sha256") != _sha256(preparation_path):
        raise ContractError("EDA_PREPARATION_HASH_MISMATCH")
    return execution, preparation, eda


def _question(execution: dict[str, Any]) -> str:
    question = execution.get("approved_question", {})
    return str(question.get("text") or question.get("question") or "승인된 탐색 분석")


def _approved_measure_metadata(
    execution: dict[str, Any],
) -> tuple[list[str], list[dict[str, str]]]:
    """Return frozen interpretation notes and approved measure definitions.

    The renderer only exposes metadata already frozen in the execution request.
    It does not infer a population, unit, base period, or analytical use from a
    column name.
    """

    preparation = execution.get("frozen_preparation_plan", {})
    sources = preparation.get("sources", []) if isinstance(preparation, dict) else []
    notes: list[str] = []
    time_basis: dict[str, str] = {}
    for source in sources:
        if not isinstance(source, dict):
            continue
        structure = source.get("dataset_structure", {})
        if not isinstance(structure, dict):
            continue
        note = structure.get("comparison_notes")
        if isinstance(note, str) and note.strip() and note not in notes:
            notes.append(note.strip())
        basis = structure.get("measure_time_basis", {})
        if isinstance(basis, dict):
            for column, description in basis.items():
                if isinstance(column, str) and isinstance(description, str):
                    time_basis[column] = description

    focus = execution.get("frozen_analysis_focus", {})
    focus = focus if isinstance(focus, dict) else {}
    usage_by_id: dict[str, str] = {}

    def register(ref: Any, usage: str) -> None:
        if isinstance(ref, dict) and ref.get("variable_id"):
            usage_by_id.setdefault(str(ref["variable_id"]), usage)

    register(focus.get("primary_measure"), "primary_measure")
    for ref in focus.get("comparison_measures", []):
        register(ref, "comparison_measure")
    for pair in focus.get("sensitivity_pairs", []):
        if not isinstance(pair, dict):
            continue
        register(pair.get("primary_variable"), "sensitivity_primary")
        register(pair.get("alternative_variable"), "sensitivity_alternative")

    inventory = execution.get("frozen_variable_inventory", {})
    variables = inventory.get("variables", []) if isinstance(inventory, dict) else []
    definitions: list[dict[str, str]] = []
    for variable in variables:
        if not isinstance(variable, dict):
            continue
        roles = variable.get("analysis_roles", [])
        if "MEASURE" not in roles:
            continue
        column = str(
            variable.get("source_column")
            or variable.get("prepared_column")
            or variable.get("variable_id")
            or ""
        )
        variable_id = str(variable.get("variable_id") or "")
        if variable_id not in usage_by_id:
            continue
        definitions.append(
            {
                "variable_id": variable_id,
                "column": column,
                "usage": usage_by_id.get(variable_id, "other_approved_measure"),
                "definition": str(time_basis.get(column) or ""),
                "unit": str(variable.get("unit") or ""),
                "measurement_scale": str(variable.get("measurement_scale") or ""),
            }
        )
    usage_order = {
        "primary_measure": 0,
        "comparison_measure": 1,
        "sensitivity_primary": 2,
        "sensitivity_alternative": 3,
        "other_approved_measure": 4,
    }
    definitions.sort(
        key=lambda item: (
            usage_order.get(item["usage"], 99),
            item["column"],
            item["variable_id"],
        )
    )
    return notes, definitions


def _ranked_evidence(
    evidence: list[dict[str, Any]], insight_ranking: dict[str, Any]
) -> list[dict[str, Any]]:
    by_id = {
        str(item.get("evidence_id")): item
        for item in evidence
        if item.get("validation_status") in REPORTABLE
    }
    ordered = [
        by_id[item["evidence_id"]]
        for item in insight_ranking.get("insights", [])
        if isinstance(item, dict) and item.get("evidence_id") in by_id
    ]
    if ordered:
        return ordered
    return sorted(
        by_id.values(),
        key=lambda item: (
            -float(item.get("insight_score") or 0),
            str(item.get("evidence_id")),
        ),
    )


def _core_question_evidence(
    evidence: list[dict[str, Any]], insight_ranking: dict[str, Any]
) -> list[dict[str, Any]]:
    core_classes = {
        "derived_rule",
        "cohort_comparison",
        "association",
        "sensitivity",
    }
    return [
        item
        for item in _ranked_evidence(evidence, insight_ranking)
        if item.get("evidence_class") in core_classes
        and item.get("question_relevance") == "core"
    ]


def _evidence_markdown_line(item: dict[str, Any]) -> str:
    qualification = ""
    if item.get("qualification_reasons"):
        qualification = (
            " 제한: " + ", ".join(item["qualification_reasons"]) + "."
        )
    coverage = _evidence_coverage_text(item)
    return (
        f"- **{item.get('evidence_id')}** "
        f"`{item.get('validation_status')}` "
        f"[{item.get('evidence_class')}] "
        f"{coverage}"
        f"{item.get('summary')} "
        f"{item.get('claim_boundary')}.{qualification}"
    )


def _evidence_coverage_text(item: dict[str, Any]) -> str:
    denominator = item.get("denominator")
    if denominator is None or pd.isna(denominator):
        return ""
    minimum = item.get("minimum_required_denominator")
    minimum_text = (
        ""
        if minimum is None or pd.isna(minimum)
        else f", minimum={minimum}"
    )
    return f"(coverage n={denominator}{minimum_text}) "


def _display_optional(value: Any) -> str:
    if value is None or pd.isna(value):
        return "해당 없음"
    return str(value)


def _report_text(
    execution: dict[str, Any],
    preparation: dict[str, Any],
    eda: dict[str, Any],
    evidence: list[dict[str, Any]],
    validation: dict[str, Any],
    data_requests: dict[str, Any],
    insight_ranking: dict[str, Any],
    quality: pd.DataFrame,
    chart_paths: list[tuple[dict[str, Any], str]],
) -> str:
    source_ids = [
        str(source.get("source_id"))
        for source in preparation.get("sources", [])
        if isinstance(source, dict)
    ]
    interpretation_notes, measure_definitions = _approved_measure_metadata(execution)
    lines = [
        "# 승인된 탐색 분석 보고서",
        "",
        "## 1. 문제 정의",
        "",
        f"> {_question(execution)}",
        "",
        "본 결과는 기술·비교·탐색 분석이다. 관측된 동반 패턴을 원인이나 "
        "예측 결과로 해석하지 않는다.",
        "",
        "## 2. 데이터와 출처",
        "",
        f"- 사용 출처 ID: {', '.join(source_ids)}",
        f"- 준비 상태: `{preparation.get('status')}`",
        f"- EDA 상태: `{eda.get('status')}`",
        f"- 실행 단계: {', '.join(map(str, eda.get('executed_stages', [])))}",
        "",
        "### 승인된 지표 정의와 비교 주의",
        "",
    ]
    for note in interpretation_notes:
        lines.append(f"- 비교 주의: {note}")
    for item in measure_definitions:
        definition = item["definition"] or "별도 시간기준 설명 없음"
        lines.append(
            f"- `{item['column']}` [{item['usage']}]: {definition}; "
            f"unit={item['unit'] or 'unspecified'}; "
            f"scale={item['measurement_scale'] or 'unspecified'}"
        )
    lines.extend(
        [
            "- sensitivity primary와 alternative는 서로 다른 승인 정의이며 "
            "동일 모집단으로 합치거나 일반 association에 사용하지 않는다.",
            "",
        "## 3. 데이터 품질",
        "",
        ]
    )
    if quality.empty:
        lines.append("- 품질 테이블이 비어 있다.")
    else:
        for row in quality.to_dict(orient="records"):
            lines.append(
                f"- `{row.get('table_id')}`: {row.get('rows')}행, "
                f"결측률 {float(row.get('missing_rate') or 0):.1%}, "
                f"중복 {row.get('duplicate_rows')}행, "
                f"결합 커버리지 {_display_optional(row.get('join_coverage'))}"
            )
    reportable = _ranked_evidence(evidence, insight_ranking)
    core = _core_question_evidence(evidence, insight_ranking)
    lines.extend(["", "## 4. 핵심 질문에 대한 답변", ""])
    if not core:
        lines.append("- 핵심 질문에 직접 연결된 검증 근거가 생성되지 않았다.")
    for item in core:
        lines.append(_evidence_markdown_line(item))
    lines.extend(
        [
            "",
            "- 위 결과는 관측된 기술·비교 근거이며 인과 효과, 예측 또는 "
            "정책 최적화를 뜻하지 않는다.",
            "",
            "## 5. 핵심 시각화",
            "",
        ]
    )
    for chart, relative in chart_paths:
        lines.extend(
            [
                f"### {chart.get('title')}",
                "",
                f"![{chart.get('title')}]({relative})",
                "",
                (
                    "근거: "
                    + ", ".join(chart.get("evidence_ids", []))
                    if chart.get("evidence_ids")
                    else "품질·맥락 시각화"
                ),
                "",
            ]
        )
    lines.extend(["## 6. 보조 분석 결과", ""])
    supporting = [
        item
        for item in reportable
        if item.get("evidence_id")
        not in {core_item.get("evidence_id") for core_item in core}
    ]
    if not supporting:
        lines.append("- 추가 보조 근거가 없다.")
    for item in supporting:
        lines.append(_evidence_markdown_line(item))
    counts = validation.get("counts", {})
    lines.extend(
        [
            "",
            "## 7. 민감도와 검증",
            "",
            f"- 후보 {counts.get('candidate', 0)}건",
            f"- validated {counts.get('validated', 0)}건",
            f"- qualified {counts.get('qualified', 0)}건",
            f"- rejected {counts.get('rejected', 0)}건",
            f"- 수행 검사: {', '.join(validation.get('checks', [])) or '없음'}",
            "",
            "## 8. 한계",
            "",
            "- 측정값 간 관계는 관측된 비인과적 동반 패턴으로만 해석한다.",
            "- 지수형 변수는 승인된 기준시점과 단위 정의에 따라서만 해석한다.",
            "- 결측, 결합 커버리지, 기간·연령 정의 차이는 해당 evidence의 제한으로 유지한다.",
            "- 분석은 사용자 제공 로컬 데이터로만 수행했으며 인터넷 탐색, "
            "API 호출 또는 원격 다운로드를 수행하지 않았다.",
            "",
            "## 9. 추가 데이터 요청",
            "",
        ]
    )
    requests = list(data_requests.get("requests", []))
    if not requests:
        lines.append("- 현재 승인된 분석 범위에서 추가 데이터 요청이 없다.")
    for item in requests:
        lines.append(
            f"- **{item.get('request_id')}** `{item.get('reason_code')}`: "
            f"{item.get('message')} ({item.get('requested_scope')})"
        )
    lines.extend(
        [
            "",
            "## 10. 재현 방법",
            "",
            f"- 실행 ID: `{execution.get('execution_id')}`",
            f"- Blueprint ID: `{execution.get('blueprint_id')}`",
            "- `preparation_manifest.json`과 `eda_manifest.json`의 해시 및 "
            "artifact 경로를 따라 동일 입력을 재실행한다.",
            "- 보고서와 대시보드는 `evidence_records.json`의 validated·qualified "
            "근거만 사용한다.",
            "",
        ]
    )
    return "\n".join(lines)


def _font_names() -> tuple[str, str]:
    regular_candidates = [
        Path(r"C:\Windows\Fonts\malgun.ttf"),
        Path(r"C:\Windows\Fonts\gulim.ttc"),
    ]
    bold_candidates = [
        Path(r"C:\Windows\Fonts\malgunbd.ttf"),
        Path(r"C:\Windows\Fonts\gulim.ttc"),
    ]
    regular = next((path for path in regular_candidates if path.is_file()), None)
    bold = next((path for path in bold_candidates if path.is_file()), regular)
    if regular is None or bold is None:
        return "Helvetica", "Helvetica-Bold"
    pdfmetrics.registerFont(TTFont("KoreanRegular", str(regular)))
    pdfmetrics.registerFont(TTFont("KoreanBold", str(bold)))
    return "KoreanRegular", "KoreanBold"


def _pdf(
    path: Path,
    execution: dict[str, Any],
    preparation: dict[str, Any],
    eda: dict[str, Any],
    evidence: list[dict[str, Any]],
    validation: dict[str, Any],
    data_requests: dict[str, Any],
    insight_ranking: dict[str, Any],
    quality: pd.DataFrame,
    chart_files: list[tuple[dict[str, Any], Path]],
) -> None:
    regular, bold = _font_names()
    styles = getSampleStyleSheet()
    title = ParagraphStyle(
        "TitleKo",
        parent=styles["Title"],
        fontName=bold,
        fontSize=22,
        leading=29,
        textColor=colors.HexColor("#0F172A"),
        alignment=TA_CENTER,
        spaceAfter=10 * mm,
    )
    heading = ParagraphStyle(
        "HeadingKo",
        parent=styles["Heading2"],
        fontName=bold,
        fontSize=15,
        leading=21,
        textColor=colors.HexColor("#1D4ED8"),
        spaceBefore=5 * mm,
        spaceAfter=3 * mm,
    )
    body = ParagraphStyle(
        "BodyKo",
        parent=styles["BodyText"],
        fontName=regular,
        fontSize=9.5,
        leading=15,
        textColor=colors.HexColor("#1F2937"),
        spaceAfter=2.5 * mm,
    )
    small = ParagraphStyle(
        "SmallKo",
        parent=body,
        fontSize=8,
        leading=12,
        textColor=colors.HexColor("#475569"),
    )
    doc = SimpleDocTemplate(
        str(path),
        pagesize=A4,
        rightMargin=18 * mm,
        leftMargin=18 * mm,
        topMargin=17 * mm,
        bottomMargin=17 * mm,
        title="승인된 탐색 분석 보고서",
        author="BDAI Skillthon Analysis Agent",
    )
    story: list[Any] = [
        Paragraph("승인된 탐색 분석 보고서", title),
        Paragraph(html.escape(_question(execution)), body),
        Paragraph(
            "기술·비교·탐색 분석이며 관측된 동반 패턴을 원인이나 예측으로 "
            "해석하지 않습니다.",
            small,
        ),
        Paragraph("1. 데이터와 품질", heading),
    ]
    source_ids = [
        str(source.get("source_id"))
        for source in preparation.get("sources", [])
        if isinstance(source, dict)
    ]
    interpretation_notes, measure_definitions = _approved_measure_metadata(execution)
    story.append(
        Paragraph(
            f"출처 ID: {html.escape(', '.join(source_ids))}<br/>"
            f"준비 상태: {preparation.get('status')} / EDA 상태: {eda.get('status')}",
            body,
        )
    )
    story.append(Paragraph("승인된 지표 정의와 비교 주의", heading))
    for note in interpretation_notes:
        story.append(Paragraph(html.escape(note), body))
    if measure_definitions:
        definition_rows: list[list[Any]] = [
            [
                Paragraph("변수", small),
                Paragraph("용도", small),
                Paragraph("승인 정의 / 단위", small),
            ]
        ]
        for item in measure_definitions:
            definition = item["definition"] or "별도 시간기준 설명 없음"
            detail = f"{definition}; unit={item['unit'] or 'unspecified'}"
            definition_rows.append(
                [
                    Paragraph(html.escape(item["column"]), small),
                    Paragraph(html.escape(item["usage"]), small),
                    Paragraph(html.escape(detail), small),
                ]
            )
        definition_table = Table(
            definition_rows,
            colWidths=[60 * mm, 36 * mm, 63 * mm],
            repeatRows=1,
        )
        definition_table.setStyle(
            TableStyle(
                [
                    ("FONTNAME", (0, 0), (-1, 0), bold),
                    ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#DBEAFE")),
                    ("GRID", (0, 0), (-1, -1), 0.3, colors.HexColor("#CBD5E1")),
                    ("VALIGN", (0, 0), (-1, -1), "TOP"),
                    ("TOPPADDING", (0, 0), (-1, -1), 3),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
                ]
            )
        )
        story.append(definition_table)
    story.append(
        Paragraph(
            "sensitivity primary와 alternative는 서로 다른 승인 정의이며 "
            "동일 모집단으로 합치거나 일반 association에 사용하지 않습니다.",
            body,
        )
    )
    if not quality.empty:
        data = [["테이블", "행", "결측률", "중복", "결합 커버리지"]]
        for row in quality.to_dict(orient="records"):
            data.append(
                [
                    str(row.get("table_id")),
                    str(row.get("rows")),
                    f"{float(row.get('missing_rate') or 0):.1%}",
                    str(row.get("duplicate_rows")),
                    _display_optional(row.get("join_coverage")),
                ]
            )
        table = Table(data, colWidths=[42 * mm, 20 * mm, 26 * mm, 20 * mm, 38 * mm])
        table.setStyle(
            TableStyle(
                [
                    ("FONTNAME", (0, 0), (-1, 0), bold),
                    ("FONTNAME", (0, 1), (-1, -1), regular),
                    ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#DBEAFE")),
                    ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#CBD5E1")),
                    ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                    ("FONTSIZE", (0, 0), (-1, -1), 8),
                    ("TOPPADDING", (0, 0), (-1, -1), 5),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
                ]
            )
        )
        story.append(table)
    reportable = _ranked_evidence(evidence, insight_ranking)
    core = _core_question_evidence(evidence, insight_ranking)
    story.append(Paragraph("2. 핵심 질문에 대한 답변", heading))
    if not core:
        story.append(
            Paragraph(
                "핵심 질문에 직접 연결된 검증 근거가 생성되지 않았습니다.",
                body,
            )
        )
    for item in core:
        reasons = ", ".join(item.get("qualification_reasons", []))
        coverage = _evidence_coverage_text(item)
        core_text = (
            f"<b>{html.escape(str(item.get('evidence_id')))}</b> "
            f"[{html.escape(str(item.get('validation_status')))} / "
            f"{html.escape(str(item.get('evidence_class')))}] "
            f"{html.escape(coverage)}"
            f"{html.escape(str(item.get('summary')))} "
            f"{html.escape(str(item.get('claim_boundary')))}."
        )
        if reasons:
            core_text += f" 제한: {html.escape(reasons)}."
        story.append(Paragraph(core_text, body))
    story.append(
        Paragraph(
            "위 결과는 관측된 기술·비교 근거이며 인과 효과, 예측 또는 "
            "정책 최적화를 뜻하지 않습니다.",
            small,
        )
    )
    story.append(Paragraph("3. 핵심 시각화", heading))
    for chart, image_path in chart_files[:8]:
        image = Image(str(image_path))
        image._restrictSize(165 * mm, 96 * mm)
        story.append(image)
        evidence_ids = ", ".join(chart.get("evidence_ids", []))
        story.append(
            Paragraph(
                (
                    f"근거: {html.escape(evidence_ids)}"
                    if evidence_ids
                    else "근거: 품질·맥락 시각화"
                ),
                small,
            )
        )
    story.append(Paragraph("4. 보조 분석 결과", heading))
    core_ids = {item.get("evidence_id") for item in core}
    supporting = [
        item
        for item in reportable
        if item.get("evidence_id") not in core_ids
    ]
    if not supporting:
        story.append(Paragraph("추가 보조 근거가 없습니다.", body))
    for item in supporting:
        reasons = ", ".join(item.get("qualification_reasons", []))
        text = (
            f"<b>{html.escape(str(item.get('evidence_id')))}</b> "
            f"[{html.escape(str(item.get('validation_status')))}] "
            f"점수 {html.escape(str(item.get('insight_score')))}. "
            f"{html.escape(str(item.get('summary')))}"
        )
        if reasons:
            text += f" 제한: {html.escape(reasons)}."
        story.append(Paragraph(text, body))
    counts = validation.get("counts", {})
    story.extend(
        [
            Paragraph("5. 민감도와 한계", heading),
            Paragraph(
                f"후보 {counts.get('candidate', 0)}건 중 validated "
                f"{counts.get('validated', 0)}건, qualified "
                f"{counts.get('qualified', 0)}건, rejected "
                f"{counts.get('rejected', 0)}건입니다.",
                body,
            ),
            Paragraph(
                "측정값 간 관계는 관측된 비인과적 동반 패턴입니다. "
                "지수형 변수는 승인된 기준시점과 단위 정의에 따라서만 해석합니다. "
                "결측·기간·연령 정의·결합 커버리지 제한을 함께 해석해야 합니다.",
                body,
            ),
            Paragraph(
                "분석은 사용자 제공 로컬 데이터만 사용했으며 인터넷 탐색, "
                "API 호출 또는 원격 다운로드를 수행하지 않았습니다.",
                body,
            ),
            Paragraph("6. 추가 데이터 요청", heading),
        ]
    )
    requests = list(data_requests.get("requests", []))
    if not requests:
        story.append(
            Paragraph("현재 승인된 분석 범위에서 추가 데이터 요청이 없습니다.", body)
        )
    for item in requests:
        story.append(
            Paragraph(
                f"<b>{html.escape(str(item.get('request_id')))}</b> "
                f"[{html.escape(str(item.get('reason_code')))}] "
                f"{html.escape(str(item.get('message')))}",
                body,
            )
        )
    story.extend(
        [
            Paragraph("7. 재현 정보", heading),
            Paragraph(
                f"실행 ID: {html.escape(str(execution.get('execution_id')))}<br/>"
                f"Blueprint ID: {html.escape(str(execution.get('blueprint_id')))}<br/>"
                "모든 결론은 evidence_records.json의 validated 또는 qualified "
                "레코드에서 생성되었습니다.",
                body,
            ),
        ]
    )
    doc.build(story)


def _data_artifact(
    preparation_path: Path, preparation: dict[str, Any]
) -> tuple[Path, list[dict[str, Any]]]:
    root = preparation_path.parent
    join = preparation.get("join")
    if isinstance(join, dict) and isinstance(join.get("artifact"), dict):
        return _resolve(root, join["artifact"]), list(join.get("variables", []))
    sources = [
        item
        for item in preparation.get("sources", [])
        if isinstance(item, dict) and isinstance(item.get("artifact"), dict)
    ]
    if not sources:
        raise ContractError("NO_DASHBOARD_TABLE")
    return _resolve(root, sources[0]["artifact"]), list(sources[0].get("variables", []))


def _dashboard(
    path: Path,
    execution: dict[str, Any],
    preparation_path: Path,
    preparation: dict[str, Any],
    evidence: list[dict[str, Any]],
    validation: dict[str, Any],
    data_requests: dict[str, Any],
    insight_ranking: dict[str, Any],
    quality: pd.DataFrame,
) -> None:
    data_path, variables = _data_artifact(preparation_path, preparation)
    frame = pd.read_csv(data_path, encoding="utf-8-sig")
    records = json.loads(frame.to_json(orient="records", force_ascii=False))
    focus = execution.get("frozen_analysis_focus", {})
    focus = focus if isinstance(focus, dict) else {}
    allowed_variable_ids: set[str] = set()

    def allow(reference: Any) -> None:
        if isinstance(reference, dict) and reference.get("variable_id"):
            allowed_variable_ids.add(str(reference["variable_id"]))

    for field in (
        "primary_measure",
        "time_axis",
        "group_axis",
        "geography_axis",
        "geography_label",
    ):
        allow(focus.get(field))
    for reference in focus.get("comparison_measures", []):
        allow(reference)
    for pair in focus.get("sensitivity_pairs", []):
        if isinstance(pair, dict):
            allow(pair.get("primary_variable"))
            allow(pair.get("alternative_variable"))
    variable_payload = [
        {
            "id": item.get("variable_id"),
            "column": item.get("final_column"),
            "role": item.get("semantic_role"),
            "type": item.get("physical_type"),
            "unit": item.get("unit"),
        }
        for item in variables
        if (
            isinstance(item, dict)
            and item.get("final_column") in frame.columns
            and str(item.get("variable_id")) in allowed_variable_ids
        )
    ]
    payload = {
        "question": _question(execution),
        "records": records,
        "variables": variable_payload,
        "approvedMetadata": {
            "interpretationNotes": _approved_measure_metadata(execution)[0],
            "measureDefinitions": _approved_measure_metadata(execution)[1],
            "sensitivityBoundary": (
                "sensitivity primary와 alternative는 서로 다른 승인 정의이며 "
                "동일 모집단으로 합치거나 일반 association에 사용하지 않는다."
            ),
        },
        "evidence": _ranked_evidence(evidence, insight_ranking),
        "coreEvidence": _core_question_evidence(
            evidence, insight_ranking
        ),
        "insightRanking": insight_ranking,
        "validation": validation,
        "dataRequests": data_requests,
        "quality": json.loads(quality.to_json(orient="records", force_ascii=False)),
    }
    plotly_js = get_plotlyjs()
    payload_json = json.dumps(payload, ensure_ascii=False).replace("</", "<\\/")
    document = f"""<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>승인된 탐색 분석 대시보드</title>
<style>
:root{{--ink:#0f172a;--muted:#64748b;--blue:#2563eb;--teal:#0f766e;--bg:#f8fafc;--card:#fff;}}
*{{box-sizing:border-box}} body{{margin:0;background:var(--bg);color:var(--ink);font-family:"Malgun Gothic","Noto Sans KR",sans-serif}}
header{{padding:32px clamp(20px,5vw,72px);background:linear-gradient(120deg,#0f172a,#1d4ed8);color:#fff}}
header h1{{margin:0 0 10px;font-size:clamp(25px,4vw,42px)}} header p{{margin:0;max-width:1000px;line-height:1.7}}
main{{padding:24px clamp(16px,4vw,56px) 60px;max-width:1500px;margin:auto}}
.controls,.cards,.grid{{display:grid;gap:16px}} .controls{{grid-template-columns:repeat(auto-fit,minmax(190px,1fr));margin-bottom:18px}}
label{{font-size:12px;font-weight:700;color:var(--muted)}} select{{width:100%;margin-top:6px;padding:10px;border:1px solid #cbd5e1;border-radius:10px;background:#fff}}
.cards{{grid-template-columns:repeat(auto-fit,minmax(160px,1fr));margin-bottom:18px}} .card,.panel{{background:var(--card);border:1px solid #e2e8f0;border-radius:16px;box-shadow:0 6px 24px rgba(15,23,42,.06)}}
.card{{padding:18px}} .card .n{{font-size:28px;font-weight:800;color:var(--blue)}} .card .label{{font-size:12px;color:var(--muted)}}
.grid{{grid-template-columns:repeat(2,minmax(0,1fr))}} .panel{{padding:14px;min-height:390px}} .wide{{grid-column:1/-1}} h2{{font-size:17px;margin:4px 8px 10px}}
table{{width:100%;border-collapse:collapse;font-size:13px}} th,td{{text-align:left;border-bottom:1px solid #e2e8f0;padding:9px;vertical-align:top}} th{{color:var(--muted)}}
.note{{padding:14px 18px;background:#fffbeb;border:1px solid #fde68a;border-radius:12px;margin:18px 0;line-height:1.6}}
@media(max-width:850px){{.grid{{grid-template-columns:1fr}} .wide{{grid-column:auto}}}}
@media print{{.controls{{display:none}} body{{background:#fff}} .panel,.card{{box-shadow:none}}}}
</style>
<script>{plotly_js}</script>
</head>
<body>
<header><h1>승인된 탐색 분석</h1><p id="question"></p></header>
<main>
<div class="note">기술·비교·탐색 분석입니다. 지표 간 동반 패턴을 원인 또는 예측으로 해석하지 않습니다.</div>
<section class="panel wide" style="margin-bottom:18px"><h2>승인된 지표 정의와 해석 경계</h2><div id="definitions"></div></section>
<section class="panel wide" style="margin-bottom:18px"><h2>핵심 질문에 대한 답변</h2><div id="coreAnswer"></div></section>
<section class="controls">
  <div><label>지표<select id="metric"></select></label></div>
  <div><label>지역·집단<select id="group"><option value="">전체</option></select></label></div>
  <div><label>기준 기간<select id="period"><option value="">전체</option></select></label></div>
</section>
<section class="cards" id="cards"></section>
<section class="grid">
  <article class="panel"><h2>기간별 추세</h2><div id="trend"></div></article>
  <article class="panel"><h2>지역·집단 비교</h2><div id="groups"></div></article>
  <article class="panel"><h2>지표 간 관측 관계</h2><div id="scatter"></div></article>
  <article class="panel"><h2>데이터 품질</h2><div id="quality"></div></article>
  <article class="panel wide"><h2>검증 근거</h2><div id="evidence"></div></article>
  <article class="panel wide"><h2>사용자 추가 데이터 요청</h2><div id="dataRequests"></div></article>
</section>
</main>
<script>
const DATA={payload_json};
const vars=DATA.variables.filter(v=>DATA.records.some(r=>Number.isFinite(Number(r[v.column]))));
const metric=document.getElementById('metric'), group=document.getElementById('group'), period=document.getElementById('period');
const timeVar=DATA.variables.find(v=>/time|year|period|date/i.test((v.role||'')+' '+v.column));
const groupVar=DATA.variables.find(v=>/geo|region|area|group|dimension|category/i.test((v.role||'')+' '+v.column) && (!timeVar||v.column!==timeVar.column));
vars.forEach(v=>metric.add(new Option(v.column+(v.unit?' ('+v.unit+')':''),v.column)));
if(groupVar) [...new Set(DATA.records.map(r=>r[groupVar.column]).filter(v=>v!==null&&v!==''))].sort().forEach(v=>group.add(new Option(v,v)));
if(timeVar) [...new Set(DATA.records.map(r=>r[timeVar.column]).filter(v=>v!==null&&v!==''))].sort().forEach(v=>period.add(new Option(v,v)));
function median(a){{const b=a.filter(Number.isFinite).sort((x,y)=>x-y);if(!b.length)return null;const m=Math.floor(b.length/2);return b.length%2?b[m]:(b[m-1]+b[m])/2}}
function filtered(){{return DATA.records.filter(r=>(!group.value||!groupVar||String(r[groupVar.column])===group.value)&&(!period.value||!timeVar||String(r[timeVar.column])===period.value))}}
function render(){{
 const rows=filtered(), m=metric.value||vars[0]?.column, vals=rows.map(r=>Number(r[m])).filter(Number.isFinite);
 const counts=DATA.validation.counts||{{}};
 document.getElementById('cards').innerHTML=[
  ['관측 행',rows.length],['선택 지표 중앙값',median(vals)?.toFixed(3)??'-'],
  ['검증 근거',counts.validated||0],['제한부 근거',counts.qualified||0]
 ].map(x=>`<div class="card"><div class="n">${{x[1]}}</div><div class="label">${{x[0]}}</div></div>`).join('');
 if(timeVar){{
   const agg={{}}; rows.forEach(r=>{{const t=r[timeVar.column],v=Number(r[m]);if(t!==null&&Number.isFinite(v))(agg[t]??=[]).push(v)}});
   const xs=Object.keys(agg).sort(), ys=xs.map(x=>median(agg[x]));
   Plotly.react('trend',[{{x:xs,y:ys,type:'scatter',mode:'lines+markers',line:{{color:'#2563eb',width:3}}}}],{{margin:{{t:15,r:15,b:45,l:55}},xaxis:{{title:timeVar.column}},yaxis:{{title:m}}}},{{responsive:true,displaylogo:false}});
 }} else document.getElementById('trend').innerHTML='<p>시간 변수가 없습니다.</p>';
 if(groupVar){{
   const agg={{}}; rows.forEach(r=>{{const g=r[groupVar.column],v=Number(r[m]);if(g!==null&&Number.isFinite(v))(agg[g]??=[]).push(v)}});
   const pairs=Object.entries(agg).map(([g,a])=>[g,median(a)]).sort((a,b)=>a[1]-b[1]);
   Plotly.react('groups',[{{x:pairs.map(x=>x[1]),y:pairs.map(x=>x[0]),type:'bar',orientation:'h',marker:{{color:'#0f766e'}}}}],{{margin:{{t:15,r:15,b:45,l:100}},xaxis:{{title:m}}}},{{responsive:true,displaylogo:false}});
 }} else document.getElementById('groups').innerHTML='<p>지역·집단 변수가 없습니다.</p>';
 const second=vars.find(v=>v.column!==m)?.column;
 if(second) Plotly.react('scatter',[{{x:rows.map(r=>r[m]),y:rows.map(r=>r[second]),text:groupVar?rows.map(r=>r[groupVar.column]):[],mode:'markers',type:'scatter',marker:{{color:'#7c3aed',opacity:.7}}}}],{{margin:{{t:15,r:15,b:50,l:60}},xaxis:{{title:m}},yaxis:{{title:second}}}},{{responsive:true,displaylogo:false}});
 else document.getElementById('scatter').innerHTML='<p>두 번째 수치 변수가 없습니다.</p>';
 const q=DATA.quality; Plotly.react('quality',[{{x:q.map(x=>x.table_id),y:q.map(x=>Number(x.missing_rate||0)*100),type:'bar',marker:{{color:'#ea580c'}}}}],{{margin:{{t:15,r:15,b:45,l:55}},yaxis:{{title:'결측률 (%)'}}}},{{responsive:true,displaylogo:false}});
 document.getElementById('evidence').innerHTML='<table><thead><tr><th>ID</th><th>점수</th><th>상태</th><th>검증된 관찰</th><th>제한</th></tr></thead><tbody>'+DATA.evidence.map(e=>`<tr><td>${{e.evidence_id}}</td><td>${{e.insight_score}}</td><td>${{e.validation_status}}</td><td>${{e.summary}}</td><td>${{(e.qualification_reasons||[]).join(', ')}}</td></tr>`).join('')+'</tbody></table>';
 const dr=DATA.dataRequests.requests||[];
 document.getElementById('dataRequests').innerHTML=dr.length
  ? '<table><thead><tr><th>ID</th><th>사유</th><th>요청 내용</th><th>범위</th></tr></thead><tbody>'+dr.map(x=>`<tr><td>${{x.request_id}}</td><td>${{x.reason_code}}</td><td>${{x.message}}</td><td>${{x.requested_scope}}</td></tr>`).join('')+'</tbody></table>'
  : '<p>현재 승인된 분석 범위에서 추가 데이터 요청이 없습니다.</p>';
}}
document.getElementById('question').textContent=DATA.question;
document.getElementById('coreAnswer').innerHTML=(DATA.coreEvidence||[]).length
 ? '<table><thead><tr><th>근거</th><th>구분</th><th>관측 답변</th><th>경계</th></tr></thead><tbody>'+DATA.coreEvidence.map(e=>`<tr><td>${{e.evidence_id}}</td><td>${{e.evidence_class}}</td><td>${{e.summary}}</td><td>${{e.claim_boundary}}</td></tr>`).join('')+'</tbody></table>'
 : '<p>핵심 질문에 직접 연결된 검증 근거가 없습니다.</p>';
const meta=DATA.approvedMetadata||{{}}, defs=meta.measureDefinitions||[];
document.getElementById('definitions').innerHTML=
 (meta.interpretationNotes||[]).map(x=>`<p><b>비교 주의:</b> ${{x}}</p>`).join('')+
 '<p>'+String(meta.sensitivityBoundary||'')+'</p>'+
 '<table><thead><tr><th>변수</th><th>용도</th><th>승인 정의</th><th>단위</th><th>척도</th></tr></thead><tbody>'+
 defs.map(x=>`<tr><td>${{x.column}}</td><td>${{x.usage}}</td><td>${{x.definition}}</td><td>${{x.unit}}</td><td>${{x.measurement_scale}}</td></tr>`).join('')+
 '</tbody></table>';
[metric,group,period].forEach(x=>x.addEventListener('change',render)); render();
</script>
</body></html>"""
    path.write_text(document, encoding="utf-8", newline="\n")


def render(
    execution_path: Path,
    preparation_path: Path,
    eda_path: Path,
    output_dir: Path,
) -> dict[str, Any]:
    execution, preparation, eda = _validate(
        execution_path, preparation_path, eda_path
    )
    if output_dir.exists():
        raise ContractError(f"OUTPUT_DIRECTORY_ALREADY_EXISTS:{output_dir}")
    eda_root = eda_path.parent
    artifacts = eda.get("artifacts")
    if not isinstance(artifacts, dict):
        raise ContractError("EDA_ARTIFACTS_REQUIRED")
    evidence_payload = _load_json(_resolve(eda_root, artifacts["evidence_records"]))
    validation = _load_json(_resolve(eda_root, artifacts["validation_summary"]))
    data_requests = _load_json(
        _resolve(eda_root, artifacts["additional_data_requests"])
    )
    insight_ranking = _load_json(
        _resolve(eda_root, artifacts["insight_ranking"])
    )
    charts_payload = _load_json(_resolve(eda_root, artifacts["chart_manifest"]))
    quality_path = _resolve(eda_root, artifacts["data_quality"])
    evidence = list(evidence_payload.get("evidence", []))
    charts = list(charts_payload.get("charts", []))
    quality = pd.read_csv(quality_path, encoding="utf-8-sig")

    chart_sources: list[tuple[dict[str, Any], Path]] = []
    for chart in charts[:8]:
        if not isinstance(chart, dict) or not isinstance(chart.get("artifact"), dict):
            raise ContractError("INVALID_CHART_ARTIFACT")
        chart_sources.append((chart, _resolve(eda_root, chart["artifact"])))

    output_dir.mkdir(parents=True)
    assets_dir = output_dir / "assets"
    assets_dir.mkdir()
    copied: list[tuple[dict[str, Any], Path]] = []
    markdown_charts: list[tuple[dict[str, Any], str]] = []
    for index, (chart, source) in enumerate(chart_sources, 1):
        target = assets_dir / f"{index:02d}-{re.sub(r'[^a-zA-Z0-9._-]+', '-', source.name)}"
        shutil.copy2(source, target)
        copied.append((chart, target))
        markdown_charts.append((chart, target.relative_to(output_dir).as_posix()))

    report_md = output_dir / "report.md"
    report_pdf = output_dir / "report.pdf"
    dashboard = output_dir / "dashboard.html"
    report_md.write_text(
        _report_text(
            execution,
            preparation,
            eda,
            evidence,
            validation,
            data_requests,
            insight_ranking,
            quality,
            markdown_charts,
        ),
        encoding="utf-8",
        newline="\n",
    )
    _pdf(
        report_pdf,
        execution,
        preparation,
        eda,
        evidence,
        validation,
        data_requests,
        insight_ranking,
        quality,
        copied,
    )
    _dashboard(
        dashboard,
        execution,
        preparation_path,
        preparation,
        evidence,
        validation,
        data_requests,
        insight_ranking,
        quality,
    )
    result = {
        "schema_version": "analysis_deliverables_manifest.v1",
        "execution_id": execution["execution_id"],
        "blueprint_id": execution["blueprint_id"],
        "input_hashes": {
            "execution": _sha256(execution_path),
            "preparation_manifest": _sha256(preparation_path),
            "eda_manifest": _sha256(eda_path),
        },
        "artifacts": {
            "report_markdown": _artifact(report_md, output_dir),
            "report_pdf": _artifact(report_pdf, output_dir),
            "dashboard_html": _artifact(dashboard, output_dir),
            "report_charts": [
                _artifact(path, output_dir) for _, path in copied
            ],
        },
        "claim_boundary": "descriptive-comparative-exploratory-only",
    }
    manifest_path = output_dir / "deliverables_manifest.json"
    manifest_path.write_bytes(_json_bytes(result))
    return result


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Render report and offline dashboard from EDA evidence."
    )
    parser.add_argument("execution", type=Path)
    parser.add_argument("preparation_manifest", type=Path)
    parser.add_argument("eda_manifest", type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    return parser


def main(argv: Iterable[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        manifest = render(
            args.execution.resolve(),
            args.preparation_manifest.resolve(),
            args.eda_manifest.resolve(),
            args.output_dir.resolve(),
        )
        sys.stdout.write(
            json.dumps(
                {
                    "valid": True,
                    "manifest": str(
                        args.output_dir.resolve() / "deliverables_manifest.json"
                    ),
                    "artifacts": manifest["artifacts"],
                },
                ensure_ascii=False,
                sort_keys=True,
            )
            + "\n"
        )
        return 0
    except ContractError as exc:
        sys.stderr.write(
            json.dumps(
                {"valid": False, "errors": [str(exc)]},
                ensure_ascii=False,
                sort_keys=True,
            )
            + "\n"
        )
        return 2
    except Exception as exc:
        sys.stderr.write(
            json.dumps(
                {"valid": False, "errors": [f"{type(exc).__name__}:{exc}"]},
                ensure_ascii=False,
                sort_keys=True,
            )
            + "\n"
        )
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
