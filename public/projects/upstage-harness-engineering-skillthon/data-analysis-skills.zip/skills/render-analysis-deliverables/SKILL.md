---
name: render-analysis-deliverables
description: Render a traceable Markdown report, verified PDF, and serverless single-file Plotly HTML dashboard from completed staged-EDA artifacts. Use when validated or qualified evidence must be presented without recomputing analytical results, while preserving evidence IDs, source scope, denominators, qualifications, and non-causal claim boundaries.
---

# Render Analysis Deliverables

Render presentation artifacts from EDA evidence. Never calculate replacement
metrics in the renderer.

## Workflow

1. Read `references/input-contract.md`.
2. Run
   `scripts/render_deliverables.py EXECUTION PREPARATION_MANIFEST EDA_MANIFEST --output-dir OUTPUT`.
3. Include only `validated` and `qualified` evidence in conclusions. Reproduce
   every qualification next to the associated statement.
   Follow `insight_ranking.json` for ordering and the eight-item limit.
4. Put the evidence-derived answer to the approved core question before charts.
   Include declared-rule groups, declared cohort comparisons, frozen
   association pairs, definition sensitivity, and limitations without
   recomputation or measure-scope expansion.
5. Load `additional_data_requests.json` and display unresolved requests as
   requests for user-provided local files. Never acquire the requested data.
6. Keep `report.md` as the canonical editable report, generate `report.pdf` from
   the same evidence, and embed Plotly plus dashboard data in `dashboard.html`.
7. Render and inspect the PDF pages and open the HTML without a network
   connection before delivery.

## Guardrails

- Reject mismatched execution, preparation, or EDA identifiers and hashes.
- Resolve only artifacts declared by the EDA and preparation manifests.
- Keep report and dashboard values sourced from `evidence_records.json`.
- Do not browse, call APIs, or download data. Render only approved local
  artifacts and EDA-generated user requests.
- Show rejected evidence only in the validation audit, never as a conclusion.
- Repeat the descriptive/exploratory and non-causal limitation prominently.

## Resources

- `scripts/render_deliverables.py`: render Markdown, PDF, and offline HTML.
- `references/input-contract.md`: manifest and evidence requirements.
- `references/output-contract.md`: final artifact contract and QA checklist.
