# Output Contract

Write:

- `report.md`: canonical evidence-linked report;
- `report.pdf`: fixed-layout submission copy;
- `dashboard.html`: offline single-file interactive dashboard;
- `deliverables_manifest.json`: input hashes and output artifact hashes;
- `assets/*.png`: copied report charts.

The report order is:

1. problem definition;
2. data and provenance;
3. data quality;
4. direct answer to the approved core question, including derived-rule groups,
   declared cohort comparison, frozen association-pair results, sensitivity,
   and claim limitations;
5. key visual findings;
6. supporting temporal/distribution evidence;
7. sensitivity validation;
8. limitations and claim boundary;
9. additional data requests to the user;
10. reproducibility.

Validated and qualified findings must be ordered by
`insight_ranking.json`. Show no more than the frozen top eight findings, and
use each evidence record's deterministic `summary` and `insight_score`.
The renderer must not ask the model to recalculate metrics, select a preferred
finding, or invent a domain explanation.
The main report and dashboard expose only the frozen focus measures and axes;
other approved measures remain outside the core narrative. The direct answer
must be reproduced from evidence records and appear before charts.

The dashboard must include metric, region/group, and period controls when the
corresponding dimensions exist, along with overview, trend, regional comparison,
association, data-quality, and evidence panels. Embed Plotly and data so the
file opens without a server or network.
Include a user data-request panel and state that analysis used only local files
provided by the user.

Before delivery, reopen the PDF with `pypdf`, render every page to PNG, inspect
for clipped or broken Korean text, and open the HTML while offline.
