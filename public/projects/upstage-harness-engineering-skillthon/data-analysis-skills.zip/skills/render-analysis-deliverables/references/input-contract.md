# Input Contract

Require matching:

- approved `analysis_execution_request.v1`;
- completed `preparation_manifest.v1`;
- `eda_manifest.v1` with `COMPLETE` or `PARTIAL_EXECUTION`.

Verify all three execution and blueprint IDs plus the stored SHA-256 references.
Resolve evidence, validation, insight-ranking, additional-data-request, chart-manifest,
quality-table, and chart artifacts only inside the EDA output directory.
Resolve dashboard data only from the preparation manifest.

Use `validated` and `qualified` records for report and dashboard conclusions.
Preserve qualification reasons. Keep rejected records in the validation-count
display only.
Order and limit conclusions using `insight_ranking.json`; do not ask a model to
choose which evidence looks important.
Display additional requests as user-provided-local-file requirements. Never
resolve them through network access.
