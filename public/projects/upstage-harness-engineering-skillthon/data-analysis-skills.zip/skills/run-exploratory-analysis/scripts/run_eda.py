#!/usr/bin/env python3
"""Run deterministic staged EDA from approved prepared artifacts."""

from __future__ import annotations

import argparse
from collections import defaultdict
import hashlib
import json
import math
from pathlib import Path
import re
import sys
from typing import Any, Iterable

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns


EXECUTION_SCHEMA = "analysis_execution_request.v1"
PREPARATION_SCHEMA = "preparation_manifest.v1"
EDA_SCHEMA = "eda_manifest.v1"
ALLOWED_MODULES = {
    "data_quality",
    "distribution",
    "group_comparison",
    "temporal_pattern",
    "spatial_pattern",
    "association",
    "anomaly_screen",
    "cross_source_consistency",
}
APPROVED_STATUSES = {"AUTO_CONFIDENT", "USER_CONFIRMED"}
NUMERIC_TYPES = {"integer", "number", "float", "double", "decimal"}


class ContractError(ValueError):
    """Raised before output creation for an invalid or drifted contract."""


def _load_json(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8-sig"))
    if not isinstance(payload, dict):
        raise ContractError(f"TOP_LEVEL_JSON_MUST_BE_OBJECT:{path}")
    return payload


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(65_536), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _json_bytes(value: Any) -> bytes:
    return (
        json.dumps(
            value,
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
            allow_nan=False,
        )
        + "\n"
    ).encode("utf-8")


def _write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(_json_bytes(value))


def _safe_name(value: str) -> str:
    normalized = re.sub(r"[^a-zA-Z0-9._-]+", "-", value).strip("-")
    return normalized or "artifact"


def _resolve_artifact(
    manifest_dir: Path, artifact: dict[str, Any]
) -> Path:
    relative = artifact.get("path")
    expected_hash = artifact.get("sha256")
    if not isinstance(relative, str) or not relative:
        raise ContractError("ARTIFACT_PATH_REQUIRED")
    candidate = (manifest_dir / relative).resolve()
    root = manifest_dir.resolve()
    try:
        candidate.relative_to(root)
    except ValueError as exc:
        raise ContractError(f"ARTIFACT_OUTSIDE_MANIFEST_ROOT:{relative}") from exc
    if not candidate.is_file():
        raise ContractError(f"ARTIFACT_NOT_FOUND:{relative}")
    if (
        not isinstance(expected_hash, str)
        or _sha256(candidate) != expected_hash
    ):
        raise ContractError(f"ARTIFACT_HASH_MISMATCH:{relative}")
    return candidate


def _analysis_task(execution: dict[str, Any]) -> dict[str, Any]:
    tasks = [
        task
        for task in execution.get("tasks", [])
        if isinstance(task, dict)
        and task.get("task_type") == "exploratory_analysis"
    ]
    if len(tasks) != 1:
        raise ContractError("EXACTLY_ONE_EDA_TASK_REQUIRED")
    task = tasks[0]
    if task.get("executor") != "run-exploratory-analysis":
        raise ContractError("EDA_EXECUTOR_MISMATCH")
    return task


def _validate_inputs(
    execution_path: Path,
    manifest_path: Path,
) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any]]:
    execution = _load_json(execution_path)
    manifest = _load_json(manifest_path)
    if execution.get("schema_version") != EXECUTION_SCHEMA:
        raise ContractError(f"EXPECTED_SCHEMA:{EXECUTION_SCHEMA}")
    approval = execution.get("approval")
    if (
        not isinstance(approval, dict)
        or approval.get("status") != "APPROVED"
        or not str(approval.get("approved_by", "")).strip()
    ):
        raise ContractError("EXPLICIT_APPROVAL_REQUIRED")
    data_policy = execution.get("data_access_policy")
    if (
        not isinstance(data_policy, dict)
        or data_policy.get("schema_version") != "data_access_policy.v1"
        or data_policy.get("mode") != "USER_PROVIDED_LOCAL_ONLY"
        or data_policy.get("network_access") is not False
        or data_policy.get("remote_fetch") is not False
        or data_policy.get("when_data_is_missing") != "REQUEST_USER"
    ):
        raise ContractError("USER_PROVIDED_LOCAL_DATA_POLICY_REQUIRED")
    if manifest.get("schema_version") != PREPARATION_SCHEMA:
        raise ContractError(f"EXPECTED_SCHEMA:{PREPARATION_SCHEMA}")
    if manifest.get("status") != "COMPLETED":
        raise ContractError("COMPLETED_PREPARATION_REQUIRED")
    for field in ("execution_id", "blueprint_id"):
        if manifest.get(field) != execution.get(field):
            raise ContractError(f"PREPARATION_{field.upper()}_MISMATCH")
    if manifest.get("execution_request_sha256") != _sha256(execution_path):
        raise ContractError("EXECUTION_REQUEST_HASH_MISMATCH")
    frozen = execution.get("frozen_variable_inventory")
    if (
        not isinstance(frozen, dict)
        or frozen.get("status") != "READY"
        or frozen.get("confirmation_requests") != []
    ):
        raise ContractError("RESOLVED_FROZEN_VARIABLE_INVENTORY_REQUIRED")
    task = _analysis_task(execution)
    task_inputs = task.get("inputs")
    if (
        not isinstance(task_inputs, dict)
        or task_inputs.get("variable_inventory") != frozen
    ):
        raise ContractError("EDA_VARIABLE_INVENTORY_NOT_FROZEN")
    focus = task_inputs.get("analysis_focus")
    if (
        not isinstance(focus, dict)
        or focus != execution.get("frozen_analysis_focus")
        or focus.get("schema_version") != "analysis_focus.v1"
    ):
        raise ContractError("FROZEN_ANALYSIS_FOCUS_REQUIRED")
    policy = task_inputs.get("staged_eda_policy")
    if (
        not isinstance(policy, dict)
        or policy != execution.get("frozen_staged_eda_policy")
        or policy.get("schema_version") != "staged_eda_policy.v1"
        or policy.get("core_modules") != policy.get("stage_1_modules")
        or not set(policy.get("requested_modules", []))
        <= set(policy.get("core_modules", []))
        or policy.get("stage_2_requires_recorded_trigger") is not True
        or policy.get("stage_3_applies_to_each_candidate_finding") is not True
        or policy.get("evidence_statuses")
        != ["validated", "qualified", "rejected"]
        or not isinstance(policy.get("maximum_report_charts"), int)
        or policy.get("maximum_report_charts") < 1
    ):
        raise ContractError("FROZEN_STAGED_EDA_POLICY_REQUIRED")
    recipe = task_inputs.get("generic_analysis_recipe")
    if (
        not isinstance(recipe, dict)
        or recipe != execution.get("frozen_generic_analysis_recipe")
        or recipe.get("schema_version") != "generic_analysis_recipe.v1"
        or recipe.get("cost_bounds", {}).get(
            "maximum_detailed_measures_per_table"
        )
        != 20
        or not isinstance(
            recipe.get("cost_bounds", {}).get(
                "maximum_association_pairs_per_table"
            ),
            int,
        )
        or recipe.get("cost_bounds", {}).get(
            "maximum_association_pairs_per_table"
        )
        < 1
        or recipe.get("univariate", {}).get("mad_z_threshold") != 3.5
        or recipe.get("temporal", {}).get("minimum_periods_for_trend") != 3
        or recipe.get("group_comparison", {}).get(
            "maximum_groups_for_full_chart"
        )
        != 30
        or recipe.get("association", {}).get("strong_threshold") != 0.5
        or recipe.get("association", {}).get("pair_scope")
        != "frozen_association_pairs_only"
        or recipe.get("spatial_baseline", {}).get(
            "geometry_methods_allowed"
        )
        is not False
        or recipe.get("finding_validation", {}).get(
            "applies_to_each_candidate"
        )
        is not True
        or recipe.get("insight_ranking", {}).get(
            "maximum_report_insights"
        )
        != 8
        or recipe.get("claim_policy", {}).get("causal_language") is not False
        or recipe.get("claim_policy", {}).get("prediction_language")
        is not False
    ):
        raise ContractError("FROZEN_GENERIC_ANALYSIS_RECIPE_REQUIRED")
    steps = execution.get("tasks", [])
    planned_steps = task_inputs.get("analysis_steps")
    if not isinstance(planned_steps, list) or not planned_steps:
        raise ContractError("ANALYSIS_STEPS_REQUIRED")
    modules = {
        step.get("module")
        for step in planned_steps
        if isinstance(step, dict)
    }
    if not modules <= ALLOWED_MODULES:
        raise ContractError(
            "UNSUPPORTED_ANALYSIS_MODULE:"
            + ",".join(sorted(str(item) for item in modules - ALLOWED_MODULES))
        )
    del steps
    return execution, manifest, task


def _table_specs(
    manifest_path: Path, manifest: dict[str, Any]
) -> list[dict[str, Any]]:
    root = manifest_path.parent
    join = manifest.get("join")
    if isinstance(join, dict) and isinstance(join.get("artifact"), dict):
        return [
            {
                "table_id": "integrated",
                "source_ids": sorted(
                    str(item.get("source_id"))
                    for item in manifest.get("sources", [])
                    if isinstance(item, dict)
                ),
                "path": _resolve_artifact(root, join["artifact"]),
                "variables": join.get("variables", []),
                "join_coverage": join.get("join_coverage"),
            }
        ]
    result: list[dict[str, Any]] = []
    for source in manifest.get("sources", []):
        if not isinstance(source, dict) or not isinstance(
            source.get("artifact"), dict
        ):
            raise ContractError("INVALID_SOURCE_ARTIFACT")
        result.append(
            {
                "table_id": str(source.get("table_id")),
                "source_ids": [str(source.get("source_id"))],
                "path": _resolve_artifact(root, source["artifact"]),
                "variables": source.get("variables", []),
                "join_coverage": None,
            }
        )
    if not result:
        raise ContractError("NO_PREPARED_TABLES")
    return result


def _eligible(variable: dict[str, Any], module: str) -> bool:
    allowed = variable.get("allowed_analyses")
    return (
        variable.get("status") in APPROVED_STATUSES
        and isinstance(allowed, list)
        and module in allowed
    )


def _eligible_measure(variable: dict[str, Any]) -> bool:
    allowed = variable.get("allowed_analyses")
    roles = set(variable.get("analysis_roles") or [])
    return (
        variable.get("status") in APPROVED_STATUSES
        and "MEASURE" in roles
        and not roles & {"QUALITY_ONLY", "EXCLUDED"}
        and isinstance(allowed, list)
        and bool(
            {
                "mean",
                "median",
                "distribution",
                "difference",
                "sum",
                "ratio",
                "association",
                "anomaly_screen",
            }
            & set(allowed)
        )
    )


def _role(variable: dict[str, Any]) -> str:
    return str(variable.get("semantic_role", "")).lower()


def _is_time(variable: dict[str, Any]) -> bool:
    roles = set(variable.get("analysis_roles") or [])
    if roles:
        return "TIME_AXIS" in roles and not roles & {
            "QUALITY_ONLY", "EXCLUDED"
        }
    role = _role(variable)
    name = str(variable.get("final_column", "")).lower()
    return (
        role in {"time", "time_axis", "temporal", "temporal_dimension"}
        or name in {"year", "date", "period", "month", "quarter"}
        or name.endswith("_year")
    )


def _is_group(variable: dict[str, Any]) -> bool:
    roles = set(variable.get("analysis_roles") or [])
    if roles:
        return "GROUP" in roles and not roles & {
            "QUALITY_ONLY", "EXCLUDED"
        }
    role = _role(variable)
    return role in {
        "dimension",
        "group",
        "geography",
        "geographic",
        "geographic_dimension",
        "category",
    } or any(
        token in str(variable.get("final_column", "")).lower()
        for token in ("region", "area", "province", "city", "group")
    )


def _select_focus_axes(
    variables: list[dict[str, Any]], focus: dict[str, Any] | None
) -> dict[str, list[dict[str, Any]]]:
    by_id = {
        str(variable.get("variable_id")): variable
        for variable in variables
        if isinstance(variable, dict)
    }

    def selected(field: str, predicate: Any) -> list[dict[str, Any]]:
        reference = (focus or {}).get(field)
        if isinstance(reference, dict) and reference.get("variable_id"):
            variable = by_id.get(str(reference["variable_id"]))
            if variable is None or not predicate(variable):
                raise ContractError(
                    f"FROZEN_ANALYSIS_FOCUS_AXIS_INVALID:{field}:"
                    f"{reference.get('variable_id')}"
                )
            return [variable]
        return sorted(
            [variable for variable in variables if predicate(variable)],
            key=lambda item: str(item.get("variable_id")),
        )

    return {
        "time": selected("time_axis", _is_time),
        "group": selected("group_axis", _is_group),
        "geography": selected(
            "geography_axis",
            lambda item: (
                "GEO_AXIS" in set(item.get("analysis_roles") or [])
                and not set(item.get("analysis_roles") or [])
                & {"QUALITY_ONLY", "EXCLUDED"}
            ),
        ),
    }


def _is_numeric(variable: dict[str, Any]) -> bool:
    physical = str(variable.get("physical_type", "")).lower()
    scale = str(variable.get("measurement_scale", "")).lower()
    return physical in NUMERIC_TYPES or scale in {"interval", "ratio"}


def _read_table(spec: dict[str, Any]) -> pd.DataFrame:
    frame = pd.read_csv(spec["path"], encoding="utf-8-sig")
    for variable in spec["variables"]:
        if not isinstance(variable, dict):
            continue
        column = variable.get("final_column")
        if column not in frame.columns:
            raise ContractError(
                f"FROZEN_VARIABLE_COLUMN_NOT_FOUND:{column}:{spec['table_id']}"
            )
        if _is_numeric(variable) or _is_time(variable):
            converted = pd.to_numeric(frame[column], errors="coerce")
            if converted.notna().any():
                frame[column] = converted
    return frame


def _python_value(value: Any) -> Any:
    if value is None or pd.isna(value):
        return None
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating, float)):
        if not math.isfinite(float(value)):
            return None
        return round(float(value), 8)
    if isinstance(value, (np.bool_,)):
        return bool(value)
    return value


def _write_csv(path: Path, rows: list[dict[str, Any]], columns: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows, columns=columns).to_csv(
        path, index=False, encoding="utf-8", lineterminator="\n"
    )


def _artifact(path: Path, output_dir: Path) -> dict[str, Any]:
    return {
        "path": path.relative_to(output_dir).as_posix(),
        "sha256": _sha256(path),
    }


def _plot_setup() -> None:
    sns.set_theme(style="whitegrid")
    plt.rcParams.update(
        {
            "figure.dpi": 120,
            "savefig.dpi": 120,
            "font.family": ["Malgun Gothic", "DejaVu Sans"],
            "axes.unicode_minus": False,
        }
    )


def _save_plot(fig: plt.Figure, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(path, bbox_inches="tight", metadata={"Software": "Codex EDA"})
    plt.close(fig)


def _variable_map(spec: dict[str, Any]) -> dict[str, dict[str, Any]]:
    return {
        str(variable["final_column"]): variable
        for variable in spec["variables"]
        if isinstance(variable, dict)
        and isinstance(variable.get("final_column"), str)
    }


def _id(prefix: str, counter: int) -> str:
    return f"{prefix}-{counter:04d}"


def _trend_slope(values: pd.DataFrame, time_col: str, value_col: str) -> tuple[float, int]:
    grouped = (
        values[[time_col, value_col]]
        .dropna()
        .groupby(time_col, as_index=False)[value_col]
        .mean()
        .sort_values(time_col)
    )
    if len(grouped) < 3:
        return math.nan, len(grouped)
    x = pd.to_numeric(grouped[time_col], errors="coerce")
    y = pd.to_numeric(grouped[value_col], errors="coerce")
    valid = x.notna() & y.notna()
    if valid.sum() < 3 or x[valid].nunique() < 2:
        return math.nan, int(valid.sum())
    return float(np.polyfit(x[valid], y[valid], 1)[0]), int(valid.sum())


def _unit_kind(variable: dict[str, Any]) -> str:
    unit = str(variable.get("unit") or "").strip().lower()
    if unit in {"%", "percent", "percentage", "percentage point", "pp"}:
        return "percent"
    if "index" in unit or "지수" in unit:
        return "index"
    return "other"


def _mad_outlier_count(series: pd.Series, threshold: float) -> int:
    usable = pd.to_numeric(series, errors="coerce").dropna()
    if usable.empty:
        return 0
    median = float(usable.median())
    mad = float((usable - median).abs().median())
    if mad == 0 or not math.isfinite(mad):
        return 0
    robust_z = 0.6745 * (usable - median).abs() / mad
    return int((robust_z > threshold).sum())


def _derived_change_type(variable: dict[str, Any]) -> str:
    if _unit_kind(variable) == "percent":
        return "percentage_point_change"
    return "absolute_change"


def _measure_time_basis(
    execution: dict[str, Any], variable: dict[str, Any]
) -> str | None:
    source_id = variable.get("source_id")
    source_column = variable.get("source_column")
    sources = execution.get("frozen_preparation_plan", {}).get("sources", [])
    for source in sources:
        if not isinstance(source, dict) or source.get("source_id") != source_id:
            continue
        structure = source.get("dataset_structure")
        basis = (
            structure.get("measure_time_basis")
            if isinstance(structure, dict)
            else None
        )
        if isinstance(basis, dict):
            value = basis.get(source_column)
            if isinstance(value, str) and value.strip():
                return value.strip().lower()
    return None


def _finding_summary(candidate: dict[str, Any]) -> str:
    kind = candidate.get("kind")
    columns = [str(value) for value in candidate.get("columns", [])]
    value = candidate.get("value")
    denominator = candidate.get("denominator")
    if kind == "temporal_pattern":
        name = columns[-1] if columns else "수치 변수"
        return (
            f"{name}의 기간별 평균에서 기간당 선형 변화량 {value}가 "
            f"관찰되었다(n={denominator})."
        )
    if kind == "temporal_change":
        name = columns[-1] if columns else "수치 변수"
        return (
            f"{name}의 최초 기간과 최신 기간 사이 "
            f"{candidate.get('metric')}는 {value}였다(n={denominator})."
        )
    if kind == "recent_window_shift":
        name = columns[-1] if columns else "수치 변수"
        return (
            f"{name}의 최근 구간 평균은 직전 구간 평균보다 {value}만큼 "
            f"달랐다(n={denominator})."
        )
    if kind == "group_gap":
        name = columns[-1] if columns else "수치 변수"
        return (
            f"집단별 {name} 중앙값의 최대-최소 차이는 {value}였다"
            f"(집단 수={denominator})."
        )
    if kind == "association":
        names = "와 ".join(columns[-2:]) if columns else "두 수치 변수"
        spearman = candidate.get("details", {}).get("spearman")
        strength = candidate.get("details", {}).get(
            "strength_classification"
        )
        boundary = (
            " 승인 임계값 기준 강한 연관은 관찰되지 않았다."
            if strength == "below_strong_threshold"
            else ""
        )
        return (
            f"{names} 사이에 Pearson r={value}, Spearman ρ={spearman}의 "
            f"관측 관계가 있었다(n={denominator}).{boundary}"
        )
    if kind == "declared_rule_summary":
        details = candidate.get("details", {})
        groups = details.get("group_results", [])
        qualifying = details.get("qualifying_groups", [])
        return (
            f"선언 규칙 {candidate.get('rule_id')}을 {len(groups)}개 집단에 "
            f"적용했고, 기록된 선택 조건을 충족한 집단은 "
            f"{', '.join(str(item.get('label')) for item in qualifying) or '없음'}"
            f"이었다."
        )
    if kind == "derived_group_comparison":
        details = candidate.get("details", {})
        selected = details.get("selected_groups", [])
        remaining = details.get("remaining_groups", [])
        measures = details.get("measure_results", [])
        measure_text = "; ".join(
            (
                f"{item.get('measure_column')}: 선택-나머지 "
                f"중앙값 차이={item.get('difference')}"
            )
            for item in measures
        )
        return (
            f"선언 규칙으로 선택된 집단 "
            f"{', '.join(str(item.get('label')) for item in selected)}와 "
            f"나머지 {len(remaining)}개 집단을 비교했다. {measure_text} "
            "(관측 비인과 집단 대조)."
        )
    if kind == "declared_sensitivity_summary":
        details = candidate.get("details", {})
        return (
            f"정의 민감도 {candidate.get('pair_id')}에서 pairwise coverage="
            f"{details.get('pairwise_complete_coverage')}, 방향 일치율="
            f"{details.get('direction_agreement')}, 집단 순위 안정성="
            f"{details.get('group_rank_stability')}, 임계값 분류 일치율="
            f"{details.get('threshold_classification_agreement')}였다."
        )
    if kind == "distribution_asymmetry":
        name = columns[-1] if columns else "수치 변수"
        return f"{name}의 왜도는 {value}로 비대칭 분포 후보였다(n={denominator})."
    if kind == "anomaly_screen":
        name = columns[-1] if columns else "수치 변수"
        return (
            f"{name}에서 IQR 또는 MAD 기준 검토 후보 {value}건이 "
            f"발견되었다(n={denominator})."
        )
    return (
        f"{candidate.get('metric')}={value}의 탐색 패턴이 관찰되었다"
        f"(n={denominator})."
    )


def _selector_matches(value: Any, operator: str, target: float) -> bool:
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        return False
    observed = float(value)
    if operator == "equal":
        return math.isclose(observed, target, rel_tol=0, abs_tol=1e-12)
    if operator == "at_least":
        return observed >= target
    if operator == "at_most":
        return observed <= target
    raise ContractError(f"UNSUPPORTED_GROUP_SELECTOR_OPERATOR:{operator}")


def _declared_summary_candidates(
    frame: pd.DataFrame,
    variables: dict[str, dict[str, Any]],
    focus: dict[str, Any],
    derived: list[dict[str, Any]],
    sensitivity: list[dict[str, Any]],
    table_id: str,
    source_ids: list[str],
    start_counter: int,
) -> tuple[list[dict[str, Any]], int]:
    by_id = _focus_variable_columns(variables)
    counter = start_counter
    result: list[dict[str, Any]] = []
    label_reference = focus.get("geography_label", {})
    label_col = by_id.get(str(label_reference.get("variable_id")))
    group_reference = focus.get("group_axis", {})
    group_col = by_id.get(str(group_reference.get("variable_id")))
    label_by_group: dict[Any, Any] = {}
    if label_col and group_col:
        mapping = frame[[group_col, label_col]].dropna().drop_duplicates()
        if (
            mapping.groupby(group_col)[label_col].nunique().le(1).all()
        ):
            label_by_group = dict(
                mapping.drop_duplicates(group_col)[
                    [group_col, label_col]
                ].itertuples(index=False, name=None)
            )

    comparisons_by_rule = defaultdict(list)
    for comparison in focus.get("derived_group_comparisons", []):
        comparisons_by_rule[str(comparison["selector_rule_id"])].append(
            comparison
        )
    for rule in focus.get("derived_rules", []):
        rule_id = str(rule["rule_id"])
        rows = [
            item for item in derived if str(item.get("rule_id")) == rule_id
        ]
        valid = [
            item
            for item in rows
            if item.get("validation_status") == "validated"
            and item.get("value") is not None
        ]
        qualifying: list[dict[str, Any]] = []
        selectors = comparisons_by_rule.get(rule_id, [])
        if selectors:
            selector = selectors[0]
            qualifying = [
                {
                    "group": item.get("group_value"),
                    "label": label_by_group.get(
                        item.get("group_value"), item.get("group_value")
                    ),
                    "value": item.get("value"),
                }
                for item in valid
                if _selector_matches(
                    item.get("value"),
                    str(selector["selector_operator"]),
                    float(selector["selector_value"]),
                )
            ]
        group_results = [
            {
                "group": item.get("group_value"),
                "label": label_by_group.get(
                    item.get("group_value"), item.get("group_value")
                ),
                "value": item.get("value"),
                "denominator": item.get("denominator"),
                "validation_status": item.get("validation_status"),
            }
            for item in rows
        ]
        counter += 1
        result.append(
            {
                "finding_id": _id("finding", counter),
                "stage": 1,
                "kind": "declared_rule_summary",
                "rule_id": rule_id,
                "table_id": table_id,
                "source_ids": source_ids,
                "variable_ids": [
                    rule["input_variable"]["variable_id"],
                    rule["time_axis"]["variable_id"],
                    rule["group_axis"]["variable_id"],
                ],
                "columns": [
                    rule["time_axis"]["source_column"],
                    rule["group_axis"]["source_column"],
                    rule["input_variable"]["source_column"],
                ],
                "metric": str(rule["operation"]),
                "value": len(qualifying),
                "denominator": len(valid),
                "minimum_required_denominator": 1,
                "scope": {"table": table_id},
                "unit": rule["input_variable"].get("unit"),
                "calculation": (
                    "one summary candidate from all group-level results of "
                    "the frozen declared rule"
                ),
                "threshold": rule.get("threshold"),
                "details": {
                    "operation": rule["operation"],
                    "group_count": len(rows),
                    "valid_group_count": len(valid),
                    "group_results": group_results,
                    "qualifying_groups": qualifying,
                },
                "requested_module": (
                    "spatial_pattern"
                    if rule["group_axis"]["variable_id"]
                    == focus.get("geography_axis", {}).get("variable_id")
                    else "group_comparison"
                ),
            }
        )

    derived_by_rule = defaultdict(list)
    for row in derived:
        if row.get("rule_id"):
            derived_by_rule[str(row["rule_id"])].append(row)
    for comparison in focus.get("derived_group_comparisons", []):
        selector_rows = [
            row
            for row in derived_by_rule[str(comparison["selector_rule_id"])]
            if row.get("validation_status") == "validated"
        ]
        selected_ids = {
            row.get("group_value")
            for row in selector_rows
            if _selector_matches(
                row.get("value"),
                str(comparison["selector_operator"]),
                float(comparison["selector_value"]),
            )
        }
        minimum_observations = int(
            comparison["minimum_observations_per_group"]
        )
        measure_results: list[dict[str, Any]] = []
        eligible_groups: set[Any] | None = None
        for measure in comparison["comparison_measures"]:
            value_col = by_id[str(measure["variable_id"])]
            work = frame[[group_col, value_col]].copy()
            work[value_col] = pd.to_numeric(
                work[value_col], errors="coerce"
            )
            grouped = (
                work.dropna()
                .groupby(group_col)[value_col]
                .agg(["count", "median"])
            )
            grouped = grouped[
                grouped["count"] >= minimum_observations
            ]
            current_groups = set(grouped.index.tolist())
            eligible_groups = (
                current_groups
                if eligible_groups is None
                else eligible_groups & current_groups
            )
            selected_values = grouped.loc[
                grouped.index.isin(selected_ids), "median"
            ]
            remaining_values = grouped.loc[
                ~grouped.index.isin(selected_ids), "median"
            ]
            difference = (
                float(selected_values.median() - remaining_values.median())
                if not selected_values.empty and not remaining_values.empty
                else None
            )
            measure_results.append(
                {
                    "measure_variable_id": measure["variable_id"],
                    "measure_column": measure["source_column"],
                    "selected_group_median": _python_value(
                        selected_values.median()
                        if not selected_values.empty
                        else None
                    ),
                    "remaining_group_median": _python_value(
                        remaining_values.median()
                        if not remaining_values.empty
                        else None
                    ),
                    "difference": _python_value(difference),
                }
            )
        eligible_groups = eligible_groups or set()
        selected_eligible = sorted(
            selected_ids & eligible_groups, key=str
        )
        remaining_eligible = sorted(
            eligible_groups - selected_ids, key=str
        )
        counter += 1
        result.append(
            {
                "finding_id": _id("finding", counter),
                "stage": 1,
                "kind": "derived_group_comparison",
                "comparison_id": comparison["comparison_id"],
                "selector_rule_id": comparison["selector_rule_id"],
                "table_id": table_id,
                "source_ids": source_ids,
                "variable_ids": [
                    focus["primary_measure"]["variable_id"],
                    focus["group_axis"]["variable_id"],
                    *[
                        item["variable_id"]
                        for item in comparison["comparison_measures"]
                    ],
                ],
                "columns": [
                    focus["group_axis"]["source_column"],
                    *[
                        item["source_column"]
                        for item in comparison["comparison_measures"]
                    ],
                ],
                "metric": comparison["comparison_statistic"],
                "value": len(selected_eligible),
                "denominator": (
                    len(selected_eligible) + len(remaining_eligible)
                ),
                "minimum_required_denominator": (
                    int(comparison["minimum_selected_groups"])
                    + int(comparison["minimum_remaining_groups"])
                ),
                "scope": {"table": table_id},
                "unit": None,
                "calculation": comparison["comparison_statistic"],
                "claim_boundary": comparison["claim_boundary"],
                "details": {
                    "selector_operator": comparison["selector_operator"],
                    "selector_value": comparison["selector_value"],
                    "selected_groups": [
                        {
                            "group": value,
                            "label": label_by_group.get(value, value),
                        }
                        for value in selected_eligible
                    ],
                    "remaining_groups": [
                        {
                            "group": value,
                            "label": label_by_group.get(value, value),
                        }
                        for value in remaining_eligible
                    ],
                    "measure_results": measure_results,
                    "minimum_observations_per_group": minimum_observations,
                    "missing_policy": comparison["missing_policy"],
                },
                "requested_module": "group_comparison",
                "prevalidation_reasons": [
                    *(
                        ["INSUFFICIENT_SELECTED_GROUPS"]
                        if len(selected_eligible)
                        < int(comparison["minimum_selected_groups"])
                        else []
                    ),
                    *(
                        ["INSUFFICIENT_REMAINING_GROUPS"]
                        if len(remaining_eligible)
                        < int(comparison["minimum_remaining_groups"])
                        else []
                    ),
                    *(
                        ["INCOMPLETE_COMPARISON_MEASURE_RESULTS"]
                        if any(
                            item.get("difference") is None
                            for item in measure_results
                        )
                        else []
                    ),
                ],
            }
        )

    for row in sensitivity:
        if not row.get("pair_id"):
            continue
        counter += 1
        result.append(
            {
                "finding_id": _id("finding", counter),
                "stage": 3,
                "kind": "declared_sensitivity_summary",
                "pair_id": row["pair_id"],
                "table_id": table_id,
                "source_ids": source_ids,
                "variable_ids": [
                    row["primary_variable_id"],
                    row["alternative_variable_id"],
                ],
                "columns": [
                    str(row["primary_variable_id"]),
                    str(row["alternative_variable_id"]),
                ],
                "metric": "declared_definition_stability",
                "value": row.get("direction_agreement"),
                "denominator": row.get("pairwise_complete_count", 0),
                "minimum_required_denominator": row.get(
                    "minimum_pairwise_observations", 2
                ),
                "scope": {"table": table_id},
                "unit": None,
                "calculation": (
                    "frozen pairwise coverage, direction, rank, and "
                    "threshold-classification stability"
                ),
                "details": {
                    key: row.get(key)
                    for key in (
                        "checks",
                        "pairwise_complete_coverage",
                        "direction_agreement",
                        "pearson",
                        "spearman",
                        "group_rank_stability",
                        "threshold",
                        "threshold_classification_agreement",
                    )
                },
                "requested_module": "association",
            }
        )
    return result, counter


def _enrich_question_fields(
    candidate: dict[str, Any], focus: dict[str, Any]
) -> None:
    primary_id = str(
        focus.get("primary_measure", {}).get("variable_id") or ""
    )
    kind = str(candidate.get("kind") or "")
    module_by_kind = {
        "temporal_pattern": "temporal_pattern",
        "temporal_change": "temporal_pattern",
        "recent_window_shift": "temporal_pattern",
        "group_gap": "group_comparison",
        "derived_group_comparison": "group_comparison",
        "association": "association",
        "declared_sensitivity_summary": "association",
        "distribution_asymmetry": "data_quality",
        "anomaly_screen": "data_quality",
    }
    candidate.setdefault(
        "requested_module", module_by_kind.get(kind, "data_quality")
    )
    candidate["uses_primary_measure"] = bool(
        primary_id and primary_id in candidate.get("variable_ids", [])
    )
    candidate["declared_rule_related"] = bool(
        candidate.get("rule_id") or candidate.get("selector_rule_id")
    )
    evidence_class_by_kind = {
        "declared_rule_summary": "derived_rule",
        "derived_group_comparison": "cohort_comparison",
        "association": "association",
        "declared_sensitivity_summary": "sensitivity",
        "temporal_pattern": "temporal",
        "temporal_change": "temporal",
        "recent_window_shift": "temporal",
        "group_gap": "group_spatial",
    }
    candidate["evidence_class"] = evidence_class_by_kind.get(
        kind, "context"
    )
    candidate["question_relevance"] = (
        "core"
        if candidate["evidence_class"]
        in {
            "derived_rule",
            "cohort_comparison",
            "association",
            "sensitivity",
        }
        or (
            candidate["uses_primary_measure"]
            and candidate["requested_module"]
            in set(focus.get("requested_modules", []))
        )
        else (
            "supporting"
            if candidate["requested_module"]
            in set(focus.get("requested_modules", []))
            else "context"
        )
    )


def _select_diverse_evidence(
    records: list[dict[str, Any]],
    policy: dict[str, Any],
    requested_modules: list[str],
) -> list[dict[str, Any]]:
    maximum = int(policy["maximum_report_insights"])
    maximum_per_module = int(
        policy.get("maximum_per_requested_module", maximum)
    )
    maximum_per_kind = int(policy.get("maximum_per_kind", maximum))
    eligible = [
        record
        for record in records
        if record.get("validation_status")
        not in set(policy.get("exclude_statuses", ["rejected"]))
    ]
    eligible.sort(
        key=lambda record: (
            -float(record.get("insight_score") or 0),
            str(record.get("evidence_id")),
        )
    )
    selected: list[dict[str, Any]] = []
    selected_ids: set[str] = set()
    module_counts: defaultdict[str, int] = defaultdict(int)
    kind_counts: defaultdict[str, int] = defaultdict(int)

    def add(record: dict[str, Any], *, force: bool = False) -> bool:
        evidence_id = str(record.get("evidence_id"))
        if evidence_id in selected_ids or len(selected) >= maximum:
            return False
        module = str(record.get("requested_module") or "")
        kind = str(record.get("kind") or "")
        if not force and (
            module_counts[module] >= maximum_per_module
            or kind_counts[kind] >= maximum_per_kind
        ):
            return False
        selected.append(record)
        selected_ids.add(evidence_id)
        module_counts[module] += 1
        kind_counts[kind] += 1
        return True

    for record in eligible:
        if record.get("evidence_class") == "association":
            add(record, force=True)
    for evidence_class in policy.get("required_evidence_classes", []):
        if any(
            item.get("evidence_class") == evidence_class
            for item in selected
        ):
            continue
        match = next(
            (
                item
                for item in eligible
                if item.get("evidence_class") == evidence_class
            ),
            None,
        )
        if match is not None:
            add(match, force=True)
    for module in requested_modules:
        if module_counts[module]:
            continue
        match = next(
            (
                item
                for item in eligible
                if item.get("requested_module") == module
            ),
            None,
        )
        if match is not None:
            add(match, force=True)
    for record in eligible:
        add(record)
    return selected


def _insight_score(record: dict[str, Any], status_weights: dict[str, Any]) -> float:
    score = float(status_weights.get(record.get("validation_status"), 0))
    denominator = int(record.get("denominator") or 0)
    score += min(20.0, denominator) 
    if record.get("kind") in {
        "temporal_pattern",
        "temporal_change",
        "recent_window_shift",
        "group_gap",
        "association",
    }:
        score += 15.0
    sensitivity = record.get("sensitivity")
    if isinstance(sensitivity, dict) and sensitivity.get("stable_direction") is True:
        score += 15.0
    score -= 5.0 * len(record.get("qualification_reasons", []))
    return round(max(0.0, score), 4)


def _focus_variable_columns(
    variables: dict[str, dict[str, Any]],
) -> dict[str, str]:
    return {
        str(variable.get("variable_id")): column
        for column, variable in variables.items()
        if variable.get("variable_id")
    }


def _maximum_true_run(values: list[bool | None]) -> int:
    maximum = 0
    current = 0
    for value in values:
        if value is True:
            current += 1
            maximum = max(maximum, current)
        else:
            current = 0
    return maximum


def _declared_derived_rows(
    frame: pd.DataFrame,
    variables: dict[str, dict[str, Any]],
    focus: dict[str, Any],
    table_id: str,
    source_ids: list[str],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    by_id = _focus_variable_columns(variables)
    rows: list[dict[str, Any]] = []
    qualifications: list[dict[str, Any]] = []
    for rule in focus.get("derived_rules", []):
        if not isinstance(rule, dict):
            continue
        input_id = str(rule.get("input_variable", {}).get("variable_id"))
        time_id = str(rule.get("time_axis", {}).get("variable_id"))
        group_id = str(rule.get("group_axis", {}).get("variable_id"))
        required_ids = (input_id, time_id, group_id)
        if any(variable_id not in by_id for variable_id in required_ids):
            continue
        input_col, time_col, group_col = (
            by_id[input_id],
            by_id[time_id],
            by_id[group_id],
        )
        work = frame[[group_col, time_col, input_col]].copy()
        work[input_col] = pd.to_numeric(work[input_col], errors="coerce")
        work = work.sort_values([group_col, time_col])
        operation = str(rule.get("operation"))
        minimum = int(rule.get("minimum_observations") or 0)
        for group_value, group_frame in work.groupby(group_col, dropna=False):
            series = group_frame[input_col]
            observed = series.dropna()
            status = "validated"
            qualification = None
            value: float | int | None = None
            denominator = int(len(observed))
            if denominator < minimum:
                status = "qualified"
                qualification = "INSUFFICIENT_OBSERVATIONS"
            elif operation == "proportion_below_threshold":
                threshold = float(rule["threshold"])
                value = float((observed < threshold).mean())
            elif operation == "consecutive_periods_below_threshold":
                threshold = float(rule["threshold"])
                states = [
                    None if pd.isna(item) else bool(float(item) < threshold)
                    for item in series.tolist()
                ]
                value = _maximum_true_run(states)
            elif operation == "window_mean_difference":
                recent_size = int(rule["recent_window_size"])
                previous_size = int(rule["previous_window_size"])
                required = recent_size + previous_size
                if denominator < max(minimum, required):
                    status = "qualified"
                    qualification = "INSUFFICIENT_WINDOW_COVERAGE"
                else:
                    values = observed.iloc[-required:]
                    previous = values.iloc[:previous_size]
                    recent = values.iloc[-recent_size:]
                    value = float(recent.mean() - previous.mean())
            elif operation == "first_latest_difference":
                value = float(observed.iloc[-1] - observed.iloc[0])
            if rule.get("partial_period_policy") == "exclude_partial_periods":
                status = "qualified"
                qualification = "COMPLETE_PERIOD_FLAG_NOT_DECLARED_IN_RULE"
            row = {
                "derived_id": (
                    f"{table_id}:{rule.get('rule_id')}:"
                    f"{_safe_name(group_value)}"
                ),
                "table_id": table_id,
                "source_ids": "|".join(source_ids),
                "source_variable_id": input_id,
                "derived_name": operation,
                "value": _python_value(value),
                "unit": rule.get("input_variable", {}).get("unit"),
                "formula": operation,
                "denominator": denominator,
                "eligibility_basis": (
                    f"minimum_observations={minimum};"
                    f"missing_policy={rule.get('missing_policy')};"
                    f"partial_period_policy={rule.get('partial_period_policy')}"
                ),
                "rule_id": rule.get("rule_id"),
                "operation": operation,
                "group_variable_id": group_id,
                "time_variable_id": time_id,
                "group_value": _python_value(group_value),
                "threshold": _python_value(rule.get("threshold")),
                "minimum_observations": minimum,
                "recent_window_size": rule.get("recent_window_size"),
                "previous_window_size": rule.get("previous_window_size"),
                "missing_policy": rule.get("missing_policy"),
                "partial_period_policy": rule.get("partial_period_policy"),
                "validation_status": status,
                "qualification_reason": qualification,
            }
            rows.append(row)
            if qualification:
                qualifications.append(
                    {
                        "reason_code": qualification,
                        "variable_ids": list(required_ids),
                        "rule_id": rule.get("rule_id"),
                    }
                )
    return rows, qualifications


def _declared_sensitivity_rows(
    frame: pd.DataFrame,
    variables: dict[str, dict[str, Any]],
    focus: dict[str, Any],
    table_id: str,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    by_id = _focus_variable_columns(variables)
    rows: list[dict[str, Any]] = []
    qualifications: list[dict[str, Any]] = []
    for pair in focus.get("sensitivity_pairs", []):
        if not isinstance(pair, dict):
            continue
        primary_id = str(pair.get("primary_variable", {}).get("variable_id"))
        alternative_id = str(
            pair.get("alternative_variable", {}).get("variable_id")
        )
        group_id = str(pair.get("group_axis", {}).get("variable_id"))
        time_id = str(pair.get("time_axis", {}).get("variable_id"))
        required_ids = (primary_id, alternative_id, group_id, time_id)
        if any(variable_id not in by_id for variable_id in required_ids):
            continue
        primary_col, alternative_col, group_col, time_col = (
            by_id[primary_id],
            by_id[alternative_id],
            by_id[group_id],
            by_id[time_id],
        )
        work = frame[
            [primary_col, alternative_col, group_col, time_col]
        ].copy()
        work[primary_col] = pd.to_numeric(
            work[primary_col], errors="coerce"
        )
        work[alternative_col] = pd.to_numeric(
            work[alternative_col], errors="coerce"
        )
        complete = work.dropna(subset=[primary_col, alternative_col])
        minimum = int(pair.get("minimum_pairwise_observations") or 0)
        checks = list(pair.get("checks") or [])
        status = "validated"
        reason = None
        pearson = None
        spearman = None
        direction = None
        threshold_agreement = None
        rank_stability = None
        if len(complete) < minimum:
            status = "qualified"
            reason = "INSUFFICIENT_PAIRWISE_OBSERVATIONS"
        else:
            if "direction_agreement" in checks:
                direction = float(
                    (
                        np.sign(complete[primary_col])
                        == np.sign(complete[alternative_col])
                    ).mean()
                )
            if (
                "pearson_co_movement" in checks
                and complete[primary_col].nunique() > 1
                and complete[alternative_col].nunique() > 1
            ):
                pearson = float(
                    complete[primary_col].corr(complete[alternative_col])
                )
            if (
                "spearman_co_movement" in checks
                and complete[primary_col].nunique() > 1
                and complete[alternative_col].nunique() > 1
            ):
                spearman = float(
                    complete[primary_col].corr(
                        complete[alternative_col], method="spearman"
                    )
                )
            if "threshold_classification_agreement" in checks:
                threshold = float(pair["threshold"])
                threshold_agreement = float(
                    (
                        (complete[primary_col] < threshold)
                        == (complete[alternative_col] < threshold)
                    ).mean()
                )
            if "group_rank_stability" in checks:
                grouped = (
                    complete.groupby(group_col)[
                        [primary_col, alternative_col]
                    ]
                    .mean()
                    .dropna()
                )
                if len(grouped) >= 2:
                    rank_stability = float(
                        grouped[primary_col].corr(
                            grouped[alternative_col], method="spearman"
                        )
                    )
                else:
                    status = "qualified"
                    reason = "INSUFFICIENT_GROUPS_FOR_RANK_STABILITY"
        row = {
            "finding_id": None,
            "check": "declared_sensitivity_pair",
            "full_value": _python_value(pearson),
            "sensitivity_value": _python_value(spearman),
            "full_denominator": int(len(frame)),
            "sensitivity_denominator": int(len(complete)),
            "stable_direction": (
                None if direction is None else direction >= 0.8
            ),
            "latest_period_stable": None,
            "iqr_outlier_stable": None,
            "pair_id": pair.get("pair_id"),
            "table_id": table_id,
            "primary_variable_id": primary_id,
            "alternative_variable_id": alternative_id,
            "checks": "|".join(checks),
            "pairwise_complete_count": int(len(complete)),
            "pairwise_complete_coverage": (
                round(float(len(complete) / len(frame)), 8)
                if len(frame)
                else None
            ),
            "direction_agreement": _python_value(direction),
            "pearson": _python_value(pearson),
            "spearman": _python_value(spearman),
            "group_rank_stability": _python_value(rank_stability),
            "threshold": _python_value(pair.get("threshold")),
            "threshold_classification_agreement": _python_value(
                threshold_agreement
            ),
            "minimum_pairwise_observations": minimum,
            "validation_status": status,
            "qualification_reason": reason,
        }
        rows.append(row)
        if reason:
            qualifications.append(
                {
                    "reason_code": reason,
                    "variable_ids": list(required_ids),
                    "pair_id": pair.get("pair_id"),
                }
            )
    return rows, qualifications


def run(
    execution_path: Path, manifest_path: Path, output_dir: Path
) -> dict[str, Any]:
    execution, manifest, task = _validate_inputs(execution_path, manifest_path)
    if output_dir.exists():
        raise ContractError(f"OUTPUT_DIRECTORY_ALREADY_EXISTS:{output_dir}")
    specs = _table_specs(manifest_path, manifest)
    output_dir.mkdir(parents=True)
    _plot_setup()

    quality_rows: list[dict[str, Any]] = []
    numeric_rows: list[dict[str, Any]] = []
    derived_rows: list[dict[str, Any]] = []
    temporal_rows: list[dict[str, Any]] = []
    group_rows: list[dict[str, Any]] = []
    spatial_rows: list[dict[str, Any]] = []
    association_rows: list[dict[str, Any]] = []
    association_drilldown_rows: list[dict[str, Any]] = []
    selection_rows: list[dict[str, Any]] = []
    sensitivity_rows: list[dict[str, Any]] = []
    candidates: list[dict[str, Any]] = []
    charts: list[dict[str, Any]] = []
    triggers: list[dict[str, Any]] = []
    module_execution_records: list[dict[str, Any]] = []
    pending_stage_2_candidates: list[dict[str, Any]] = []
    pending_temporal_sensitivity: list[dict[str, Any]] = []
    chart_limit = int(
        task["inputs"]["staged_eda_policy"]["maximum_report_charts"]
    )
    requested_modules = set(
        task["inputs"]["staged_eda_policy"].get("requested_modules", [])
    )
    recipe = task["inputs"]["generic_analysis_recipe"]
    univariate_recipe = recipe["univariate"]
    temporal_recipe = recipe["temporal"]
    group_recipe = recipe["group_comparison"]
    association_recipe = recipe["association"]
    finding_counter = 0
    evidence_counter = 0
    frames_for_dashboard: list[dict[str, Any]] = []
    finding_sensitivity: dict[str, dict[str, Any]] = {}
    declared_qualifications: list[dict[str, Any]] = []

    for spec in specs:
        frame = _read_table(spec)
        variables = _variable_map(spec)
        table_id = spec["table_id"]
        frames_for_dashboard.append(
            {
                "table_id": table_id,
                "source_ids": spec["source_ids"],
                "artifact": str(spec["path"]),
                "columns": list(frame.columns),
            }
        )
        missing_cells = int(frame.isna().sum().sum())
        total_cells = int(frame.shape[0] * frame.shape[1])
        duplicate_rows = int(frame.duplicated().sum())
        quality_rows.append(
            {
                "table_id": table_id,
                "source_ids": "|".join(spec["source_ids"]),
                "rows": int(len(frame)),
                "columns": int(len(frame.columns)),
                "missing_cells": missing_cells,
                "missing_rate": (
                    round(missing_cells / total_cells, 8) if total_cells else 0.0
                ),
                "duplicate_rows": duplicate_rows,
                "join_coverage": _python_value(spec.get("join_coverage")),
            }
        )
        if missing_cells:
            triggers.append(
                {
                    "trigger": "missingness",
                    "table_id": table_id,
                    "observed_cells": missing_cells,
                    "reason": "At least one prepared value is missing.",
                }
            )
        coverage = spec.get("join_coverage")
        if isinstance(coverage, (int, float)) and coverage < 1:
            triggers.append(
                {
                    "trigger": "join_loss",
                    "table_id": table_id,
                    "observed_coverage": round(float(coverage), 8),
                    "reason": "Integrated rows do not cover every prepared key.",
                }
            )

        if (
            len(charts) < chart_limit
            and not any(
                chart.get("kind") == "missingness_heatmap"
                for chart in charts
            )
        ):
            missing_by_column = frame.isna().mean().sort_values(ascending=False)
            fig, ax = plt.subplots(figsize=(8, max(2.8, len(frame.columns) * 0.28)))
            sns.heatmap(
                missing_by_column.to_frame("missing_rate"),
                annot=True,
                fmt=".1%",
                cmap="Blues",
                vmin=0,
                vmax=max(0.01, float(missing_by_column.max())),
                cbar=False,
                ax=ax,
            )
            ax.set_title(f"Missingness - {table_id}")
            ax.set_xlabel("")
            path = output_dir / "charts" / f"{len(charts)+1:02d}-missingness-{_safe_name(table_id)}.png"
            _save_plot(fig, path)
            charts.append(
                {
                    "chart_id": f"chart-{len(charts)+1:02d}",
                    "stage": 1,
                    "kind": "missingness_heatmap",
                    "title": f"Missingness - {table_id}",
                    "table_id": table_id,
                    "variable_ids": [],
                    "evidence_ids": [],
                    "context_chart": True,
                    "requested_module": "data_quality",
                    "question_relevance": "context",
                    "artifact": _artifact(path, output_dir),
                }
            )

        analysis_focus = task["inputs"].get("analysis_focus") or {}
        primary_measure_id = str(
            analysis_focus.get("primary_measure", {}).get("variable_id")
            or ""
        )
        focus_axes = _select_focus_axes(
            list(variables.values()), analysis_focus
        )
        time_columns = [
            str(variable.get("final_column"))
            for variable in focus_axes["time"]
        ]
        group_columns = [
            str(variable.get("final_column"))
            for variable in focus_axes["group"]
        ]
        focus_measure_ids = {
            str(reference.get("variable_id"))
            for reference in [
                analysis_focus.get("primary_measure"),
                *(analysis_focus.get("comparison_measures") or []),
            ]
            if isinstance(reference, dict) and reference.get("variable_id")
        }
        declared_derived, derived_qualifications = _declared_derived_rows(
            frame,
            variables,
            analysis_focus,
            table_id,
            spec["source_ids"],
        )
        declared_sensitivity, sensitivity_qualifications = (
            _declared_sensitivity_rows(
                frame,
                variables,
                analysis_focus,
                table_id,
            )
        )
        derived_rows.extend(declared_derived)
        sensitivity_rows.extend(declared_sensitivity)
        declared_qualifications.extend(derived_qualifications)
        declared_qualifications.extend(sensitivity_qualifications)
        promoted_candidates, finding_counter = (
            _declared_summary_candidates(
                frame,
                variables,
                analysis_focus,
                declared_derived,
                declared_sensitivity,
                table_id,
                spec["source_ids"],
                finding_counter,
            )
        )
        candidates.extend(promoted_candidates)
        numeric_columns: list[str] = []
        for column, variable in variables.items():
            if (
                _is_numeric(variable)
                and not _is_time(variable)
                and not _is_group(variable)
                and _eligible_measure(variable)
                and (
                    not focus_measure_ids
                    or str(variable.get("variable_id")) in focus_measure_ids
                )
                and any(
                _eligible(variable, module)
                for module in (
                    "distribution",
                    "group_comparison",
                    "temporal_pattern",
                    "association",
                    "anomaly_screen",
                )
                )
            ):
                numeric_columns.append(column)
        numeric_columns = sorted(
            numeric_columns,
            key=lambda column: (
                0
                if str(variables[column].get("variable_id"))
                in focus_measure_ids
                else 1,
                float(frame[column].isna().mean()),
                str(variables[column].get("variable_id")),
            ),
        )
        measure_limit = int(
            recipe["cost_bounds"]["maximum_detailed_measures_per_table"]
        )
        eligible_numeric_columns = list(numeric_columns)
        numeric_columns = numeric_columns[:measure_limit]
        selection_rows.append(
            {
                "table_id": table_id,
                "eligible_measure_count": len(eligible_numeric_columns),
                "selected_measure_count": len(numeric_columns),
                "selected_columns": "|".join(numeric_columns),
                "excluded_by_cost_bound": "|".join(
                    eligible_numeric_columns[measure_limit:]
                ),
                "selection_rule": (
                    "missing_rate_ascending_then_variable_id_ascending"
                ),
            }
        )

        for column in sorted(numeric_columns):
            series = pd.to_numeric(frame[column], errors="coerce")
            usable = series.dropna()
            if usable.empty:
                continue
            q1 = float(usable.quantile(0.25))
            q3 = float(usable.quantile(0.75))
            iqr = q3 - q1
            lower = q1 - 1.5 * iqr
            upper = q3 + 1.5 * iqr
            outliers = int(((usable < lower) | (usable > upper)).sum())
            mad_outliers = _mad_outlier_count(
                usable, float(univariate_recipe["mad_z_threshold"])
            )
            mean = float(usable.mean())
            std = float(usable.std(ddof=1)) if usable.size > 1 else math.nan
            coefficient_of_variation = (
                std / abs(mean)
                if math.isfinite(std) and mean != 0
                else math.nan
            )
            skewness = (
                float(usable.skew()) if usable.size >= 3 else math.nan
            )
            numeric_rows.append(
                {
                    "table_id": table_id,
                    "variable_id": variables[column].get("variable_id"),
                    "column": column,
                    "n": int(usable.size),
                    "missing": int(series.isna().sum()),
                    "zero_rate": _python_value((usable == 0).mean()),
                    "negative_rate": _python_value((usable < 0).mean()),
                    "mean": _python_value(mean),
                    "median": _python_value(usable.median()),
                    "std": _python_value(std),
                    "coefficient_of_variation": _python_value(
                        coefficient_of_variation
                    ),
                    "skewness": _python_value(skewness),
                    "min": _python_value(usable.min()),
                    "q1": _python_value(q1),
                    "q3": _python_value(q3),
                    "max": _python_value(usable.max()),
                    "iqr_outlier_count": outliers,
                    "mad_outlier_count": mad_outliers,
                }
            )
            if (
                math.isfinite(skewness)
                and abs(skewness)
                >= float(univariate_recipe["skewness_trigger"])
            ):
                triggers.append(
                    {
                        "trigger": "distribution_asymmetry",
                        "table_id": table_id,
                        "variable_id": variables[column].get("variable_id"),
                        "absolute_skewness": round(abs(skewness), 8),
                        "reason": "Absolute sample skewness meets the frozen threshold.",
                    }
                )
                finding_counter += 1
                pending_stage_2_candidates.append(
                    {
                        "finding_id": _id("finding", finding_counter),
                        "kind": "distribution_asymmetry",
                        "table_id": table_id,
                        "source_ids": spec["source_ids"],
                        "variable_ids": [
                            variables[column].get("variable_id")
                        ],
                        "columns": [column],
                        "metric": "sample_skewness",
                        "value": _python_value(skewness),
                        "denominator": int(usable.size),
                        "scope": {"table": table_id},
                        "unit": variables[column].get("unit"),
                        "calculation": "pandas unbiased sample skewness",
                    }
                )
            if outliers or mad_outliers:
                review_count = max(outliers, mad_outliers)
                triggers.append(
                    {
                        "trigger": "robust_outlier_candidates",
                        "table_id": table_id,
                        "variable_id": variables[column].get("variable_id"),
                        "count": review_count,
                        "iqr_count": outliers,
                        "mad_count": mad_outliers,
                        "reason": (
                            "Values meet the frozen 1.5-IQR or MAD robust-z "
                            "review rule."
                        ),
                    }
                )
                finding_counter += 1
                pending_stage_2_candidates.append(
                    {
                        "finding_id": _id("finding", finding_counter),
                        "kind": "anomaly_screen",
                        "table_id": table_id,
                        "source_ids": spec["source_ids"],
                        "variable_ids": [variables[column].get("variable_id")],
                        "columns": [column],
                        "metric": "robust_outlier_candidate_count",
                        "value": review_count,
                        "denominator": int(usable.size),
                        "scope": {"table": table_id},
                        "unit": variables[column].get("unit"),
                        "calculation": (
                            "max(count outside 1.5-IQR bounds, "
                            "count with modified MAD z > 3.5)"
                        ),
                        "details": {
                            "iqr_outlier_count": outliers,
                            "mad_outlier_count": mad_outliers,
                        },
                    }
                )
            if (
                len(charts) < chart_limit
                and _eligible(variables[column], "distribution")
                and str(variables[column].get("variable_id"))
                == str(primary_measure_id)
            ):
                fig, (hist_ax, box_ax) = plt.subplots(
                    2,
                    1,
                    figsize=(7.5, 5.6),
                    gridspec_kw={"height_ratios": [4, 1]},
                )
                sns.histplot(
                    usable,
                    kde=usable.nunique() > 2,
                    ax=hist_ax,
                    color="#2563EB",
                )
                hist_ax.axvline(
                    float(usable.median()),
                    color="#DC2626",
                    linestyle="--",
                )
                hist_ax.set_title(f"Distribution - {column}")
                sns.boxplot(
                    x=usable,
                    ax=box_ax,
                    color="#93C5FD",
                    orient="h",
                )
                box_ax.set_xlabel(column)
                path = output_dir / "charts" / f"{len(charts)+1:02d}-distribution-{_safe_name(column)}.png"
                _save_plot(fig, path)
                charts.append(
                    {
                        "chart_id": f"chart-{len(charts)+1:02d}",
                        "stage": 1,
                        "kind": "distribution",
                        "title": f"Distribution - {column}",
                        "table_id": table_id,
                        "variable_ids": [variables[column].get("variable_id")],
                        "evidence_ids": [],
                        "context_chart": True,
                        "requested_module": "distribution",
                        "question_relevance": "supporting",
                        "artifact": _artifact(path, output_dir),
                    }
                )

        if time_columns:
            time_col = sorted(time_columns)[0]
            for column in sorted(numeric_columns):
                variable = variables[column]
                if (
                    not _eligible(variables[time_col], "temporal_pattern")
                    or not _eligible_measure(variable)
                ):
                    continue
                grouped = (
                    frame[[time_col, column]]
                    .dropna()
                    .groupby(time_col, as_index=False)[column]
                    .mean()
                    .sort_values(time_col)
                )
                if len(grouped) >= 2:
                    first_value = float(grouped[column].iloc[0])
                    latest_value = float(grouped[column].iloc[-1])
                    change = latest_value - first_value
                    change_type = _derived_change_type(variable)
                    time_basis = _measure_time_basis(execution, variable)
                    percent_change = None
                    if (
                        str(variable.get("measurement_scale", "")).upper()
                        == "RATIO"
                        and _unit_kind(variable) == "other"
                        and first_value > 0
                        and time_basis
                        in {
                            "snapshot",
                            "period_total",
                            "period_average",
                            "rate",
                        }
                    ):
                        percent_change = (
                            (latest_value - first_value) / first_value * 100
                        )
                    temporal_rows.append(
                        {
                            "table_id": table_id,
                            "variable_id": variable.get("variable_id"),
                            "column": column,
                            "periods": int(len(grouped)),
                            "first_period": _python_value(
                                grouped[time_col].iloc[0]
                            ),
                            "latest_period": _python_value(
                                grouped[time_col].iloc[-1]
                            ),
                            "first_value": _python_value(first_value),
                            "latest_value": _python_value(latest_value),
                            "absolute_change": _python_value(change),
                            "percent_change": _python_value(percent_change),
                            "change_type": change_type,
                            "recent_window_change": None,
                            "period_difference_std": _python_value(
                                grouped[column].diff().dropna().std(ddof=1)
                            ),
                        }
                    )
                    derived_rows.append(
                        {
                            "derived_id": (
                                f"{table_id}:{column}:{change_type}"
                            ),
                            "table_id": table_id,
                            "source_ids": "|".join(spec["source_ids"]),
                            "source_variable_id": variable.get("variable_id"),
                            "derived_name": change_type,
                            "value": _python_value(change),
                            "unit": (
                                "percentage_point"
                                if change_type == "percentage_point_change"
                                else variable.get("unit")
                            ),
                            "formula": "latest_period_mean - first_period_mean",
                            "denominator": int(len(grouped)),
                            "minimum_required_denominator": 2,
                            "eligibility_basis": (
                                "confirmed percent unit"
                                if change_type == "percentage_point_change"
                                else "approved quantitative measure"
                            ),
                        }
                    )
                    if percent_change is not None:
                        derived_rows.append(
                            {
                                "derived_id": (
                                    f"{table_id}:{column}:percent-change"
                                ),
                                "table_id": table_id,
                                "source_ids": "|".join(spec["source_ids"]),
                                "source_variable_id": variable.get(
                                    "variable_id"
                                ),
                                "derived_name": "percent_change",
                                "value": _python_value(percent_change),
                                "unit": "percent",
                                "formula": (
                                    "(latest_period_mean - "
                                    "first_period_mean) / "
                                    "first_period_mean * 100"
                                ),
                                "denominator": int(len(grouped)),
                                "eligibility_basis": (
                                    f"confirmed ratio scale and "
                                    f"measure_time_basis={time_basis}"
                                ),
                            }
                        )
                    finding_counter += 1
                    candidates.append(
                        {
                            "finding_id": _id("finding", finding_counter),
                            "kind": "temporal_change",
                            "table_id": table_id,
                            "source_ids": spec["source_ids"],
                            "variable_ids": [
                                variables[time_col].get("variable_id"),
                                variable.get("variable_id"),
                            ],
                            "columns": [time_col, column],
                            "metric": change_type,
                            "value": _python_value(change),
                            "denominator": int(len(grouped)),
                            "scope": {
                                "table": table_id,
                                "first_period": _python_value(
                                    grouped[time_col].iloc[0]
                                ),
                                "latest_period": _python_value(
                                    grouped[time_col].iloc[-1]
                                ),
                            },
                            "unit": (
                                "percentage_point"
                                if change_type == "percentage_point_change"
                                else variable.get("unit")
                            ),
                            "calculation": (
                                "latest period mean - first period mean"
                            ),
                        }
                    )
                minimum_windows = int(
                    temporal_recipe[
                        "minimum_periods_for_window_comparison"
                    ]
                )
                window_size = int(temporal_recipe["window_size"])
                if len(grouped) >= minimum_windows:
                    recent_mean = float(
                        grouped[column].iloc[-window_size:].mean()
                    )
                    prior_mean = float(
                        grouped[column]
                        .iloc[-2 * window_size : -window_size]
                        .mean()
                    )
                    window_change = recent_mean - prior_mean
                    temporal_rows[-1]["recent_window_change"] = _python_value(
                        window_change
                    )
                    derived_rows.append(
                        {
                            "derived_id": (
                                f"{table_id}:{column}:recent-window-change"
                            ),
                            "table_id": table_id,
                            "source_ids": "|".join(spec["source_ids"]),
                            "source_variable_id": variable.get("variable_id"),
                            "derived_name": "recent_window_change",
                            "value": _python_value(window_change),
                            "unit": variable.get("unit"),
                            "formula": (
                                f"mean(last {window_size} periods) - "
                                f"mean(previous {window_size} periods)"
                            ),
                            "denominator": int(2 * window_size),
                            "minimum_required_denominator": int(
                                2 * window_size
                            ),
                            "eligibility_basis": (
                                f"at least {minimum_windows} observed periods"
                            ),
                        }
                    )
                    finding_counter += 1
                    candidates.append(
                        {
                            "finding_id": _id("finding", finding_counter),
                            "kind": "recent_window_shift",
                            "table_id": table_id,
                            "source_ids": spec["source_ids"],
                            "variable_ids": [
                                variables[time_col].get("variable_id"),
                                variable.get("variable_id"),
                            ],
                            "columns": [time_col, column],
                            "metric": "recent_vs_previous_window_change",
                            "value": _python_value(window_change),
                            "denominator": int(2 * window_size),
                            "minimum_required_denominator": int(
                                2 * window_size
                            ),
                            "scope": {
                                "table": table_id,
                                "window_size": window_size,
                            },
                            "unit": variable.get("unit"),
                            "calculation": (
                                f"mean(last {window_size} periods) - "
                                f"mean(previous {window_size} periods)"
                            ),
                        }
                    )
                slope, periods = _trend_slope(frame, time_col, column)
                if not math.isfinite(slope):
                    continue
                finding_counter += 1
                finding_id = _id("finding", finding_counter)
                candidates.append(
                    {
                        "finding_id": finding_id,
                        "kind": "temporal_pattern",
                        "table_id": table_id,
                        "source_ids": spec["source_ids"],
                        "variable_ids": [
                            variables[time_col].get("variable_id"),
                            variable.get("variable_id"),
                        ],
                        "columns": [time_col, column],
                        "metric": "linear_slope_per_period",
                        "value": _python_value(slope),
                        "denominator": periods,
                        "minimum_required_denominator": int(
                            temporal_recipe["minimum_periods_for_trend"]
                        ),
                        "scope": {
                            "table": table_id,
                            "time_column": time_col,
                            "minimum": _python_value(frame[time_col].min()),
                            "maximum": _python_value(frame[time_col].max()),
                        },
                        "unit": variable.get("unit"),
                        "calculation": "OLS slope of period means; descriptive only",
                    }
                )
                pending_temporal_sensitivity.append(
                    {
                        "finding_id": finding_id,
                        "frame": frame,
                        "time_col": time_col,
                        "value_col": column,
                        "full_value": slope,
                        "full_denominator": periods,
                    }
                )
                if (
                    len(charts) < chart_limit
                    and str(variable.get("variable_id"))
                    == str(primary_measure_id)
                ):
                    fig, ax = plt.subplots(figsize=(8, 4.5))
                    sns.lineplot(
                        data=grouped, x=time_col, y=column, marker="o", ax=ax
                    )
                    ax.set_title(f"Temporal pattern - {column}")
                    path = output_dir / "charts" / f"{len(charts)+1:02d}-temporal-{_safe_name(column)}.png"
                    _save_plot(fig, path)
                    charts.append(
                        {
                            "chart_id": f"chart-{len(charts)+1:02d}",
                            "stage": 1,
                            "kind": "temporal_pattern",
                            "title": f"Temporal pattern - {column}",
                            "table_id": table_id,
                            "variable_ids": candidates[-1]["variable_ids"],
                            "evidence_ids": [],
                            "finding_ids": [finding_id],
                            "context_chart": False,
                            "requested_module": "temporal_pattern",
                            "question_relevance": "supporting",
                            "artifact": _artifact(path, output_dir),
                        }
                    )

        by_variable_id = {
            str(variable.get("variable_id")): column
            for column, variable in variables.items()
        }
        frozen_pairs: list[tuple[dict[str, Any], str, str]] = []
        if "association" in requested_modules:
            for frozen_pair in recipe.get("association_pairs", []):
                left_id = str(
                    frozen_pair.get("left_variable", {}).get("variable_id")
                )
                right_id = str(
                    frozen_pair.get("right_variable", {}).get("variable_id")
                )
                if left_id not in by_variable_id or right_id not in by_variable_id:
                    raise ContractError(
                        "FROZEN_ASSOCIATION_PAIR_COLUMN_NOT_FOUND:"
                        f"{frozen_pair.get('pair_id')}"
                    )
                frozen_pairs.append(
                    (
                        frozen_pair,
                        by_variable_id[left_id],
                        by_variable_id[right_id],
                    )
                )
        association_screen: list[
            tuple[
                dict[str, Any],
                str,
                str,
                pd.DataFrame,
                float,
                float,
                str,
            ]
        ] = []
        minimum_pairwise = int(association_recipe["minimum_pairwise_rows"])
        for frozen_pair, left, right in frozen_pairs:
            pair = frame[[left, right]].apply(
                pd.to_numeric, errors="coerce"
            ).dropna()
            corr = math.nan
            spearman = math.nan
            if (
                len(pair) >= minimum_pairwise
                and pair[left].nunique() > 1
                and pair[right].nunique() > 1
            ):
                corr = float(pair[left].corr(pair[right]))
                spearman = float(
                    pair[left].corr(pair[right], method="spearman")
                )
            association_rows.append(
                {
                    "pair_id": frozen_pair.get("pair_id"),
                    "table_id": table_id,
                    "left_variable_id": variables[left].get("variable_id"),
                    "right_variable_id": variables[right].get("variable_id"),
                    "left_column": left,
                    "right_column": right,
                    "n": int(len(pair)),
                    "pearson": _python_value(corr),
                    "spearman": _python_value(spearman),
                }
            )
            finding_counter += 1
            association_finding_id = _id(
                "finding", finding_counter
            )
            strong_threshold = float(
                association_recipe["strong_threshold"]
            )
            candidates.append(
                {
                    "finding_id": association_finding_id,
                    "stage": 1,
                    "kind": "association",
                    "pair_id": frozen_pair.get("pair_id"),
                    "table_id": table_id,
                    "source_ids": spec["source_ids"],
                    "variable_ids": [
                        variables[left].get("variable_id"),
                        variables[right].get("variable_id"),
                    ],
                    "columns": [left, right],
                    "metric": "pearson_correlation",
                    "value": _python_value(corr),
                    "denominator": int(len(pair)),
                    "minimum_required_denominator": minimum_pairwise,
                    "scope": {"table": table_id},
                    "unit": None,
                    "calculation": (
                        "frozen pairwise-complete Pearson and Spearman "
                        "association baseline; non-causal"
                    ),
                    "details": {
                        "spearman": _python_value(spearman),
                        "strong_threshold": strong_threshold,
                        "strength_classification": (
                            "meets_strong_threshold"
                            if math.isfinite(corr)
                            and math.isfinite(spearman)
                            and max(abs(corr), abs(spearman))
                            >= strong_threshold
                            else "below_strong_threshold"
                        ),
                    },
                    "requested_module": "association",
                }
            )
            association_screen.append(
                (
                    frozen_pair,
                    left,
                    right,
                    pair,
                    corr,
                    spearman,
                    association_finding_id,
                )
            )
            if len(charts) < chart_limit and not pair.empty:
                fig, ax = plt.subplots(figsize=(6.8, 5))
                sns.regplot(
                    data=pair,
                    x=left,
                    y=right,
                    scatter_kws={"alpha": 0.7},
                    line_kws={"color": "#DC2626"},
                    ax=ax,
                )
                ax.set_title(
                    f"Observed association - {left} vs {right}"
                )
                path = (
                    output_dir
                    / "charts"
                    / (
                        f"{len(charts)+1:02d}-association-"
                        f"{_safe_name(left)}-{_safe_name(right)}.png"
                    )
                )
                _save_plot(fig, path)
                charts.append(
                    {
                        "chart_id": f"chart-{len(charts)+1:02d}",
                        "stage": 1,
                        "kind": "association_baseline",
                        "pair_id": frozen_pair.get("pair_id"),
                        "title": (
                            f"Observed association - {left} vs {right}"
                        ),
                        "table_id": table_id,
                        "variable_ids": candidates[-1]["variable_ids"],
                        "evidence_ids": [],
                        "finding_ids": [association_finding_id],
                        "context_chart": False,
                        "requested_module": "association",
                        "question_relevance": "core",
                        "artifact": _artifact(path, output_dir),
                    }
                )
            if (
                math.isfinite(corr)
                and math.isfinite(spearman)
                and max(abs(corr), abs(spearman))
                >= float(association_recipe["strong_threshold"])
            ):
                triggers.append(
                    {
                        "trigger": "strong_numeric_association",
                        "table_id": table_id,
                        "pair_id": frozen_pair.get("pair_id"),
                        "variable_ids": [
                            variables[left].get("variable_id"),
                            variables[right].get("variable_id"),
                        ],
                        "absolute_correlation": round(
                            max(abs(corr), abs(spearman)), 8
                        ),
                        "reason": (
                            "Frozen-pair baseline screening met the "
                            "approved association threshold."
                        ),
                    }
                )

        for sequence, trigger in enumerate(triggers, 1):
            trigger.setdefault("decision_sequence", sequence)
        stage_2_triggered_for_table = bool(triggers) and bool(
            requested_modules
        )
        if stage_2_triggered_for_table:
            for pending in pending_stage_2_candidates:
                pending["stage"] = 2
            candidates.extend(pending_stage_2_candidates)
            pending_stage_2_candidates = []
            for pending in pending_temporal_sensitivity:
                latest = pd.to_numeric(
                    pending["frame"][pending["time_col"]],
                    errors="coerce",
                ).max()
                reduced = pending["frame"][
                    pd.to_numeric(
                        pending["frame"][pending["time_col"]],
                        errors="coerce",
                    )
                    < latest
                ]
                reduced_slope, reduced_periods = _trend_slope(
                    reduced,
                    pending["time_col"],
                    pending["value_col"],
                )
                stable: bool | None = None
                if math.isfinite(reduced_slope):
                    stable = bool(
                        pending["full_value"] == 0
                        or reduced_slope == 0
                        or np.sign(pending["full_value"])
                        == np.sign(reduced_slope)
                    )
                sensitivity = {
                    "check": "exclude_latest_period",
                    "full_value": _python_value(pending["full_value"]),
                    "sensitivity_value": _python_value(reduced_slope),
                    "full_denominator": pending["full_denominator"],
                    "sensitivity_denominator": reduced_periods,
                    "stable_direction": stable,
                }
                finding_sensitivity[pending["finding_id"]] = sensitivity
                sensitivity_rows.append(
                    {"finding_id": pending["finding_id"], **sensitivity}
                )
            pending_temporal_sensitivity = []
            for (
                frozen_pair,
                left,
                right,
                pair,
                corr,
                spearman,
                association_finding_id,
            ) in association_screen:
                if not math.isfinite(corr) or not math.isfinite(spearman):
                    continue
                filtered_pair = pair.copy()
                for value_column in (left, right):
                    q1_pair = float(
                        filtered_pair[value_column].quantile(0.25)
                    )
                    q3_pair = float(
                        filtered_pair[value_column].quantile(0.75)
                    )
                    iqr_pair = q3_pair - q1_pair
                    if iqr_pair > 0:
                        filtered_pair = filtered_pair[
                            filtered_pair[value_column].between(
                                q1_pair - 1.5 * iqr_pair,
                                q3_pair + 1.5 * iqr_pair,
                            )
                        ]
                filtered_corr = (
                    float(filtered_pair[left].corr(filtered_pair[right]))
                    if len(filtered_pair) >= minimum_pairwise
                    and filtered_pair[left].nunique() > 1
                    and filtered_pair[right].nunique() > 1
                    else math.nan
                )
                outlier_stable = (
                    bool(
                        corr == 0
                        or filtered_corr == 0
                        or np.sign(corr) == np.sign(filtered_corr)
                    )
                    if math.isfinite(filtered_corr)
                    else None
                )
                latest_stability = None
                reduced_corr = math.nan
                reduced_pair = pd.DataFrame(columns=[left, right])
                if time_columns:
                    time_col = time_columns[0]
                    latest = pd.to_numeric(
                        frame[time_col], errors="coerce"
                    ).max()
                    reduced_pair = (
                        frame[
                            pd.to_numeric(
                                frame[time_col], errors="coerce"
                            )
                            < latest
                        ][[left, right]]
                        .apply(pd.to_numeric, errors="coerce")
                        .dropna()
                    )
                    if (
                        len(reduced_pair) >= minimum_pairwise
                        and reduced_pair[left].nunique() > 1
                        and reduced_pair[right].nunique() > 1
                    ):
                        reduced_corr = float(
                            reduced_pair[left].corr(reduced_pair[right])
                        )
                        latest_stability = bool(
                            corr == 0
                            or reduced_corr == 0
                            or np.sign(corr) == np.sign(reduced_corr)
                        )
                checks = [
                    value
                    for value in (outlier_stable, latest_stability)
                    if value is not None
                ]
                combined_stability = all(checks) if checks else None
                association_drilldown_rows.append(
                    {
                        "pair_id": frozen_pair.get("pair_id"),
                        "table_id": table_id,
                        "left_variable_id": variables[left].get("variable_id"),
                        "right_variable_id": variables[right].get("variable_id"),
                        "left_column": left,
                        "right_column": right,
                        "n": int(len(pair)),
                        "outlier_filtered_n": int(len(filtered_pair)),
                        "outlier_filtered_pearson": _python_value(
                            filtered_corr
                        ),
                        "latest_period_excluded_n": int(len(reduced_pair)),
                        "latest_period_excluded_pearson": _python_value(
                            reduced_corr
                        ),
                        "stable_without_iqr_outliers": outlier_stable,
                        "stable_without_latest_period": latest_stability,
                    }
                )
                finding_sensitivity[association_finding_id] = {
                    "check": "association_robustness",
                    "full_value": _python_value(corr),
                    "sensitivity_value": _python_value(
                        reduced_corr
                        if math.isfinite(reduced_corr)
                        else filtered_corr
                    ),
                    "full_denominator": int(len(pair)),
                    "sensitivity_denominator": int(
                        len(reduced_pair)
                        if not reduced_pair.empty
                        else len(filtered_pair)
                    ),
                    "stable_direction": combined_stability,
                    "latest_period_stable": latest_stability,
                    "iqr_outlier_stable": outlier_stable,
                }
                sensitivity_rows.append(
                    {
                        "finding_id": association_finding_id,
                        **finding_sensitivity[association_finding_id],
                    }
                )

        if group_columns and numeric_columns:
            for group_col in sorted(group_columns):
                for value_col in sorted(numeric_columns):
                    groups = (
                        frame[[group_col, value_col]]
                        .dropna()
                        .groupby(group_col, as_index=False)[value_col]
                        .median()
                        .sort_values(value_col)
                    )
                    if len(groups) < int(group_recipe["minimum_groups"]):
                        continue
                    overall_median = float(
                        pd.to_numeric(
                            frame[value_col], errors="coerce"
                        ).median()
                    )
                    groups = groups.assign(
                        gap_from_overall=groups[value_col] - overall_median,
                        rank=groups[value_col].rank(
                            method="min", ascending=False
                        ),
                    )
                    for item in groups.to_dict(orient="records"):
                        group_rows.append(
                            {
                                "table_id": table_id,
                                "group_variable_id": variables[group_col].get(
                                    "variable_id"
                                ),
                                "measure_variable_id": variables[
                                    value_col
                                ].get("variable_id"),
                                "group_column": group_col,
                                "measure_column": value_col,
                                "group_value": item[group_col],
                                "group_median": _python_value(
                                    item[value_col]
                                ),
                                "overall_median": _python_value(
                                    overall_median
                                ),
                                "gap_from_overall_median": _python_value(
                                    item["gap_from_overall"]
                                ),
                                "group_rank": int(item["rank"]),
                                "group_count": int(len(groups)),
                            }
                        )
                    gap = float(
                        groups[value_col].iloc[-1]
                        - groups[value_col].iloc[0]
                    )
                    finding_counter += 1
                    finding_id = _id("finding", finding_counter)
                    candidates.append(
                        {
                            "finding_id": finding_id,
                            "kind": "group_gap",
                            "table_id": table_id,
                            "source_ids": spec["source_ids"],
                            "variable_ids": [
                                variables[group_col].get("variable_id"),
                                variables[value_col].get("variable_id"),
                            ],
                            "columns": [group_col, value_col],
                            "metric": "group_median_max_min_gap",
                            "value": _python_value(gap),
                            "denominator": int(len(groups)),
                            "minimum_required_denominator": int(
                                group_recipe["minimum_groups"]
                            ),
                            "scope": {
                                "table": table_id,
                                "lowest_group": str(
                                    groups[group_col].iloc[0]
                                ),
                                "highest_group": str(
                                    groups[group_col].iloc[-1]
                                ),
                            },
                            "unit": variables[value_col].get("unit"),
                            "calculation": (
                                "maximum group median - minimum group median"
                            ),
                        }
                    )
                    maximum_groups = int(
                        group_recipe["maximum_groups_for_full_chart"]
                    )
                    if (
                        len(charts) < chart_limit
                        and len(groups) <= maximum_groups
                        and str(
                            variables[value_col].get("variable_id")
                        )
                        == primary_measure_id
                    ):
                        fig, ax = plt.subplots(
                            figsize=(8, max(4, len(groups) * 0.3))
                        )
                        sns.barplot(
                            data=groups,
                            x=value_col,
                            y=group_col,
                            color="#0F766E",
                            ax=ax,
                        )
                        ax.axvline(
                            overall_median,
                            color="#DC2626",
                            linestyle="--",
                        )
                        ax.set_title(f"Group comparison - {value_col}")
                        path = (
                            output_dir
                            / "charts"
                            / (
                                f"{len(charts)+1:02d}-group-"
                                f"{_safe_name(group_col)}-"
                                f"{_safe_name(value_col)}.png"
                            )
                        )
                        _save_plot(fig, path)
                        charts.append(
                            {
                                "chart_id": f"chart-{len(charts)+1:02d}",
                                "stage": 1,
                                "kind": "group_comparison",
                                "title": (
                                    f"Group comparison - {value_col}"
                                ),
                                "table_id": table_id,
                                "variable_ids": candidates[-1][
                                    "variable_ids"
                                ],
                                "evidence_ids": [],
                                "finding_ids": [finding_id],
                                "context_chart": False,
                                "requested_module": "group_comparison",
                                "question_relevance": "core",
                                "artifact": _artifact(path, output_dir),
                            }
                        )
                    if (
                        time_columns
                        and len(charts) < chart_limit
                        and int(
                            recipe["visual_selection"].get(
                                "maximum_group_time_charts", 0
                            )
                        )
                        > 0
                        and str(
                            variables[value_col].get("variable_id")
                        )
                        == primary_measure_id
                    ):
                        heat_time = sorted(time_columns)[0]
                        pivot = frame.pivot_table(
                            index=group_col,
                            columns=heat_time,
                            values=value_col,
                            aggfunc="median",
                        )
                        if (
                            1 < pivot.shape[0] <= maximum_groups
                            and 1 < pivot.shape[1] <= 30
                        ):
                            fig, ax = plt.subplots(
                                figsize=(
                                    max(7, pivot.shape[1] * 0.55),
                                    max(4, pivot.shape[0] * 0.35),
                                )
                            )
                            sns.heatmap(
                                pivot,
                                cmap="vlag",
                                center=float(
                                    pd.to_numeric(
                                        frame[value_col],
                                        errors="coerce",
                                    ).median()
                                ),
                                ax=ax,
                            )
                            ax.set_title(
                                f"Group × period - {value_col}"
                            )
                            path = (
                                output_dir
                                / "charts"
                                / (
                                    f"{len(charts)+1:02d}-group-time-"
                                    f"{_safe_name(group_col)}-"
                                    f"{_safe_name(value_col)}.png"
                                )
                            )
                            _save_plot(fig, path)
                            charts.append(
                                {
                                    "chart_id": (
                                        f"chart-{len(charts)+1:02d}"
                                    ),
                                    "stage": 1,
                                    "kind": "group_time_heatmap",
                                    "title": (
                                        f"Group × period - {value_col}"
                                    ),
                                    "table_id": table_id,
                                    "variable_ids": [
                                        variables[group_col].get(
                                            "variable_id"
                                        ),
                                        variables[heat_time].get(
                                            "variable_id"
                                        ),
                                        variables[value_col].get(
                                            "variable_id"
                                        ),
                                    ],
                                    "evidence_ids": [],
                                    "finding_ids": [finding_id],
                                    "context_chart": False,
                                    "requested_module": "group_comparison",
                                    "question_relevance": "supporting",
                                    "artifact": _artifact(
                                        path, output_dir
                                    ),
                                }
                            )

        spatial_status = "not_requested"
        spatial_reasons: list[str] = []
        if "spatial_pattern" in requested_modules:
            geography_reference = analysis_focus.get("geography_axis", {})
            label_reference = analysis_focus.get("geography_label", {})
            primary_reference = analysis_focus.get("primary_measure", {})
            geography_col = by_variable_id.get(
                str(geography_reference.get("variable_id"))
            )
            label_col = by_variable_id.get(
                str(label_reference.get("variable_id"))
            )
            primary_col = by_variable_id.get(
                str(primary_reference.get("variable_id"))
            )
            if geography_col is None or primary_col is None:
                spatial_status = "qualified"
                spatial_reasons.append("SPATIAL_BASELINE_COLUMN_NOT_FOUND")
            else:
                display_col = label_col or geography_col
                mapping_ok = True
                if label_col:
                    mapping = frame[
                        [geography_col, label_col]
                    ].dropna().drop_duplicates()
                    mapping_ok = bool(
                        (
                            mapping.groupby(geography_col)[label_col].nunique()
                            <= 1
                        ).all()
                        and (
                            mapping.groupby(label_col)[geography_col].nunique()
                            <= 1
                        ).all()
                    )
                if not mapping_ok:
                    spatial_status = "qualified"
                    spatial_reasons.append(
                        "GEOGRAPHY_ID_LABEL_NOT_ONE_TO_ONE"
                    )
                else:
                    work_columns = [geography_col, display_col, primary_col]
                    if time_columns:
                        work_columns.append(time_columns[0])
                    work = frame[list(dict.fromkeys(work_columns))].copy()
                    work[primary_col] = pd.to_numeric(
                        work[primary_col], errors="coerce"
                    )
                    geography_means = (
                        work.dropna(
                            subset=[geography_col, display_col, primary_col]
                        )
                        .groupby(
                            [geography_col, display_col],
                            as_index=False,
                        )[primary_col]
                        .mean()
                        .sort_values(primary_col, ascending=False)
                    )
                    geography_means["rank"] = geography_means[
                        primary_col
                    ].rank(method="min", ascending=False)
                    rank_by_id = {
                        row[geography_col]: int(row["rank"])
                        for row in geography_means.to_dict(orient="records")
                    }
                    if time_columns:
                        period_col = time_columns[0]
                        period_rows = (
                            work.dropna(
                                subset=[
                                    geography_col,
                                    display_col,
                                    period_col,
                                    primary_col,
                                ]
                            )
                            .groupby(
                                [geography_col, display_col, period_col],
                                as_index=False,
                            )[primary_col]
                            .mean()
                        )
                    else:
                        period_col = None
                        period_rows = geography_means.copy()
                        period_rows["__period"] = None
                    for row in period_rows.to_dict(orient="records"):
                        spatial_rows.append(
                            {
                                "table_id": table_id,
                                "geography_variable_id": geography_reference.get(
                                    "variable_id"
                                ),
                                "geography_label_variable_id": (
                                    label_reference.get("variable_id")
                                ),
                                "primary_measure_variable_id": (
                                    primary_reference.get("variable_id")
                                ),
                                "geography_id": _python_value(
                                    row[geography_col]
                                ),
                                "geography_display": _python_value(
                                    row[display_col]
                                ),
                                "period": _python_value(
                                    row.get(period_col)
                                    if period_col
                                    else None
                                ),
                                "primary_mean": _python_value(
                                    row[primary_col]
                                ),
                                "geography_rank": rank_by_id.get(
                                    row[geography_col]
                                ),
                                "geometry_used": False,
                            }
                        )
                    spatial_status = (
                        "executed" if spatial_rows else "qualified"
                    )
                    if not spatial_rows:
                        spatial_reasons.append(
                            "INSUFFICIENT_SPATIAL_BASELINE_OBSERVATIONS"
                        )
                    if (
                        not geography_means.empty
                        and len(charts) < chart_limit
                    ):
                        fig, ax = plt.subplots(
                            figsize=(
                                8,
                                max(4, len(geography_means) * 0.3),
                            )
                        )
                        sns.barplot(
                            data=geography_means,
                            x=primary_col,
                            y=display_col,
                            color="#7C3AED",
                            ax=ax,
                        )
                        ax.set_title(
                            f"Geography baseline - {primary_col}"
                        )
                        path = (
                            output_dir
                            / "charts"
                            / (
                                f"{len(charts)+1:02d}-spatial-rank-"
                                f"{_safe_name(primary_col)}.png"
                            )
                        )
                        _save_plot(fig, path)
                        charts.append(
                            {
                                "chart_id": f"chart-{len(charts)+1:02d}",
                                "stage": 1,
                                "kind": "geography_ranked_bar",
                                "title": (
                                    f"Geography baseline - {primary_col}"
                                ),
                                "table_id": table_id,
                                "variable_ids": [
                                    geography_reference.get("variable_id"),
                                    label_reference.get("variable_id"),
                                    primary_reference.get("variable_id"),
                                ],
                                "evidence_ids": [],
                                "context_chart": True,
                                "geometry_used": False,
                                "requested_module": "spatial_pattern",
                                "question_relevance": "core",
                                "artifact": _artifact(path, output_dir),
                            }
                        )

        core_status = {
            "data_quality": ("executed", []),
            "distribution": (
                "executed" if numeric_rows else "qualified",
                [] if numeric_rows else ["NO_ELIGIBLE_NUMERIC_MEASURE"],
            ),
            "temporal_pattern": (
                "executed" if temporal_rows else "qualified",
                [] if temporal_rows else ["INSUFFICIENT_TEMPORAL_BASELINE"],
            ),
            "group_comparison": (
                "executed" if group_rows else "qualified",
                [] if group_rows else ["INSUFFICIENT_GROUP_BASELINE"],
            ),
            "association": (
                "executed" if association_rows else "qualified",
                [] if association_rows else ["INSUFFICIENT_ASSOCIATION_BASELINE"],
            ),
            "spatial_pattern": (spatial_status, spatial_reasons),
        }
        for module in task["inputs"]["staged_eda_policy"]["core_modules"]:
            status, reasons = core_status.get(module, ("qualified", []))
            module_execution_records.append(
                {
                    "module": module,
                    "pass": "core",
                    "status": status,
                    "reasons": reasons,
                    "execution_sequence": len(module_execution_records) + 1,
                }
            )
        if stage_2_triggered_for_table:
            first_stage_2_sequence = len(triggers) + 1
            stage_2_counts_by_module = {
                "association": len(association_drilldown_rows),
                "temporal_pattern": len(finding_sensitivity),
                "group_comparison": 0,
                "spatial_pattern": 0,
            }
            for offset, module in enumerate(
                task["inputs"]["staged_eda_policy"]["stage_2_modules"]
            ):
                count = stage_2_counts_by_module.get(module, 0)
                module_execution_records.append(
                    {
                        "module": module,
                        "pass": "stage_2_drilldown",
                        "status": "executed" if count else "qualified",
                        "reasons": (
                            []
                            if count
                            else ["NO_ELIGIBLE_TRIGGERED_DRILLDOWN"]
                        ),
                        "output_count": count,
                        "execution_sequence": (
                            first_stage_2_sequence + offset
                        ),
                    }
                )

    for candidate in candidates:
        candidate.setdefault("stage", 1)
        _enrich_question_fields(candidate, analysis_focus)

    evidence: list[dict[str, Any]] = []
    finding_validation_records: list[dict[str, Any]] = []
    status_counts: defaultdict[str, int] = defaultdict(int)
    validation_recipe = recipe["finding_validation"]
    minimum_default_denominator = int(
        validation_recipe["minimum_default_denominator"]
    )
    declared_pair_rows = [
        row for row in sensitivity_rows if row.get("pair_id")
    ]
    primary_measure_id = str(
        analysis_focus.get("primary_measure", {}).get("variable_id") or ""
    )
    for candidate in candidates:
        reasons: list[str] = list(
            candidate.get("prevalidation_reasons") or []
        )
        denominator = int(candidate.get("denominator") or 0)
        if denominator > 0:
            coverage_check = {
                "status": "applied",
                "observed_count": denominator,
                "reason": None,
            }
        else:
            coverage_check = {
                "status": "failed",
                "observed_count": denominator,
                "reason": "NO_OBSERVED_COVERAGE",
            }
            reasons.append("NO_OBSERVED_COVERAGE")
        minimum_required_denominator = int(
            candidate.get("minimum_required_denominator")
            or minimum_default_denominator
        )
        if denominator >= minimum_required_denominator:
            denominator_check = {
                "status": "applied",
                "minimum_required": minimum_required_denominator,
                "observed": denominator,
                "reason": None,
            }
        elif denominator > 0:
            denominator_check = {
                "status": "insufficient_data",
                "minimum_required": minimum_required_denominator,
                "observed": denominator,
                "reason": "SMALL_DENOMINATOR",
            }
            reasons.append("SMALL_DENOMINATOR")
        else:
            denominator_check = {
                "status": "failed",
                "minimum_required": minimum_required_denominator,
                "observed": denominator,
                "reason": "EMPTY_DENOMINATOR",
            }
            reasons.append("EMPTY_DENOMINATOR")

        sensitivity = finding_sensitivity.get(candidate["finding_id"])
        if sensitivity is None:
            candidate_sensitivity = {
                "status": "not_applicable",
                "reason": (
                    "NO_MEANINGFUL_CANDIDATE_LEVEL_PERTURBATION_DECLARED"
                ),
            }
        elif sensitivity.get("stable_direction") is False:
            candidate_sensitivity = {
                "status": "failed",
                "reason": "DIRECTION_REVERSED_UNDER_CANDIDATE_SENSITIVITY",
            }
            reasons.append(
                "DIRECTION_REVERSED_UNDER_CANDIDATE_SENSITIVITY"
            )
        elif sensitivity.get("stable_direction") is None:
            candidate_sensitivity = {
                "status": "insufficient_data",
                "reason": "INSUFFICIENT_CANDIDATE_SENSITIVITY_DATA",
            }
            reasons.append("INSUFFICIENT_CANDIDATE_SENSITIVITY_DATA")
        else:
            candidate_sensitivity = {
                "status": "applied",
                "reason": None,
            }

        relevant_definition_rows = (
            [
                row
                for row in declared_pair_rows
                if row.get("primary_variable_id") == primary_measure_id
            ]
            if primary_measure_id
            and primary_measure_id in candidate.get("variable_ids", [])
            else []
        )
        if not (
            primary_measure_id
            and primary_measure_id in candidate.get("variable_ids", [])
        ):
            definition_sensitivity = {
                "status": "not_applicable",
                "pair_ids": [],
                "reason": "FINDING_DOES_NOT_USE_PRIMARY_MEASURE",
            }
        elif not relevant_definition_rows:
            definition_sensitivity = {
                "status": "insufficient_data",
                "pair_ids": [],
                "reason": "DECLARED_DEFINITION_SENSITIVITY_NOT_AVAILABLE",
            }
            reasons.append("DECLARED_DEFINITION_SENSITIVITY_NOT_AVAILABLE")
        else:
            failed = False
            insufficient = False
            for row in relevant_definition_rows:
                if row.get("validation_status") != "validated":
                    insufficient = True
                checks = str(row.get("checks") or "").split("|")
                if (
                    "direction_agreement" in checks
                    and isinstance(row.get("direction_agreement"), (int, float))
                    and float(row["direction_agreement"])
                    < float(
                        validation_recipe[
                            "definition_sensitivity_direction_agreement_minimum"
                        ]
                    )
                ):
                    failed = True
                if (
                    "group_rank_stability" in checks
                    and isinstance(
                        row.get("group_rank_stability"), (int, float)
                    )
                    and float(row["group_rank_stability"])
                    < float(
                        validation_recipe[
                            "definition_sensitivity_rank_correlation_minimum"
                        ]
                    )
                ):
                    failed = True
                if (
                    "threshold_classification_agreement" in checks
                    and isinstance(
                        row.get("threshold_classification_agreement"),
                        (int, float),
                    )
                    and float(row["threshold_classification_agreement"])
                    < float(
                        validation_recipe[
                            "definition_sensitivity_classification_agreement_minimum"
                        ]
                    )
                ):
                    failed = True
            if failed:
                definition_sensitivity = {
                    "status": "failed",
                    "pair_ids": [
                        row.get("pair_id")
                        for row in relevant_definition_rows
                    ],
                    "reason": "DECLARED_DEFINITION_DIRECTION_OR_CLASSIFICATION_FAILED",
                }
                reasons.append(
                    "DECLARED_DEFINITION_DIRECTION_OR_CLASSIFICATION_FAILED"
                )
            elif insufficient:
                definition_sensitivity = {
                    "status": "insufficient_data",
                    "pair_ids": [
                        row.get("pair_id")
                        for row in relevant_definition_rows
                    ],
                    "reason": "INSUFFICIENT_DECLARED_DEFINITION_SENSITIVITY",
                }
                reasons.append(
                    "INSUFFICIENT_DECLARED_DEFINITION_SENSITIVITY"
                )
            else:
                definition_sensitivity = {
                    "status": "applied",
                    "pair_ids": [
                        row.get("pair_id")
                        for row in relevant_definition_rows
                    ],
                    "reason": None,
                }
        check_statuses = {
            coverage_check["status"],
            denominator_check["status"],
            candidate_sensitivity["status"],
            definition_sensitivity["status"],
        }
        hard_failure = (
            coverage_check["status"] == "failed"
            or denominator_check["status"] == "failed"
        )
        sensitivity_limitation = (
            candidate_sensitivity["status"] == "failed"
            or definition_sensitivity["status"] == "failed"
        )
        if hard_failure:
            status = "rejected"
        elif (
            "insufficient_data" in check_statuses
            or sensitivity_limitation
            or reasons
        ):
            status = "qualified"
        else:
            status = "validated"
        if candidate["kind"] == "anomaly_screen":
            status = "qualified" if status != "rejected" else status
            reasons.append("REVIEW_CANDIDATES_NOT_CONFIRMED_ERRORS")
        validation_record = {
            "finding_id": candidate["finding_id"],
            "coverage_check": coverage_check,
            "denominator_check": denominator_check,
            "candidate_sensitivity": candidate_sensitivity,
            "declared_definition_sensitivity": definition_sensitivity,
            "final_evidence_status": status,
            "qualification_or_rejection_reasons": list(
                dict.fromkeys(reasons)
            ),
        }
        finding_validation_records.append(validation_record)
        evidence_counter += 1
        record = {
            **candidate,
            "evidence_id": _id("evidence", evidence_counter),
            "validation_status": status,
            "qualification_reasons": validation_record[
                "qualification_or_rejection_reasons"
            ],
            "claim_boundary": candidate.get("claim_boundary")
            or (
                "observed non-causal pattern"
                if candidate["kind"]
                in {
                    "association",
                    "temporal_pattern",
                    "temporal_change",
                    "recent_window_shift",
                    "derived_group_comparison",
                }
                else "descriptive review candidate"
            ),
            "sensitivity": sensitivity,
            "stage_3_validation": validation_record,
            "summary": _finding_summary(candidate),
        }
        record["insight_score"] = _insight_score(
            record,
            recipe["insight_ranking"]["status_weight"],
        )
        evidence.append(record)
        status_counts[status] += 1
        for chart in charts:
            if candidate["finding_id"] in chart.get("finding_ids", []):
                chart["evidence_ids"].append(record["evidence_id"])

    if (
        task["inputs"]["staged_eda_policy"][
            "stage_3_applies_to_each_candidate_finding"
        ]
        and len(candidates) != len(finding_validation_records)
    ):
        raise ContractError("STAGE3_VALIDATION_COUNT_MISMATCH")

    reportable_evidence = _select_diverse_evidence(
        evidence,
        recipe["insight_ranking"],
        list(analysis_focus.get("requested_modules", [])),
    )
    maximum_insights = int(
        recipe["insight_ranking"]["maximum_report_insights"]
    )
    insight_ranking = {
        "schema_version": "insight_ranking.v1",
        "selection_policy": {
            "maximum_report_insights": maximum_insights,
            "selection_rule": recipe["insight_ranking"].get(
                "selection_rule"
            ),
            "required_evidence_classes": recipe[
                "insight_ranking"
            ].get("required_evidence_classes", []),
            "required_requested_module_coverage": recipe[
                "insight_ranking"
            ].get("required_requested_module_coverage"),
            "maximum_per_requested_module": recipe[
                "insight_ranking"
            ].get("maximum_per_requested_module"),
            "maximum_per_kind": recipe["insight_ranking"].get(
                "maximum_per_kind"
            ),
            "excluded_statuses": recipe["insight_ranking"].get(
                "exclude_statuses", []
            ),
            "domain_interpretation_used": False,
        },
        "insights": [
            {
                "rank": rank,
                "evidence_id": record["evidence_id"],
                "finding_id": record["finding_id"],
                "insight_score": record["insight_score"],
                "validation_status": record["validation_status"],
                "summary": record["summary"],
                "evidence_class": record.get("evidence_class"),
                "requested_module": record.get("requested_module"),
                "question_relevance": record.get(
                    "question_relevance"
                ),
                "qualification_reasons": record[
                    "qualification_reasons"
                ],
            }
            for rank, record in enumerate(
                reportable_evidence[:maximum_insights], 1
            )
        ],
    }

    additional_requests: list[dict[str, Any]] = []
    request_keys: set[tuple[str, str, str, str]] = set()

    def request_user_data(
        reason_code: str,
        source_ids: list[str],
        variable_ids: list[str],
        requested_scope: str,
        message: str,
    ) -> None:
        key = (
            reason_code,
            "|".join(sorted(source_ids)),
            "|".join(sorted(variable_ids)),
            requested_scope,
        )
        if key in request_keys:
            return
        request_keys.add(key)
        additional_requests.append(
            {
                "request_id": f"data-request-{len(additional_requests) + 1:03d}",
                "reason_code": reason_code,
                "source_ids": sorted(source_ids),
                "variable_ids": sorted(variable_ids),
                "requested_scope": requested_scope,
                "message": message,
                "delivery_mode": "USER_PROVIDED_LOCAL_FILE",
                "network_access_permitted": False,
            }
        )

    for qualification in declared_qualifications:
        request_user_data(
            str(qualification.get("reason_code")),
            sorted(
                {
                    source_id
                    for spec in specs
                    for source_id in spec.get("source_ids", [])
                }
            ),
            [
                str(value)
                for value in qualification.get("variable_ids", [])
                if value
            ],
            (
                f"declared rule/pair={qualification.get('rule_id') or qualification.get('pair_id')}; "
                "provide the missing periods, groups, coverage flag, or compatible variables"
            ),
            (
                "선언된 파생 또는 민감도 검사를 완전하게 수행할 수 있도록 "
                "필요 기간·집단·coverage 변수와 로컬 파일 형식을 제공해 주세요."
            ),
        )

    for row in quality_rows:
        source_ids = [
            value for value in str(row.get("source_ids", "")).split("|") if value
        ]
        coverage = row.get("join_coverage")
        if isinstance(coverage, (int, float)) and coverage < 0.8:
            request_user_data(
                "LOW_JOIN_COVERAGE",
                source_ids,
                [],
                f"table={row.get('table_id')}; join_coverage={coverage:.4f}",
                (
                    "결합 누락을 줄이려면 동일한 키 정의와 범위를 가진 보완 "
                    "로컬 파일 또는 키 정의를 사용자가 제공해 주세요."
                ),
            )
    candidate_by_id = {
        item["finding_id"]: item
        for item in candidates
        if isinstance(item.get("finding_id"), str)
    }
    for validation_record in finding_validation_records:
        candidate = candidate_by_id.get(
            validation_record["finding_id"], {}
        )
        for check_name in (
            "coverage_check",
            "denominator_check",
            "candidate_sensitivity",
            "declared_definition_sensitivity",
        ):
            check = validation_record[check_name]
            if check.get("status") != "insufficient_data":
                continue
            request_user_data(
                f"INSUFFICIENT_{check_name.upper()}",
                list(candidate.get("source_ids", [])),
                list(candidate.get("variable_ids", [])),
                (
                    f"finding_id={validation_record['finding_id']};"
                    f"check={check_name}"
                ),
                (
                    "해당 finding의 coverage 또는 민감도 검증을 완료할 수 "
                    "있는 동일 정의의 추가 기간·집단·변수가 포함된 로컬 "
                    "파일을 제공해 주세요."
                ),
            )
    for row in sensitivity_rows:
        if row.get("stable_direction") is not None:
            continue
        candidate = candidate_by_id.get(row.get("finding_id"), {})
        check = str(row.get("check") or "")
        request_user_data(
            (
                "INSUFFICIENT_PERIODS_FOR_SENSITIVITY"
                if check == "exclude_latest_period"
                else "INSUFFICIENT_DATA_FOR_SENSITIVITY"
            ),
            list(candidate.get("source_ids", [])),
            list(candidate.get("variable_ids", [])),
            (
                f"finding_id={row.get('finding_id')}; "
                f"available_periods={row.get('full_denominator')}"
            ),
            (
                "해당 finding의 기간 또는 이상치 민감도 검증을 위해 같은 "
                "정의의 추가 관측이 포함된 로컬 데이터를 제공해 주세요."
            ),
        )
    if not candidates:
        request_user_data(
            "NO_ELIGIBLE_FINDINGS",
            sorted(
                {
                    source_id
                    for spec in specs
                    for source_id in spec.get("source_ids", [])
                }
            ),
            [],
            "approved analysis produced no eligible candidate finding",
            (
                "승인된 분석에 필요한 수치 변수, 집단 또는 기간을 포함한 "
                "로컬 데이터와 변수 정의를 사용자가 제공해 주세요."
            ),
        )

    quality_path = output_dir / "analysis_tables" / "data_quality.csv"
    numeric_path = output_dir / "analysis_tables" / "numeric_summary.csv"
    derived_path = output_dir / "analysis_tables" / "derived_variables.csv"
    temporal_path = output_dir / "analysis_tables" / "temporal_summary.csv"
    group_path = output_dir / "analysis_tables" / "group_comparison.csv"
    spatial_path = output_dir / "analysis_tables" / "spatial_summary.csv"
    association_path = (
        output_dir / "analysis_tables" / "association_summary.csv"
    )
    association_drilldown_path = (
        output_dir / "analysis_tables" / "association_drilldown.csv"
    )
    selection_path = (
        output_dir / "analysis_tables" / "analysis_scope_selection.csv"
    )
    sensitivity_path = output_dir / "analysis_tables" / "sensitivity_summary.csv"
    _write_csv(
        quality_path,
        quality_rows,
        [
            "table_id",
            "source_ids",
            "rows",
            "columns",
            "missing_cells",
            "missing_rate",
            "duplicate_rows",
            "join_coverage",
        ],
    )
    _write_csv(
        numeric_path,
        numeric_rows,
        [
            "table_id",
            "variable_id",
            "column",
            "n",
            "missing",
            "zero_rate",
            "negative_rate",
            "mean",
            "median",
            "std",
            "coefficient_of_variation",
            "skewness",
            "min",
            "q1",
            "q3",
            "max",
            "iqr_outlier_count",
            "mad_outlier_count",
        ],
    )
    _write_csv(
        derived_path,
        derived_rows,
        [
            "derived_id",
            "table_id",
            "source_ids",
            "source_variable_id",
            "derived_name",
            "value",
            "unit",
            "formula",
            "denominator",
            "eligibility_basis",
            "rule_id",
            "operation",
            "group_variable_id",
            "time_variable_id",
            "group_value",
            "threshold",
            "minimum_observations",
            "recent_window_size",
            "previous_window_size",
            "missing_policy",
            "partial_period_policy",
            "validation_status",
            "qualification_reason",
        ],
    )
    _write_csv(
        temporal_path,
        temporal_rows,
        [
            "table_id",
            "variable_id",
            "column",
            "periods",
            "first_period",
            "latest_period",
            "first_value",
            "latest_value",
            "absolute_change",
            "percent_change",
            "change_type",
            "recent_window_change",
            "period_difference_std",
        ],
    )
    _write_csv(
        group_path,
        group_rows,
        [
            "table_id",
            "group_variable_id",
            "measure_variable_id",
            "group_column",
            "measure_column",
            "group_value",
            "group_median",
            "overall_median",
            "gap_from_overall_median",
            "group_rank",
            "group_count",
        ],
    )
    _write_csv(
        spatial_path,
        spatial_rows,
        [
            "table_id",
            "geography_variable_id",
            "geography_label_variable_id",
            "primary_measure_variable_id",
            "geography_id",
            "geography_display",
            "period",
            "primary_mean",
            "geography_rank",
            "geometry_used",
        ],
    )
    _write_csv(
        association_path,
        association_rows,
        [
            "pair_id",
            "table_id",
            "left_variable_id",
            "right_variable_id",
            "left_column",
            "right_column",
            "n",
            "pearson",
            "spearman",
        ],
    )
    _write_csv(
        association_drilldown_path,
        association_drilldown_rows,
        [
            "pair_id",
            "table_id",
            "left_variable_id",
            "right_variable_id",
            "left_column",
            "right_column",
            "n",
            "outlier_filtered_n",
            "outlier_filtered_pearson",
            "latest_period_excluded_n",
            "latest_period_excluded_pearson",
            "stable_without_iqr_outliers",
            "stable_without_latest_period",
        ],
    )
    _write_csv(
        selection_path,
        selection_rows,
        [
            "table_id",
            "eligible_measure_count",
            "selected_measure_count",
            "selected_columns",
            "excluded_by_cost_bound",
            "selection_rule",
        ],
    )
    _write_csv(
        sensitivity_path,
        sensitivity_rows,
        [
            "finding_id",
            "check",
            "full_value",
            "sensitivity_value",
            "full_denominator",
            "sensitivity_denominator",
            "stable_direction",
            "latest_period_stable",
            "iqr_outlier_stable",
            "pair_id",
            "table_id",
            "primary_variable_id",
            "alternative_variable_id",
            "checks",
            "pairwise_complete_count",
            "pairwise_complete_coverage",
            "direction_agreement",
            "pearson",
            "spearman",
            "group_rank_stability",
            "threshold",
            "threshold_classification_agreement",
            "minimum_pairwise_observations",
            "validation_status",
            "qualification_reason",
        ],
    )

    candidate_path = output_dir / "candidate_findings.json"
    evidence_path = output_dir / "evidence_records.json"
    validation_path = output_dir / "validation_summary.json"
    finding_validation_path = (
        output_dir / "finding_validation_records.json"
    )
    insight_path = output_dir / "insight_ranking.json"
    data_request_path = output_dir / "additional_data_requests.json"
    chart_path = output_dir / "chart_manifest.json"
    integrity_path = output_dir / "execution_integrity.json"
    _write_json(candidate_path, {"schema_version": "candidate_findings.v1", "findings": candidates})
    _write_json(evidence_path, {"schema_version": "analysis_evidence.v1", "evidence": evidence})
    _write_json(
        finding_validation_path,
        {
            "schema_version": "finding_validation_records.v1",
            "records": finding_validation_records,
        },
    )
    validation = {
        "schema_version": "validation_summary.v1",
        "counts": {
            "candidate": len(candidates),
            "validated": status_counts["validated"],
            "qualified": status_counts["qualified"],
            "rejected": status_counts["rejected"],
        },
        "checks": sorted(
            {
                row["check"]
                for row in sensitivity_rows
                if isinstance(row.get("check"), str)
            }
        ),
        "report_eligible_statuses": ["validated", "qualified"],
    }
    _write_json(validation_path, validation)
    _write_json(insight_path, insight_ranking)
    _write_json(
        data_request_path,
        {
            "schema_version": "additional_data_requests.v1",
            "status": "REQUESTED" if additional_requests else "NOT_REQUIRED",
            "policy": "USER_PROVIDED_LOCAL_ONLY",
            "agent_network_access": False,
            "requests": additional_requests,
        },
    )
    _write_json(chart_path, {"schema_version": "chart_manifest.v1", "charts": charts})
    enabled_stage_2_modules = requested_modules & set(
        task["inputs"]["staged_eda_policy"]["stage_2_modules"]
    )
    stage_2_triggered = bool(triggers) and bool(enabled_stage_2_modules)
    executed_stages = [1, 3]
    if stage_2_triggered:
        executed_stages.insert(1, 2)
    integrity_status = (
        "PARTIAL_EXECUTION"
        if not candidates or status_counts["rejected"] == len(candidates)
        else "COMPLETE"
    )
    integrity = {
        "schema_version": "execution_integrity.v1",
        "status": integrity_status,
        "approved_modules": sorted(
            {
                *[
                    str(step.get("module"))
                    for step in task["inputs"]["analysis_steps"]
                    if isinstance(step, dict)
                ],
                *task["inputs"]["staged_eda_policy"]["core_modules"],
                *enabled_stage_2_modules,
            }
        ),
        "executed_stages": executed_stages,
        "stage_2_triggered": stage_2_triggered,
        "stage_2_trigger_decided_before_execution": (
            not stage_2_triggered
            or all(
                int(record.get("execution_sequence") or 0)
                > max(
                    int(trigger.get("decision_sequence") or 0)
                    for trigger in triggers
                )
                for record in module_execution_records
                if record.get("pass") == "stage_2_drilldown"
                and record.get("status") == "executed"
            )
        ),
        "stage_2_triggers": sorted(
            triggers,
            key=lambda item: (
                str(item.get("trigger")),
                str(item.get("table_id")),
                str(item.get("variable_id", item.get("variable_ids", ""))),
            ),
        ),
        "stage_2_output_counts": {
            "candidates": sum(
                1 for candidate in candidates if candidate.get("stage") == 2
            ),
            "charts": sum(
                1 for chart in charts if chart.get("stage") == 2
            ),
            "detailed_association_rows": len(
                association_drilldown_rows
            ),
            "evidence": sum(
                1 for record in evidence if record.get("stage") == 2
            ),
        },
        "module_execution_records": module_execution_records,
        "executed_association_pair_ids": list(
            dict.fromkeys(row["pair_id"] for row in association_rows)
        ),
        "candidate_finding_count": len(candidates),
        "stage_3_validation_record_count": len(
            finding_validation_records
        ),
        "stage_3_validation_invariant": (
            len(candidates) == len(finding_validation_records)
        ),
        "frozen_policy_alignment": (
            list(dict.fromkeys(row["pair_id"] for row in association_rows))
            == [
                pair.get("pair_id")
                for pair in recipe.get("association_pairs", [])
            ]
            and set(requested_modules)
            <= {
                record["module"]
                for record in module_execution_records
                if record["pass"] == "core"
            }
            and all(
                chart.get("stage") in executed_stages for chart in charts
            )
        ),
        "excluded_unapproved_variables": sorted(
            str(variable.get("variable_id"))
            for variable in execution["frozen_variable_inventory"]["variables"]
            if isinstance(variable, dict)
            and variable.get("status") not in APPROVED_STATUSES
        ),
        "claim_boundary": "descriptive-comparative-exploratory-only",
        "generic_analysis_recipe_schema": recipe["schema_version"],
        "generic_analysis_recipe_sha256": hashlib.sha256(
            _json_bytes(recipe)
        ).hexdigest(),
        "data_access_policy": "USER_PROVIDED_LOCAL_ONLY",
        "network_access_attempted": False,
        "additional_data_request_count": len(additional_requests),
    }
    _write_json(integrity_path, integrity)

    artifacts = {
        "data_quality": _artifact(quality_path, output_dir),
        "numeric_summary": _artifact(numeric_path, output_dir),
        "derived_variables": _artifact(derived_path, output_dir),
        "temporal_summary": _artifact(temporal_path, output_dir),
        "group_comparison": _artifact(group_path, output_dir),
        "spatial_summary": _artifact(spatial_path, output_dir),
        "association_summary": _artifact(association_path, output_dir),
        "association_drilldown": _artifact(
            association_drilldown_path, output_dir
        ),
        "analysis_scope_selection": _artifact(
            selection_path, output_dir
        ),
        "sensitivity_summary": _artifact(sensitivity_path, output_dir),
        "candidate_findings": _artifact(candidate_path, output_dir),
        "evidence_records": _artifact(evidence_path, output_dir),
        "validation_summary": _artifact(validation_path, output_dir),
        "finding_validation_records": _artifact(
            finding_validation_path, output_dir
        ),
        "insight_ranking": _artifact(insight_path, output_dir),
        "additional_data_requests": _artifact(data_request_path, output_dir),
        "chart_manifest": _artifact(chart_path, output_dir),
        "execution_integrity": _artifact(integrity_path, output_dir),
    }
    eda_manifest = {
        "schema_version": EDA_SCHEMA,
        "status": integrity_status,
        "execution_id": execution["execution_id"],
        "blueprint_id": execution["blueprint_id"],
        "execution_request_sha256": _sha256(execution_path),
        "preparation_manifest_sha256": _sha256(manifest_path),
        "tables": frames_for_dashboard,
        "executed_stages": executed_stages,
        "stage_2_triggers": integrity["stage_2_triggers"],
        "module_execution_records": module_execution_records,
        "artifacts": artifacts,
        "charts": [chart["artifact"] for chart in charts],
    }
    manifest_output = output_dir / "eda_manifest.json"
    _write_json(manifest_output, eda_manifest)
    return eda_manifest


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Run deterministic staged exploratory analysis."
    )
    parser.add_argument("execution", type=Path)
    parser.add_argument("preparation_manifest", type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    return parser


def main(argv: Iterable[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        result = run(
            args.execution.resolve(),
            args.preparation_manifest.resolve(),
            args.output_dir.resolve(),
        )
        sys.stdout.write(
            json.dumps(
                {
                    "valid": True,
                    "status": result["status"],
                    "manifest": str(
                        args.output_dir.resolve() / "eda_manifest.json"
                    ),
                },
                ensure_ascii=False,
                sort_keys=True,
            )
            + "\n"
        )
        return 0
    except ContractError as exc:
        sys.stderr.write(
            json.dumps(
                {"valid": False, "errors": [str(exc)]},
                ensure_ascii=False,
                sort_keys=True,
            )
            + "\n"
        )
        return 2
    except Exception as exc:
        sys.stderr.write(
            json.dumps(
                {"valid": False, "errors": [f"{type(exc).__name__}:{exc}"]},
                ensure_ascii=False,
                sort_keys=True,
            )
            + "\n"
        )
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
