---
name: run-exploratory-analysis
description: Run deterministic, traceable staged exploratory analysis only from user-provided local data in an approved analysis_execution_request.v1 and completed preparation_manifest.v1. Use when prepared CSV tables must be profiled, visualized, checked through conditional second-pass exploration and mandatory sensitivity validation, and converted into evidence records without network access or predictive and causal claims.
---

# Run Exploratory Analysis

Execute only approved, prepared data. Keep computation, evidence validation, and
natural-language rendering separate.

## Workflow

1. Read `references/input-contract.md` and
   `references/generic-analysis-selection.md`. Reject the request before creating an
   output directory when approval, preparation status, frozen metadata, artifact
   paths, or hashes do not match.
2. Run `scripts/run_eda.py EXECUTION PREPARATION_MANIFEST --output-dir OUTPUT`.
3. Always run quality and distribution plus the baseline of every explicitly
   requested temporal, group, spatial, and association module that is eligible
   under frozen `allowed_analyses`.
   Let Python apply the frozen `generic_analysis_recipe.v1`; the model must not
   choose tests, derived variables, thresholds, or charts ad hoc.
   Use the frozen primary time axis and group axis from `analysis_focus.v1`;
   do not select a duplicate time-like column by name.
4. Run second-pass drilldowns only after a recorded trigger fires: missingness, join
   loss, robust outlier candidates, distribution asymmetry, or a
   strong/unstable numeric association.
   Screening values may decide the gate but must not create stage-2 tables,
   charts, candidates, or evidence before it opens.
5. Create one structured validation record for every candidate finding,
   including coverage, denominator, candidate-sensitivity, and declared
   definition-sensitivity statuses. Record non-applicable checks explicitly.
   Label each finding
   `validated`, `qualified`, or `rejected`; never silently drop a candidate.
   Execute each declared sensitivity pair and derived rule by its frozen
   variable IDs. If pairwise coverage, groups, periods, units, or scales do not
   support a requested check, emit a qualified result and a structured data
   request instead of fabricating a statistic.
6. When the supplied data cannot adequately support a check, write a structured
   `additional_data_requests.json` for the user. Continue only with supported
   findings and never search for or download the requested data.
7. Read `references/output-contract.md` before handing artifacts to a report or
   dashboard renderer.

## Guardrails

- Accept only local artifacts referenced by the completed preparation manifest.
- Require `USER_PROVIDED_LOCAL_ONLY`; never browse, call APIs, or fetch data.
- Use only variables with `AUTO_CONFIDENT` or `USER_CONFIRMED` status and the
  required analysis in `allowed_analyses`.
- Treat `QUALITY_ONLY` and `EXCLUDED` as absolute exclusions from measures,
  time axes, group axes, and geography axes even when a column name or physical
  type resembles an analytic field.
- Treat identifiers, codes, time axes, geography fields, and sensitive fields as
  dimensions only when their frozen roles permit it.
- Preserve source IDs, variable IDs, denominators, scope, units, and evidence
  IDs for every numerical claim and chart.
- Promote one summary evidence item per declared rule, declared cohort
  comparison, frozen association pair, and sensitivity pair. Preserve question
  relevance and requested-module coverage in the frozen top-eight selection.
- Describe associations as observed co-movement. Do not claim prediction,
  causation, policy effects, or automated decisions.
- Keep outputs deterministic: sorted records, stable IDs, fixed plot ordering,
  no timestamps, and no random sampling.
- Execute only frozen association pairs. Keep sensitivity-only alternatives
  out of general univariate, temporal, group, spatial, and association modules.
- Without geometry, spatial baseline means geography comparison/rank and
  geography-by-time patterns only. Prefer the frozen geography label after
  verifying a one-to-one ID-label mapping; never fabricate a map, distance, or
  spatial-autocorrelation result.
- Let Python rank evidence and render bounded factual summaries. A model may
  organize or explain those summaries but must not promote unranked or rejected
  evidence, change scores, or add domain meaning not supplied by the user.

## Resources

- `scripts/run_eda.py`: validate inputs and create staged EDA artifacts.
- `references/input-contract.md`: accepted execution and preparation inputs.
- `references/generic-analysis-selection.md`: technique, derivation,
  visualization, validation, and ranking decision table.
- `references/output-contract.md`: artifact schemas and handoff rules.
