# Output Contract

Write these deterministic artifacts:

- `eda_manifest.json`: input hashes, table inventory, executed stages, stage-2
  triggers, artifact references, and overall `COMPLETE` or `PARTIAL_EXECUTION`.
- `analysis_tables/data_quality.csv`
- `analysis_tables/numeric_summary.csv`
- `analysis_tables/derived_variables.csv`
- `analysis_tables/temporal_summary.csv`
- `analysis_tables/group_comparison.csv`
- `analysis_tables/spatial_summary.csv`
- `analysis_tables/association_summary.csv`
- `analysis_tables/association_drilldown.csv`
- `analysis_tables/analysis_scope_selection.csv`
- `analysis_tables/sensitivity_summary.csv`
- `candidate_findings.json`
- `evidence_records.json`
- `validation_summary.json`
- `finding_validation_records.json`
- `insight_ranking.json`
- `additional_data_requests.json`
- `chart_manifest.json`
- `execution_integrity.json`
- `charts/*.png`

Every candidate and evidence record must include:

- stable finding/evidence ID;
- source IDs and variable IDs;
- observed metric and value;
- denominator;
- period/geography or table scope;
- unit when known;
- calculation basis;
- validation status and qualification reasons.
- a deterministic factual summary and insight score.
- requested module, primary-measure relevance, declared-rule relation,
  question relevance, and evidence class.

`insight_ranking.json` selects no more than eight validated or qualified
evidence records by the frozen question-coverage and diversity policy. It
preserves all frozen association-pair baselines when eligible, then required
evidence classes and requested-module coverage, applies per-module/per-kind
caps, and records that no domain interpretation was used. Reports and
dashboards must follow this order instead of asking a model to decide what
looks important.

`validated` means the result has an adequate finding-specific denominator and
no recorded limitation. `qualified` preserves a usable observation with an
explicit coverage, missingness, stability, or sample-size limitation.
Sensitivity instability qualifies rather than erases a descriptive baseline.
`rejected` remains in the candidate file but must not appear as a report
conclusion.

`additional_data_requests.json` is always written. It uses `NOT_REQUIRED` when
the approved data is sufficient and `REQUESTED` only when a relevant approved
variable, declared check, or finding is blocked. Structural start/partial
periods, quality-only missingness, and a successful frozen window do not create
blanket requests. Every request instructs the user to provide a local file and records
`network_access_permitted: false`; it never triggers autonomous collection.

Charts must reference one or more evidence IDs or be explicitly labeled as
quality/context charts. Downstream renderers may use only `validated` and
`qualified` evidence and must reproduce every qualification.

Declared-rule rows preserve rule ID, operation, source/group/time variable IDs,
group value, threshold, windows, missing/partial-period policies, and evidence
status. Declared sensitivity rows preserve pair ID, both measure IDs, requested
checks, pairwise coverage, supported stability statistics, threshold, minimum
pairwise count, and any qualification reason.

Evidence promotion writes one summary candidate per derived rule, one per
declared cohort comparison, one baseline per frozen association pair, and one
per sensitivity pair. Report charts are capped by the frozen budget with at
most one missingness chart, primary-only distribution and temporal context,
requested group/spatial coverage, and one association chart per frozen pair.

`association_summary.csv` is the frozen-pair core baseline.
`association_drilldown.csv` contains only trigger-gated robustness details and
has zero data rows when stage 2 does not run. `execution_integrity.json` records
module executions, trigger decision order, stage-specific output counts, the
executed pair IDs, and equality of candidate and finding-validation counts.
