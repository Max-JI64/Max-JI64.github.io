# Input Contract

Accept:

1. one `analysis_execution_request.v1`;
2. one `preparation_manifest.v1` with `status: COMPLETED`;
3. only artifacts listed in that manifest.

Require explicit `APPROVED` approval, a resolved frozen variable inventory, one
`exploratory_analysis` task assigned to `run-exploratory-analysis`, and analysis
steps limited to:

- `data_quality`
- `distribution`
- `group_comparison`
- `temporal_pattern`
- `spatial_pattern`
- `association`
- `anomaly_screen`
- `cross_source_consistency`

Also require a frozen `data_access_policy.v1` with
`mode: USER_PROVIDED_LOCAL_ONLY`, network access and remote fetching disabled,
and missing data routed to `REQUEST_USER`.

Require `generic_analysis_recipe.v1`. It freezes domain-neutral selection
rules for univariate, temporal, group, association, visualization, derived
variables, finding validation, deterministic insight ranking, and claim
boundaries. The executor must reject recipe drift.

The manifest execution and blueprint IDs must match the execution request. Its
stored execution-request SHA-256 must equal the supplied request. Artifact paths
must remain inside the manifest directory and stored artifact hashes must match.

Use `join.artifact` when an integrated table exists. Otherwise analyze each
prepared source artifact separately. Never accept an extra table path.
Never access the internet or acquire a missing dataset.

Map prepared columns through the manifest's frozen variable metadata. Use a
variable as a measure only when its status is `AUTO_CONFIDENT` or
`USER_CONFIRMED` and its `allowed_analyses` contains the requested module.

Require `analysis_focus.v1`, `staged_eda_policy.v1`, and
`generic_analysis_recipe.v1` to equal their top-level frozen execution copies.
Resolve primary axes and declared measures by variable ID. Frozen
`QUALITY_ONLY` or `EXCLUDED` roles override name and physical-type fallback and
are never eligible as measures, time axes, group axes, or geography axes.

Require the recipe association-pair list to equal the resolved focus list.
Only those pairs may be screened or analyzed. Require the spatial baseline to
freeze geography axis, optional display label, primary measure, and geometry
prohibition. Require stage 3 to apply to every candidate.
