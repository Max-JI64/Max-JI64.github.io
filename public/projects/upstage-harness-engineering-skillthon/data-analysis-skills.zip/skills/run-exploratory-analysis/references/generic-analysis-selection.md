# Generic Analysis Selection

This reference defines the domain-neutral decisions that Python must execute.
The model may explain completed evidence, but it must not improvise a technique,
derived variable, chart, threshold, or finding status.

## Selection boundary

Select analyses only from frozen:

- semantic role;
- measurement scale;
- allowed and prohibited analyses;
- unit;
- observed sample size and cardinality;
- approved time and group dimensions.

Domain interpretation is optional and may be added only when the user supplies
the topic and variable meaning. It must not change computed evidence.

For bounded execution, use at most 20 detailed measures per table, ordered by
missing rate and then variable ID. This permits at most 190 association pairs.
Record every eligible, selected, and cost-bound-excluded measure in
`analysis_scope_selection.csv`.

## Univariate numeric analysis

For every approved quantitative measure, compute:

- count and missing count;
- zero and negative rates;
- mean, median, standard deviation, quartiles, minimum, and maximum;
- coefficient of variation only when the mean is non-zero;
- sample skewness with at least three observations;
- 1.5-IQR and modified MAD-z outlier candidate counts.

Absolute skewness at least 1 creates a distribution-asymmetry candidate.
IQR or MAD candidates are review targets, not confirmed errors.

Use one combined histogram/KDE and boxplot chart for the frozen primary measure.
Never transform the reported scale merely to make a chart look normal.

## Time and measure analysis

Use only an approved temporal dimension and approved measure.

- At two or more periods, calculate first and latest period means and their
  absolute difference.
- For confirmed percent units, label the difference as percentage points.
- Calculate percent change only when the scale is `RATIO`, the first value is
  positive, and `measure_time_basis` is explicitly one of `snapshot`,
  `period_total`, `period_average`, or `rate`.
- At three or more periods, calculate the OLS slope of period means.
- At five or more periods, compare the mean of the latest two periods with the
  preceding two periods.
- Recalculate slope without the latest period and record directional stability.

Do not calculate per-capita, rates, shares, or normalized indices unless an
approved denominator and formula are frozen before execution.

Use the frozen primary measure for the report-facing line chart. Other
approved measures may remain in analysis tables without consuming the chart
budget.

## Group and measure analysis

For every approved group-measure pair with at least two groups, calculate:

- group median;
- overall median;
- gap from the overall median;
- descending group rank;
- maximum-minus-minimum group-median gap.

Use a full ranked bar chart for at most 30 groups. When group, time, and measure
are all present and the matrix is no larger than 30 by 30, use a group-by-time
heatmap. Keep complete group results in the analysis table even when the chart
budget or cardinality prevents a chart.

## Numeric association analysis

For every frozen association pair with at least five pairwise-complete rows:

- compute Pearson and Spearman association;
- remove joint 1.5-IQR candidates and recompute Pearson association;
- when time exists, exclude the latest period and recompute Pearson association;
- record sample sizes and whether direction is stable.

Never create comparison-to-comparison pairs unless the approved focus freezes
them. Keep sensitivity-only alternatives outside general analysis. Use
lightweight pairwise values for the core baseline and trigger screening. Every
frozen pair creates one stage-1 baseline evidence record and one report-facing
scatter/regression chart even when the association is weak; weak results state
that no strong association was observed at the frozen threshold. Robustness
rows remain conditional on the recorded stage-2 gate.

## Declared-rule cohort comparison

Promote each frozen derived rule to one summary candidate rather than one
candidate per group. Preserve the rule ID, threshold, evaluated group count,
and labelled group values. When a frozen derived-group comparison selects a
cohort from a rule result, compare that cohort with the remaining eligible
groups on only the declared comparison measures and statistic. Enforce the
declared group and per-group observation minima, missing policy, and non-causal
claim boundary.

Promote each frozen sensitivity pair to one summary candidate containing
pairwise coverage and every requested supported stability result.

## Spatial baseline without geometry

Use the frozen geography axis and primary measure for geography comparison,
rank, and geography-by-time tables or heatmaps. Prefer the frozen label after
confirming that ID and label map one-to-one. A conflicting mapping produces a
qualified module disposition. Without geometry or adjacency, never calculate a
map, distance, neighborhood, or spatial-autocorrelation statistic.

## Finding validation and ranking

Every candidate first receives exactly one validation record. Coverage and
denominator checks always apply. Candidate and declared-definition sensitivity
must be `applied`, `not_applicable`, `insufficient_data`, or `failed`, with a
reason. Then every candidate becomes evidence:

- `validated` when denominator and available sensitivity checks are adequate;
- `qualified` when useful but limited by sample size, coverage, missingness, or
  unavailable sensitivity;
- `rejected` when the candidate has no usable coverage or fails its required
  denominator. Sensitivity instability qualifies an otherwise usable
  descriptive baseline and is disclosed as a limitation.

Rank reportable evidence deterministically with question coverage first:

1. preserve one baseline for every frozen association pair;
2. cover derived-rule, declared-cohort, association, and sensitivity evidence
   when eligible;
3. cover every requested module when eligible;
4. apply the frozen maximum per module and per kind;
5. fill remaining positions by score and evidence ID;
6. exclude rejected evidence.

Render at most eight ranked insights. Each statement must contain the observed
pattern, comparison or calculation, magnitude, denominator, scope, status, and
limitations. Domain significance is not inferred.

## Data requests

Request user-provided local data only when an approved focus variable or
finding is blocked:

- join coverage is below 80%;
- a required sensitivity check lacks observations;
- no eligible finding can be generated.

Do not request data solely because a table-wide missingness rate is high, a
quality-only field is empty, an unavailable period predates a source series,
or a completed declared window has fewer rows than an unrelated global default.
Use the finding-specific frozen minimum denominator and list the relevant
variable IDs and finding scope.

Never browse, call an API, or download data to satisfy a request.

## Frozen focus, derived rules, and definition sensitivity

Use analysis-focus measures before other eligible measures and only the
declared primary time axis for primary temporal analysis. Geography may be a
group axis only when frozen roles include both `GEO_AXIS` and `GROUP`. Never
select `QUALITY_ONLY` variables as measures or axes.

Execute derived rules by frozen variable IDs and apply each threshold, minimum
observations, recent/previous windows, missing policy, and partial-period
policy exactly. Execute sensitivity pairs using pairwise-complete coverage and
only their requested direction, Pearson/Spearman co-movement, group-rank,
threshold-classification, latest-period, or time-window checks. When a
statistic is unsupported, record it as qualified and request the specific
missing local variable, period, group, or coverage flag.
